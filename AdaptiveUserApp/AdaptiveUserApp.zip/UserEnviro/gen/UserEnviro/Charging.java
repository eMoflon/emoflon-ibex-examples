/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Charging</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UserEnviro.Charging#isUnit <em>Unit</em>}</li>
 * </ul>
 * </p>
 *
 * @see UserEnviro.UserEnviroPackage#getCharging()
 * @model
 * @generated
 */
public interface Charging extends EObject {
	/**
	 * Returns the value of the '<em><b>Unit</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Unit</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Unit</em>' attribute.
	 * @see #setUnit(boolean)
	 * @see UserEnviro.UserEnviroPackage#getCharging_Unit()
	 * @model
	 * @generated
	 */
	boolean isUnit();

	/**
	 * Sets the value of the '{@link UserEnviro.Charging#isUnit <em>Unit</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Unit</em>' attribute.
	 * @see #isUnit()
	 * @generated
	 */
	void setUnit(boolean value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Charging
