/**
 */
package UserEnviro;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Three G</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getThreeG()
 * @model
 * @generated
 */
public interface ThreeG extends ConnectionSpeed { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // ThreeG
