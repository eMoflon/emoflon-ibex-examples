/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Usage Time</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UserEnviro.UsageTime#getUsetime <em>Usetime</em>}</li>
 * </ul>
 * </p>
 *
 * @see UserEnviro.UserEnviroPackage#getUsageTime()
 * @model
 * @generated
 */
public interface UsageTime extends EObject {
	/**
	 * Returns the value of the '<em><b>Usetime</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Usetime</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Usetime</em>' attribute.
	 * @see #setUsetime(int)
	 * @see UserEnviro.UserEnviroPackage#getUsageTime_Usetime()
	 * @model
	 * @generated
	 */
	int getUsetime();

	/**
	 * Sets the value of the '{@link UserEnviro.UsageTime#getUsetime <em>Usetime</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Usetime</em>' attribute.
	 * @see #getUsetime()
	 * @generated
	 */
	void setUsetime(int value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // UsageTime
