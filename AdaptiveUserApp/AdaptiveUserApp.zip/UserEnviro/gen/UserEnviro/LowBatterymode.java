/**
 */
package UserEnviro;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Low Batterymode</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getLowBatterymode()
 * @model
 * @generated
 */
public interface LowBatterymode extends Batterymode { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // LowBatterymode
