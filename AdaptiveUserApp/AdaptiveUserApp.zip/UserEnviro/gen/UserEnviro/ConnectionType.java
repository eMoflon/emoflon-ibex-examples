/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connection Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UserEnviro.ConnectionType#getWifi <em>Wifi</em>}</li>
 *   <li>{@link UserEnviro.ConnectionType#getCellular <em>Cellular</em>}</li>
 * </ul>
 * </p>
 *
 * @see UserEnviro.UserEnviroPackage#getConnectionType()
 * @model
 * @generated
 */
public interface ConnectionType extends EObject {
	/**
	 * Returns the value of the '<em><b>Wifi</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Wifi</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Wifi</em>' reference.
	 * @see #setWifi(Wifi)
	 * @see UserEnviro.UserEnviroPackage#getConnectionType_Wifi()
	 * @model
	 * @generated
	 */
	Wifi getWifi();

	/**
	 * Sets the value of the '{@link UserEnviro.ConnectionType#getWifi <em>Wifi</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Wifi</em>' reference.
	 * @see #getWifi()
	 * @generated
	 */
	void setWifi(Wifi value);

	/**
	 * Returns the value of the '<em><b>Cellular</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Cellular</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cellular</em>' reference.
	 * @see #setCellular(Cellular)
	 * @see UserEnviro.UserEnviroPackage#getConnectionType_Cellular()
	 * @model
	 * @generated
	 */
	Cellular getCellular();

	/**
	 * Sets the value of the '{@link UserEnviro.ConnectionType#getCellular <em>Cellular</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cellular</em>' reference.
	 * @see #getCellular()
	 * @generated
	 */
	void setCellular(Cellular value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // ConnectionType
