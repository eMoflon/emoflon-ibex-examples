/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>User</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UserEnviro.User#getMood <em>Mood</em>}</li>
 *   <li>{@link UserEnviro.User#getExp <em>Exp</em>}</li>
 *   <li>{@link UserEnviro.User#getTime <em>Time</em>}</li>
 *   <li>{@link UserEnviro.User#getVision <em>Vision</em>}</li>
 *   <li>{@link UserEnviro.User#getName <em>Name</em>}</li>
 *   <li>{@link UserEnviro.User#getAge <em>Age</em>}</li>
 * </ul>
 * </p>
 *
 * @see UserEnviro.UserEnviroPackage#getUser()
 * @model
 * @generated
 */
public interface User extends EObject {
	/**
	 * Returns the value of the '<em><b>Mood</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mood</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mood</em>' containment reference.
	 * @see #setMood(Mood)
	 * @see UserEnviro.UserEnviroPackage#getUser_Mood()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Mood getMood();

	/**
	 * Sets the value of the '{@link UserEnviro.User#getMood <em>Mood</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Mood</em>' containment reference.
	 * @see #getMood()
	 * @generated
	 */
	void setMood(Mood value);

	/**
	 * Returns the value of the '<em><b>Exp</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Exp</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exp</em>' containment reference.
	 * @see #setExp(ExperienceLevel)
	 * @see UserEnviro.UserEnviroPackage#getUser_Exp()
	 * @model containment="true" required="true"
	 * @generated
	 */
	ExperienceLevel getExp();

	/**
	 * Sets the value of the '{@link UserEnviro.User#getExp <em>Exp</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Exp</em>' containment reference.
	 * @see #getExp()
	 * @generated
	 */
	void setExp(ExperienceLevel value);

	/**
	 * Returns the value of the '<em><b>Time</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Time</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Time</em>' reference.
	 * @see #setTime(UsageTime)
	 * @see UserEnviro.UserEnviroPackage#getUser_Time()
	 * @model required="true"
	 * @generated
	 */
	UsageTime getTime();

	/**
	 * Sets the value of the '{@link UserEnviro.User#getTime <em>Time</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Time</em>' reference.
	 * @see #getTime()
	 * @generated
	 */
	void setTime(UsageTime value);

	/**
	 * Returns the value of the '<em><b>Vision</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vision</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vision</em>' reference.
	 * @see #setVision(Vision)
	 * @see UserEnviro.UserEnviroPackage#getUser_Vision()
	 * @model
	 * @generated
	 */
	Vision getVision();

	/**
	 * Sets the value of the '{@link UserEnviro.User#getVision <em>Vision</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vision</em>' reference.
	 * @see #getVision()
	 * @generated
	 */
	void setVision(Vision value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see UserEnviro.UserEnviroPackage#getUser_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link UserEnviro.User#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Age</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Age</em>' attribute.
	 * @see #setAge(int)
	 * @see UserEnviro.UserEnviroPackage#getUser_Age()
	 * @model
	 * @generated
	 */
	int getAge();

	/**
	 * Sets the value of the '{@link UserEnviro.User#getAge <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Age</em>' attribute.
	 * @see #getAge()
	 * @generated
	 */
	void setAge(int value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // User
