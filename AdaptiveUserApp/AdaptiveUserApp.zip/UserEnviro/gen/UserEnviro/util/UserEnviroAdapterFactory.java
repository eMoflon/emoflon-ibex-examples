/**
 */
package UserEnviro.util;

import UserEnviro.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see UserEnviro.UserEnviroPackage
 * @generated
 */
public class UserEnviroAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static UserEnviroPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserEnviroAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = UserEnviroPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UserEnviroSwitch<Adapter> modelSwitch = new UserEnviroSwitch<Adapter>() {
		@Override
		public Adapter caseContext(Context object) {
			return createContextAdapter();
		}

		@Override
		public Adapter caseUser(User object) {
			return createUserAdapter();
		}

		@Override
		public Adapter caseOldAgeUser(OldAgeUser object) {
			return createOldAgeUserAdapter();
		}

		@Override
		public Adapter caseMiddleAgeUser(MiddleAgeUser object) {
			return createMiddleAgeUserAdapter();
		}

		@Override
		public Adapter caseYoungerUser(YoungerUser object) {
			return createYoungerUserAdapter();
		}

		@Override
		public Adapter caseVision(Vision object) {
			return createVisionAdapter();
		}

		@Override
		public Adapter caseNormalvision(Normalvision object) {
			return createNormalvisionAdapter();
		}

		@Override
		public Adapter caseReducedvision(Reducedvision object) {
			return createReducedvisionAdapter();
		}

		@Override
		public Adapter caseMood(Mood object) {
			return createMoodAdapter();
		}

		@Override
		public Adapter caseBadmood(Badmood object) {
			return createBadmoodAdapter();
		}

		@Override
		public Adapter caseGoodmood(Goodmood object) {
			return createGoodmoodAdapter();
		}

		@Override
		public Adapter caseNeutralmood(Neutralmood object) {
			return createNeutralmoodAdapter();
		}

		@Override
		public Adapter caseExperienceLevel(ExperienceLevel object) {
			return createExperienceLevelAdapter();
		}

		@Override
		public Adapter caseExperienced(Experienced object) {
			return createExperiencedAdapter();
		}

		@Override
		public Adapter caseInexperienced(Inexperienced object) {
			return createInexperiencedAdapter();
		}

		@Override
		public Adapter caseIntermediate(Intermediate object) {
			return createIntermediateAdapter();
		}

		@Override
		public Adapter caseUsageTime(UsageTime object) {
			return createUsageTimeAdapter();
		}

		@Override
		public Adapter caseEnvironment(Environment object) {
			return createEnvironmentAdapter();
		}

		@Override
		public Adapter caseConnectionSpeed(ConnectionSpeed object) {
			return createConnectionSpeedAdapter();
		}

		@Override
		public Adapter caseThreeG(ThreeG object) {
			return createThreeGAdapter();
		}

		@Override
		public Adapter caseTwoG(TwoG object) {
			return createTwoGAdapter();
		}

		@Override
		public Adapter caseFourG(FourG object) {
			return createFourGAdapter();
		}

		@Override
		public Adapter caseConnectionType(ConnectionType object) {
			return createConnectionTypeAdapter();
		}

		@Override
		public Adapter caseWifi(Wifi object) {
			return createWifiAdapter();
		}

		@Override
		public Adapter caseCellular(Cellular object) {
			return createCellularAdapter();
		}

		@Override
		public Adapter caseBatteryLevel(BatteryLevel object) {
			return createBatteryLevelAdapter();
		}

		@Override
		public Adapter caseCharging(Charging object) {
			return createChargingAdapter();
		}

		@Override
		public Adapter caseAmbientlight(Ambientlight object) {
			return createAmbientlightAdapter();
		}

		@Override
		public Adapter caseLowLight(LowLight object) {
			return createLowLightAdapter();
		}

		@Override
		public Adapter caseHighLight(HighLight object) {
			return createHighLightAdapter();
		}

		@Override
		public Adapter caseNormalLight(NormalLight object) {
			return createNormalLightAdapter();
		}

		@Override
		public Adapter caseTime(Time object) {
			return createTimeAdapter();
		}

		@Override
		public Adapter caseSunRise(SunRise object) {
			return createSunRiseAdapter();
		}

		@Override
		public Adapter caseSunDawn(SunDawn object) {
			return createSunDawnAdapter();
		}

		@Override
		public Adapter caseActivity(Activity object) {
			return createActivityAdapter();
		}

		@Override
		public Adapter casePlatform(Platform object) {
			return createPlatformAdapter();
		}

		@Override
		public Adapter caseDeviceHardware(DeviceHardware object) {
			return createDeviceHardwareAdapter();
		}

		@Override
		public Adapter caseCamera(Camera object) {
			return createCameraAdapter();
		}

		@Override
		public Adapter caseScreenDimension(ScreenDimension object) {
			return createScreenDimensionAdapter();
		}

		@Override
		public Adapter caseBatterymode(Batterymode object) {
			return createBatterymodeAdapter();
		}

		@Override
		public Adapter caseNormalBatterymode(NormalBatterymode object) {
			return createNormalBatterymodeAdapter();
		}

		@Override
		public Adapter caseLowBatterymode(LowBatterymode object) {
			return createLowBatterymodeAdapter();
		}

		@Override
		public Adapter caseDevicetype(Devicetype object) {
			return createDevicetypeAdapter();
		}

		@Override
		public Adapter caseTablet(Tablet object) {
			return createTabletAdapter();
		}

		@Override
		public Adapter caseSmartphone(Smartphone object) {
			return createSmartphoneAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Context <em>Context</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Context
	 * @generated
	 */
	public Adapter createContextAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.User <em>User</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.User
	 * @generated
	 */
	public Adapter createUserAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.OldAgeUser <em>Old Age User</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.OldAgeUser
	 * @generated
	 */
	public Adapter createOldAgeUserAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.MiddleAgeUser <em>Middle Age User</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.MiddleAgeUser
	 * @generated
	 */
	public Adapter createMiddleAgeUserAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.YoungerUser <em>Younger User</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.YoungerUser
	 * @generated
	 */
	public Adapter createYoungerUserAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Vision <em>Vision</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Vision
	 * @generated
	 */
	public Adapter createVisionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Normalvision <em>Normalvision</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Normalvision
	 * @generated
	 */
	public Adapter createNormalvisionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Reducedvision <em>Reducedvision</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Reducedvision
	 * @generated
	 */
	public Adapter createReducedvisionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Mood <em>Mood</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Mood
	 * @generated
	 */
	public Adapter createMoodAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Badmood <em>Badmood</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Badmood
	 * @generated
	 */
	public Adapter createBadmoodAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Goodmood <em>Goodmood</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Goodmood
	 * @generated
	 */
	public Adapter createGoodmoodAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Neutralmood <em>Neutralmood</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Neutralmood
	 * @generated
	 */
	public Adapter createNeutralmoodAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.ExperienceLevel <em>Experience Level</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.ExperienceLevel
	 * @generated
	 */
	public Adapter createExperienceLevelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Experienced <em>Experienced</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Experienced
	 * @generated
	 */
	public Adapter createExperiencedAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Inexperienced <em>Inexperienced</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Inexperienced
	 * @generated
	 */
	public Adapter createInexperiencedAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Intermediate <em>Intermediate</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Intermediate
	 * @generated
	 */
	public Adapter createIntermediateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.UsageTime <em>Usage Time</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.UsageTime
	 * @generated
	 */
	public Adapter createUsageTimeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Environment <em>Environment</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Environment
	 * @generated
	 */
	public Adapter createEnvironmentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.ConnectionSpeed <em>Connection Speed</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.ConnectionSpeed
	 * @generated
	 */
	public Adapter createConnectionSpeedAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.ThreeG <em>Three G</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.ThreeG
	 * @generated
	 */
	public Adapter createThreeGAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.TwoG <em>Two G</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.TwoG
	 * @generated
	 */
	public Adapter createTwoGAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.FourG <em>Four G</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.FourG
	 * @generated
	 */
	public Adapter createFourGAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.ConnectionType <em>Connection Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.ConnectionType
	 * @generated
	 */
	public Adapter createConnectionTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Wifi <em>Wifi</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Wifi
	 * @generated
	 */
	public Adapter createWifiAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Cellular <em>Cellular</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Cellular
	 * @generated
	 */
	public Adapter createCellularAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.BatteryLevel <em>Battery Level</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.BatteryLevel
	 * @generated
	 */
	public Adapter createBatteryLevelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Charging <em>Charging</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Charging
	 * @generated
	 */
	public Adapter createChargingAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Ambientlight <em>Ambientlight</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Ambientlight
	 * @generated
	 */
	public Adapter createAmbientlightAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.LowLight <em>Low Light</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.LowLight
	 * @generated
	 */
	public Adapter createLowLightAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.HighLight <em>High Light</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.HighLight
	 * @generated
	 */
	public Adapter createHighLightAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.NormalLight <em>Normal Light</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.NormalLight
	 * @generated
	 */
	public Adapter createNormalLightAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Time <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Time
	 * @generated
	 */
	public Adapter createTimeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.SunRise <em>Sun Rise</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.SunRise
	 * @generated
	 */
	public Adapter createSunRiseAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.SunDawn <em>Sun Dawn</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.SunDawn
	 * @generated
	 */
	public Adapter createSunDawnAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Activity <em>Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Activity
	 * @generated
	 */
	public Adapter createActivityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Platform <em>Platform</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Platform
	 * @generated
	 */
	public Adapter createPlatformAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.DeviceHardware <em>Device Hardware</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.DeviceHardware
	 * @generated
	 */
	public Adapter createDeviceHardwareAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Camera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Camera
	 * @generated
	 */
	public Adapter createCameraAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.ScreenDimension <em>Screen Dimension</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.ScreenDimension
	 * @generated
	 */
	public Adapter createScreenDimensionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Batterymode <em>Batterymode</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Batterymode
	 * @generated
	 */
	public Adapter createBatterymodeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.NormalBatterymode <em>Normal Batterymode</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.NormalBatterymode
	 * @generated
	 */
	public Adapter createNormalBatterymodeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.LowBatterymode <em>Low Batterymode</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.LowBatterymode
	 * @generated
	 */
	public Adapter createLowBatterymodeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Devicetype <em>Devicetype</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Devicetype
	 * @generated
	 */
	public Adapter createDevicetypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Tablet <em>Tablet</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Tablet
	 * @generated
	 */
	public Adapter createTabletAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UserEnviro.Smartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UserEnviro.Smartphone
	 * @generated
	 */
	public Adapter createSmartphoneAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //UserEnviroAdapterFactory
