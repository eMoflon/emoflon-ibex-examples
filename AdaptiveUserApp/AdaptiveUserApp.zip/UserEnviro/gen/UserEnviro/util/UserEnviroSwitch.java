/**
 */
package UserEnviro.util;

import UserEnviro.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see UserEnviro.UserEnviroPackage
 * @generated
 */
public class UserEnviroSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static UserEnviroPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserEnviroSwitch() {
		if (modelPackage == null) {
			modelPackage = UserEnviroPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case UserEnviroPackage.CONTEXT: {
			Context context = (Context) theEObject;
			T result = caseContext(context);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.USER: {
			User user = (User) theEObject;
			T result = caseUser(user);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.OLD_AGE_USER: {
			OldAgeUser oldAgeUser = (OldAgeUser) theEObject;
			T result = caseOldAgeUser(oldAgeUser);
			if (result == null)
				result = caseUser(oldAgeUser);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.MIDDLE_AGE_USER: {
			MiddleAgeUser middleAgeUser = (MiddleAgeUser) theEObject;
			T result = caseMiddleAgeUser(middleAgeUser);
			if (result == null)
				result = caseUser(middleAgeUser);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.YOUNGER_USER: {
			YoungerUser youngerUser = (YoungerUser) theEObject;
			T result = caseYoungerUser(youngerUser);
			if (result == null)
				result = caseUser(youngerUser);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.VISION: {
			Vision vision = (Vision) theEObject;
			T result = caseVision(vision);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.NORMALVISION: {
			Normalvision normalvision = (Normalvision) theEObject;
			T result = caseNormalvision(normalvision);
			if (result == null)
				result = caseVision(normalvision);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.REDUCEDVISION: {
			Reducedvision reducedvision = (Reducedvision) theEObject;
			T result = caseReducedvision(reducedvision);
			if (result == null)
				result = caseVision(reducedvision);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.MOOD: {
			Mood mood = (Mood) theEObject;
			T result = caseMood(mood);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.BADMOOD: {
			Badmood badmood = (Badmood) theEObject;
			T result = caseBadmood(badmood);
			if (result == null)
				result = caseMood(badmood);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.GOODMOOD: {
			Goodmood goodmood = (Goodmood) theEObject;
			T result = caseGoodmood(goodmood);
			if (result == null)
				result = caseMood(goodmood);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.NEUTRALMOOD: {
			Neutralmood neutralmood = (Neutralmood) theEObject;
			T result = caseNeutralmood(neutralmood);
			if (result == null)
				result = caseMood(neutralmood);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.EXPERIENCE_LEVEL: {
			ExperienceLevel experienceLevel = (ExperienceLevel) theEObject;
			T result = caseExperienceLevel(experienceLevel);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.EXPERIENCED: {
			Experienced experienced = (Experienced) theEObject;
			T result = caseExperienced(experienced);
			if (result == null)
				result = caseExperienceLevel(experienced);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.INEXPERIENCED: {
			Inexperienced inexperienced = (Inexperienced) theEObject;
			T result = caseInexperienced(inexperienced);
			if (result == null)
				result = caseExperienceLevel(inexperienced);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.INTERMEDIATE: {
			Intermediate intermediate = (Intermediate) theEObject;
			T result = caseIntermediate(intermediate);
			if (result == null)
				result = caseExperienceLevel(intermediate);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.USAGE_TIME: {
			UsageTime usageTime = (UsageTime) theEObject;
			T result = caseUsageTime(usageTime);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.ENVIRONMENT: {
			Environment environment = (Environment) theEObject;
			T result = caseEnvironment(environment);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.CONNECTION_SPEED: {
			ConnectionSpeed connectionSpeed = (ConnectionSpeed) theEObject;
			T result = caseConnectionSpeed(connectionSpeed);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.THREE_G: {
			ThreeG threeG = (ThreeG) theEObject;
			T result = caseThreeG(threeG);
			if (result == null)
				result = caseConnectionSpeed(threeG);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.TWO_G: {
			TwoG twoG = (TwoG) theEObject;
			T result = caseTwoG(twoG);
			if (result == null)
				result = caseConnectionSpeed(twoG);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.FOUR_G: {
			FourG fourG = (FourG) theEObject;
			T result = caseFourG(fourG);
			if (result == null)
				result = caseConnectionSpeed(fourG);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.CONNECTION_TYPE: {
			ConnectionType connectionType = (ConnectionType) theEObject;
			T result = caseConnectionType(connectionType);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.WIFI: {
			Wifi wifi = (Wifi) theEObject;
			T result = caseWifi(wifi);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.CELLULAR: {
			Cellular cellular = (Cellular) theEObject;
			T result = caseCellular(cellular);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.BATTERY_LEVEL: {
			BatteryLevel batteryLevel = (BatteryLevel) theEObject;
			T result = caseBatteryLevel(batteryLevel);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.CHARGING: {
			Charging charging = (Charging) theEObject;
			T result = caseCharging(charging);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.AMBIENTLIGHT: {
			Ambientlight ambientlight = (Ambientlight) theEObject;
			T result = caseAmbientlight(ambientlight);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.LOW_LIGHT: {
			LowLight lowLight = (LowLight) theEObject;
			T result = caseLowLight(lowLight);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.HIGH_LIGHT: {
			HighLight highLight = (HighLight) theEObject;
			T result = caseHighLight(highLight);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.NORMAL_LIGHT: {
			NormalLight normalLight = (NormalLight) theEObject;
			T result = caseNormalLight(normalLight);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.TIME: {
			Time time = (Time) theEObject;
			T result = caseTime(time);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.SUN_RISE: {
			SunRise sunRise = (SunRise) theEObject;
			T result = caseSunRise(sunRise);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.SUN_DAWN: {
			SunDawn sunDawn = (SunDawn) theEObject;
			T result = caseSunDawn(sunDawn);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.ACTIVITY: {
			Activity activity = (Activity) theEObject;
			T result = caseActivity(activity);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.PLATFORM: {
			Platform platform = (Platform) theEObject;
			T result = casePlatform(platform);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.DEVICE_HARDWARE: {
			DeviceHardware deviceHardware = (DeviceHardware) theEObject;
			T result = caseDeviceHardware(deviceHardware);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.CAMERA: {
			Camera camera = (Camera) theEObject;
			T result = caseCamera(camera);
			if (result == null)
				result = caseDeviceHardware(camera);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.SCREEN_DIMENSION: {
			ScreenDimension screenDimension = (ScreenDimension) theEObject;
			T result = caseScreenDimension(screenDimension);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.BATTERYMODE: {
			Batterymode batterymode = (Batterymode) theEObject;
			T result = caseBatterymode(batterymode);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.NORMAL_BATTERYMODE: {
			NormalBatterymode normalBatterymode = (NormalBatterymode) theEObject;
			T result = caseNormalBatterymode(normalBatterymode);
			if (result == null)
				result = caseBatterymode(normalBatterymode);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.LOW_BATTERYMODE: {
			LowBatterymode lowBatterymode = (LowBatterymode) theEObject;
			T result = caseLowBatterymode(lowBatterymode);
			if (result == null)
				result = caseBatterymode(lowBatterymode);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.DEVICETYPE: {
			Devicetype devicetype = (Devicetype) theEObject;
			T result = caseDevicetype(devicetype);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.TABLET: {
			Tablet tablet = (Tablet) theEObject;
			T result = caseTablet(tablet);
			if (result == null)
				result = caseDevicetype(tablet);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UserEnviroPackage.SMARTPHONE: {
			Smartphone smartphone = (Smartphone) theEObject;
			T result = caseSmartphone(smartphone);
			if (result == null)
				result = caseDevicetype(smartphone);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Context</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Context</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseContext(Context object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>User</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>User</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseUser(User object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Old Age User</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Old Age User</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOldAgeUser(OldAgeUser object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Middle Age User</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Middle Age User</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMiddleAgeUser(MiddleAgeUser object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Younger User</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Younger User</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseYoungerUser(YoungerUser object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Vision</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Vision</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseVision(Vision object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Normalvision</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Normalvision</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNormalvision(Normalvision object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Reducedvision</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Reducedvision</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseReducedvision(Reducedvision object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Mood</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Mood</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMood(Mood object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Badmood</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Badmood</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBadmood(Badmood object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Goodmood</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Goodmood</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGoodmood(Goodmood object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Neutralmood</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Neutralmood</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNeutralmood(Neutralmood object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Experience Level</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Experience Level</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseExperienceLevel(ExperienceLevel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Experienced</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Experienced</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseExperienced(Experienced object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Inexperienced</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Inexperienced</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInexperienced(Inexperienced object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Intermediate</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Intermediate</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIntermediate(Intermediate object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Usage Time</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Usage Time</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseUsageTime(UsageTime object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Environment</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Environment</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEnvironment(Environment object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Connection Speed</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Connection Speed</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConnectionSpeed(ConnectionSpeed object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Three G</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Three G</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseThreeG(ThreeG object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Two G</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Two G</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTwoG(TwoG object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Four G</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Four G</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFourG(FourG object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Connection Type</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Connection Type</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConnectionType(ConnectionType object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Wifi</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Wifi</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWifi(Wifi object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Cellular</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Cellular</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCellular(Cellular object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Battery Level</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Battery Level</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBatteryLevel(BatteryLevel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Charging</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Charging</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCharging(Charging object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Ambientlight</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Ambientlight</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAmbientlight(Ambientlight object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Low Light</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Low Light</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLowLight(LowLight object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>High Light</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>High Light</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHighLight(HighLight object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Normal Light</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Normal Light</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNormalLight(NormalLight object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Time</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Time</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTime(Time object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Sun Rise</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Sun Rise</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSunRise(SunRise object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Sun Dawn</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Sun Dawn</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSunDawn(SunDawn object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Activity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Activity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseActivity(Activity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Platform</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Platform</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePlatform(Platform object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Device Hardware</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Device Hardware</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDeviceHardware(DeviceHardware object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Camera</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Camera</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCamera(Camera object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Screen Dimension</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Screen Dimension</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseScreenDimension(ScreenDimension object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Batterymode</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Batterymode</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBatterymode(Batterymode object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Normal Batterymode</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Normal Batterymode</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNormalBatterymode(NormalBatterymode object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Low Batterymode</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Low Batterymode</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLowBatterymode(LowBatterymode object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Devicetype</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Devicetype</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDevicetype(Devicetype object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tablet</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tablet</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTablet(Tablet object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Smartphone</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Smartphone</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSmartphone(Smartphone object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //UserEnviroSwitch
