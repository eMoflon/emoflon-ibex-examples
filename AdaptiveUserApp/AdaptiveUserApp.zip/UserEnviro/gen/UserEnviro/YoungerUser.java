/**
 */
package UserEnviro;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Younger User</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getYoungerUser()
 * @model
 * @generated
 */
public interface YoungerUser extends User { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // YoungerUser
