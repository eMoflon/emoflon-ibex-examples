/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cellular</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getCellular()
 * @model
 * @generated
 */
public interface Cellular extends EObject { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Cellular
