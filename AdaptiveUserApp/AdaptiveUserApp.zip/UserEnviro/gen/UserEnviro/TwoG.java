/**
 */
package UserEnviro;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Two G</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getTwoG()
 * @model
 * @generated
 */
public interface TwoG extends ConnectionSpeed { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // TwoG
