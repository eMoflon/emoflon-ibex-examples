/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UserEnviro.Activity#getActivityEnum <em>Activity Enum</em>}</li>
 * </ul>
 * </p>
 *
 * @see UserEnviro.UserEnviroPackage#getActivity()
 * @model
 * @generated
 */
public interface Activity extends EObject {
	/**
	 * Returns the value of the '<em><b>Activity Enum</b></em>' attribute.
	 * The literals are from the enumeration {@link UserEnviro.ActivityEnum}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Activity Enum</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Activity Enum</em>' attribute.
	 * @see UserEnviro.ActivityEnum
	 * @see #setActivityEnum(ActivityEnum)
	 * @see UserEnviro.UserEnviroPackage#getActivity_ActivityEnum()
	 * @model
	 * @generated
	 */
	ActivityEnum getActivityEnum();

	/**
	 * Sets the value of the '{@link UserEnviro.Activity#getActivityEnum <em>Activity Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Activity Enum</em>' attribute.
	 * @see UserEnviro.ActivityEnum
	 * @see #getActivityEnum()
	 * @generated
	 */
	void setActivityEnum(ActivityEnum value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Activity
