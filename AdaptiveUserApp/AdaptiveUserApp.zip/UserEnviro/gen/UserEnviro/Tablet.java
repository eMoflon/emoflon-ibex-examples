/**
 */
package UserEnviro;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tablet</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getTablet()
 * @model
 * @generated
 */
public interface Tablet extends Devicetype { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Tablet
