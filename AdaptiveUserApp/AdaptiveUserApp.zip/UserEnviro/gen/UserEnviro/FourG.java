/**
 */
package UserEnviro;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Four G</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getFourG()
 * @model
 * @generated
 */
public interface FourG extends ConnectionSpeed { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // FourG
