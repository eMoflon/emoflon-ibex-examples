/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Device Hardware</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getDeviceHardware()
 * @model abstract="true"
 * @generated
 */
public interface DeviceHardware extends EObject { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // DeviceHardware
