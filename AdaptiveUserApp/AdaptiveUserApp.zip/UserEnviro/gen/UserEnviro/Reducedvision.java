/**
 */
package UserEnviro;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reducedvision</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getReducedvision()
 * @model
 * @generated
 */
public interface Reducedvision extends Vision { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Reducedvision
