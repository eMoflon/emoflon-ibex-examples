/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Time</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UserEnviro.Time#getSunRise <em>Sun Rise</em>}</li>
 *   <li>{@link UserEnviro.Time#getSunDawn <em>Sun Dawn</em>}</li>
 * </ul>
 * </p>
 *
 * @see UserEnviro.UserEnviroPackage#getTime()
 * @model
 * @generated
 */
public interface Time extends EObject {
	/**
	 * Returns the value of the '<em><b>Sun Rise</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sun Rise</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sun Rise</em>' reference.
	 * @see #setSunRise(SunRise)
	 * @see UserEnviro.UserEnviroPackage#getTime_SunRise()
	 * @model
	 * @generated
	 */
	SunRise getSunRise();

	/**
	 * Sets the value of the '{@link UserEnviro.Time#getSunRise <em>Sun Rise</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sun Rise</em>' reference.
	 * @see #getSunRise()
	 * @generated
	 */
	void setSunRise(SunRise value);

	/**
	 * Returns the value of the '<em><b>Sun Dawn</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sun Dawn</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sun Dawn</em>' reference.
	 * @see #setSunDawn(SunDawn)
	 * @see UserEnviro.UserEnviroPackage#getTime_SunDawn()
	 * @model
	 * @generated
	 */
	SunDawn getSunDawn();

	/**
	 * Sets the value of the '{@link UserEnviro.Time#getSunDawn <em>Sun Dawn</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sun Dawn</em>' reference.
	 * @see #getSunDawn()
	 * @generated
	 */
	void setSunDawn(SunDawn value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Time
