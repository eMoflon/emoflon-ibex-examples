/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see UserEnviro.UserEnviroPackage
 * @generated
 */
public interface UserEnviroFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	UserEnviroFactory eINSTANCE = UserEnviro.impl.UserEnviroFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Context</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Context</em>'.
	 * @generated
	 */
	Context createContext();

	/**
	 * Returns a new object of class '<em>User</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>User</em>'.
	 * @generated
	 */
	User createUser();

	/**
	 * Returns a new object of class '<em>Old Age User</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Old Age User</em>'.
	 * @generated
	 */
	OldAgeUser createOldAgeUser();

	/**
	 * Returns a new object of class '<em>Middle Age User</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Middle Age User</em>'.
	 * @generated
	 */
	MiddleAgeUser createMiddleAgeUser();

	/**
	 * Returns a new object of class '<em>Younger User</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Younger User</em>'.
	 * @generated
	 */
	YoungerUser createYoungerUser();

	/**
	 * Returns a new object of class '<em>Normalvision</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Normalvision</em>'.
	 * @generated
	 */
	Normalvision createNormalvision();

	/**
	 * Returns a new object of class '<em>Reducedvision</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Reducedvision</em>'.
	 * @generated
	 */
	Reducedvision createReducedvision();

	/**
	 * Returns a new object of class '<em>Badmood</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Badmood</em>'.
	 * @generated
	 */
	Badmood createBadmood();

	/**
	 * Returns a new object of class '<em>Goodmood</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Goodmood</em>'.
	 * @generated
	 */
	Goodmood createGoodmood();

	/**
	 * Returns a new object of class '<em>Neutralmood</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Neutralmood</em>'.
	 * @generated
	 */
	Neutralmood createNeutralmood();

	/**
	 * Returns a new object of class '<em>Experienced</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Experienced</em>'.
	 * @generated
	 */
	Experienced createExperienced();

	/**
	 * Returns a new object of class '<em>Inexperienced</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Inexperienced</em>'.
	 * @generated
	 */
	Inexperienced createInexperienced();

	/**
	 * Returns a new object of class '<em>Intermediate</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Intermediate</em>'.
	 * @generated
	 */
	Intermediate createIntermediate();

	/**
	 * Returns a new object of class '<em>Usage Time</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Usage Time</em>'.
	 * @generated
	 */
	UsageTime createUsageTime();

	/**
	 * Returns a new object of class '<em>Environment</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Environment</em>'.
	 * @generated
	 */
	Environment createEnvironment();

	/**
	 * Returns a new object of class '<em>Three G</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Three G</em>'.
	 * @generated
	 */
	ThreeG createThreeG();

	/**
	 * Returns a new object of class '<em>Two G</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Two G</em>'.
	 * @generated
	 */
	TwoG createTwoG();

	/**
	 * Returns a new object of class '<em>Four G</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Four G</em>'.
	 * @generated
	 */
	FourG createFourG();

	/**
	 * Returns a new object of class '<em>Connection Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Connection Type</em>'.
	 * @generated
	 */
	ConnectionType createConnectionType();

	/**
	 * Returns a new object of class '<em>Wifi</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Wifi</em>'.
	 * @generated
	 */
	Wifi createWifi();

	/**
	 * Returns a new object of class '<em>Cellular</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Cellular</em>'.
	 * @generated
	 */
	Cellular createCellular();

	/**
	 * Returns a new object of class '<em>Battery Level</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Battery Level</em>'.
	 * @generated
	 */
	BatteryLevel createBatteryLevel();

	/**
	 * Returns a new object of class '<em>Charging</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Charging</em>'.
	 * @generated
	 */
	Charging createCharging();

	/**
	 * Returns a new object of class '<em>Ambientlight</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Ambientlight</em>'.
	 * @generated
	 */
	Ambientlight createAmbientlight();

	/**
	 * Returns a new object of class '<em>Low Light</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Low Light</em>'.
	 * @generated
	 */
	LowLight createLowLight();

	/**
	 * Returns a new object of class '<em>High Light</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>High Light</em>'.
	 * @generated
	 */
	HighLight createHighLight();

	/**
	 * Returns a new object of class '<em>Normal Light</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Normal Light</em>'.
	 * @generated
	 */
	NormalLight createNormalLight();

	/**
	 * Returns a new object of class '<em>Time</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Time</em>'.
	 * @generated
	 */
	Time createTime();

	/**
	 * Returns a new object of class '<em>Sun Rise</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sun Rise</em>'.
	 * @generated
	 */
	SunRise createSunRise();

	/**
	 * Returns a new object of class '<em>Sun Dawn</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Sun Dawn</em>'.
	 * @generated
	 */
	SunDawn createSunDawn();

	/**
	 * Returns a new object of class '<em>Activity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Activity</em>'.
	 * @generated
	 */
	Activity createActivity();

	/**
	 * Returns a new object of class '<em>Platform</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Platform</em>'.
	 * @generated
	 */
	Platform createPlatform();

	/**
	 * Returns a new object of class '<em>Camera</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Camera</em>'.
	 * @generated
	 */
	Camera createCamera();

	/**
	 * Returns a new object of class '<em>Screen Dimension</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Screen Dimension</em>'.
	 * @generated
	 */
	ScreenDimension createScreenDimension();

	/**
	 * Returns a new object of class '<em>Normal Batterymode</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Normal Batterymode</em>'.
	 * @generated
	 */
	NormalBatterymode createNormalBatterymode();

	/**
	 * Returns a new object of class '<em>Low Batterymode</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Low Batterymode</em>'.
	 * @generated
	 */
	LowBatterymode createLowBatterymode();

	/**
	 * Returns a new object of class '<em>Tablet</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tablet</em>'.
	 * @generated
	 */
	Tablet createTablet();

	/**
	 * Returns a new object of class '<em>Smartphone</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Smartphone</em>'.
	 * @generated
	 */
	Smartphone createSmartphone();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	UserEnviroPackage getUserEnviroPackage();

} //UserEnviroFactory
