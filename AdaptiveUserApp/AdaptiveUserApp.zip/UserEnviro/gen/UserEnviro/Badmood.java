/**
 */
package UserEnviro;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Badmood</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UserEnviro.Badmood#getBadEnum <em>Bad Enum</em>}</li>
 * </ul>
 * </p>
 *
 * @see UserEnviro.UserEnviroPackage#getBadmood()
 * @model
 * @generated
 */
public interface Badmood extends Mood {
	/**
	 * Returns the value of the '<em><b>Bad Enum</b></em>' attribute.
	 * The literals are from the enumeration {@link UserEnviro.BadEnum}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bad Enum</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bad Enum</em>' attribute.
	 * @see UserEnviro.BadEnum
	 * @see #setBadEnum(BadEnum)
	 * @see UserEnviro.UserEnviroPackage#getBadmood_BadEnum()
	 * @model
	 * @generated
	 */
	BadEnum getBadEnum();

	/**
	 * Sets the value of the '{@link UserEnviro.Badmood#getBadEnum <em>Bad Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bad Enum</em>' attribute.
	 * @see UserEnviro.BadEnum
	 * @see #getBadEnum()
	 * @generated
	 */
	void setBadEnum(BadEnum value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Badmood
