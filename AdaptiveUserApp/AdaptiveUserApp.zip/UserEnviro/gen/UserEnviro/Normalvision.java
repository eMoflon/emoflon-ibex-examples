/**
 */
package UserEnviro;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Normalvision</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getNormalvision()
 * @model
 * @generated
 */
public interface Normalvision extends Vision { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Normalvision
