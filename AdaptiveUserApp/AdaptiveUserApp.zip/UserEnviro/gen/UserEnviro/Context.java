/**
 */
package UserEnviro;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Context</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UserEnviro.Context#getUsercontext <em>Usercontext</em>}</li>
 *   <li>{@link UserEnviro.Context#getEnvirocontext <em>Envirocontext</em>}</li>
 *   <li>{@link UserEnviro.Context#getPlatcontext <em>Platcontext</em>}</li>
 * </ul>
 * </p>
 *
 * @see UserEnviro.UserEnviroPackage#getContext()
 * @model
 * @generated
 */
public interface Context extends EObject {
	/**
	 * Returns the value of the '<em><b>Usercontext</b></em>' containment reference list.
	 * The list contents are of type {@link UserEnviro.User}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Usercontext</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Usercontext</em>' containment reference list.
	 * @see UserEnviro.UserEnviroPackage#getContext_Usercontext()
	 * @model containment="true"
	 * @generated
	 */
	EList<User> getUsercontext();

	/**
	 * Returns the value of the '<em><b>Envirocontext</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Envirocontext</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Envirocontext</em>' containment reference.
	 * @see #setEnvirocontext(Environment)
	 * @see UserEnviro.UserEnviroPackage#getContext_Envirocontext()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Environment getEnvirocontext();

	/**
	 * Sets the value of the '{@link UserEnviro.Context#getEnvirocontext <em>Envirocontext</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Envirocontext</em>' containment reference.
	 * @see #getEnvirocontext()
	 * @generated
	 */
	void setEnvirocontext(Environment value);

	/**
	 * Returns the value of the '<em><b>Platcontext</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Platcontext</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Platcontext</em>' containment reference.
	 * @see #setPlatcontext(Platform)
	 * @see UserEnviro.UserEnviroPackage#getContext_Platcontext()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Platform getPlatcontext();

	/**
	 * Sets the value of the '{@link UserEnviro.Context#getPlatcontext <em>Platcontext</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Platcontext</em>' containment reference.
	 * @see #getPlatcontext()
	 * @generated
	 */
	void setPlatcontext(Platform value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Context
