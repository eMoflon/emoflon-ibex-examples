/**
 */
package UserEnviro;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Intermediate</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getIntermediate()
 * @model
 * @generated
 */
public interface Intermediate extends ExperienceLevel { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Intermediate
