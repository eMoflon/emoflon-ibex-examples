/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * TODO: Add documentation for Blup
 * <!-- end-model-doc -->
 * @see UserEnviro.UserEnviroFactory
 * @model kind="package"
 * @generated
 */
public interface UserEnviroPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "UserEnviro";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "platform:/resource/UserEnviro/model/UserEnviro.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "UserEnviro";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	UserEnviroPackage eINSTANCE = UserEnviro.impl.UserEnviroPackageImpl.init();

	/**
	 * The meta object id for the '{@link UserEnviro.impl.ContextImpl <em>Context</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.ContextImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getContext()
	 * @generated
	 */
	int CONTEXT = 0;

	/**
	 * The feature id for the '<em><b>Usercontext</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT__USERCONTEXT = 0;

	/**
	 * The feature id for the '<em><b>Envirocontext</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT__ENVIROCONTEXT = 1;

	/**
	 * The feature id for the '<em><b>Platcontext</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT__PLATCONTEXT = 2;

	/**
	 * The number of structural features of the '<em>Context</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Context</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTEXT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.UserImpl <em>User</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.UserImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getUser()
	 * @generated
	 */
	int USER = 1;

	/**
	 * The feature id for the '<em><b>Mood</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER__MOOD = 0;

	/**
	 * The feature id for the '<em><b>Exp</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER__EXP = 1;

	/**
	 * The feature id for the '<em><b>Time</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER__TIME = 2;

	/**
	 * The feature id for the '<em><b>Vision</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER__VISION = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER__NAME = 4;

	/**
	 * The feature id for the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER__AGE = 5;

	/**
	 * The number of structural features of the '<em>User</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>User</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.OldAgeUserImpl <em>Old Age User</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.OldAgeUserImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getOldAgeUser()
	 * @generated
	 */
	int OLD_AGE_USER = 2;

	/**
	 * The feature id for the '<em><b>Mood</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLD_AGE_USER__MOOD = USER__MOOD;

	/**
	 * The feature id for the '<em><b>Exp</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLD_AGE_USER__EXP = USER__EXP;

	/**
	 * The feature id for the '<em><b>Time</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLD_AGE_USER__TIME = USER__TIME;

	/**
	 * The feature id for the '<em><b>Vision</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLD_AGE_USER__VISION = USER__VISION;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLD_AGE_USER__NAME = USER__NAME;

	/**
	 * The feature id for the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLD_AGE_USER__AGE = USER__AGE;

	/**
	 * The number of structural features of the '<em>Old Age User</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLD_AGE_USER_FEATURE_COUNT = USER_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Old Age User</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OLD_AGE_USER_OPERATION_COUNT = USER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.MiddleAgeUserImpl <em>Middle Age User</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.MiddleAgeUserImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getMiddleAgeUser()
	 * @generated
	 */
	int MIDDLE_AGE_USER = 3;

	/**
	 * The feature id for the '<em><b>Mood</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIDDLE_AGE_USER__MOOD = USER__MOOD;

	/**
	 * The feature id for the '<em><b>Exp</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIDDLE_AGE_USER__EXP = USER__EXP;

	/**
	 * The feature id for the '<em><b>Time</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIDDLE_AGE_USER__TIME = USER__TIME;

	/**
	 * The feature id for the '<em><b>Vision</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIDDLE_AGE_USER__VISION = USER__VISION;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIDDLE_AGE_USER__NAME = USER__NAME;

	/**
	 * The feature id for the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIDDLE_AGE_USER__AGE = USER__AGE;

	/**
	 * The number of structural features of the '<em>Middle Age User</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIDDLE_AGE_USER_FEATURE_COUNT = USER_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Middle Age User</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIDDLE_AGE_USER_OPERATION_COUNT = USER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.YoungerUserImpl <em>Younger User</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.YoungerUserImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getYoungerUser()
	 * @generated
	 */
	int YOUNGER_USER = 4;

	/**
	 * The feature id for the '<em><b>Mood</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int YOUNGER_USER__MOOD = USER__MOOD;

	/**
	 * The feature id for the '<em><b>Exp</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int YOUNGER_USER__EXP = USER__EXP;

	/**
	 * The feature id for the '<em><b>Time</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int YOUNGER_USER__TIME = USER__TIME;

	/**
	 * The feature id for the '<em><b>Vision</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int YOUNGER_USER__VISION = USER__VISION;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int YOUNGER_USER__NAME = USER__NAME;

	/**
	 * The feature id for the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int YOUNGER_USER__AGE = USER__AGE;

	/**
	 * The number of structural features of the '<em>Younger User</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int YOUNGER_USER_FEATURE_COUNT = USER_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Younger User</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int YOUNGER_USER_OPERATION_COUNT = USER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.VisionImpl <em>Vision</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.VisionImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getVision()
	 * @generated
	 */
	int VISION = 5;

	/**
	 * The number of structural features of the '<em>Vision</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VISION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Vision</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VISION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.NormalvisionImpl <em>Normalvision</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.NormalvisionImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getNormalvision()
	 * @generated
	 */
	int NORMALVISION = 6;

	/**
	 * The number of structural features of the '<em>Normalvision</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NORMALVISION_FEATURE_COUNT = VISION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Normalvision</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NORMALVISION_OPERATION_COUNT = VISION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.ReducedvisionImpl <em>Reducedvision</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.ReducedvisionImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getReducedvision()
	 * @generated
	 */
	int REDUCEDVISION = 7;

	/**
	 * The number of structural features of the '<em>Reducedvision</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REDUCEDVISION_FEATURE_COUNT = VISION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Reducedvision</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REDUCEDVISION_OPERATION_COUNT = VISION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.MoodImpl <em>Mood</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.MoodImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getMood()
	 * @generated
	 */
	int MOOD = 8;

	/**
	 * The number of structural features of the '<em>Mood</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOOD_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Mood</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOOD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.BadmoodImpl <em>Badmood</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.BadmoodImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getBadmood()
	 * @generated
	 */
	int BADMOOD = 9;

	/**
	 * The feature id for the '<em><b>Bad Enum</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BADMOOD__BAD_ENUM = MOOD_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Badmood</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BADMOOD_FEATURE_COUNT = MOOD_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Badmood</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BADMOOD_OPERATION_COUNT = MOOD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.GoodmoodImpl <em>Goodmood</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.GoodmoodImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getGoodmood()
	 * @generated
	 */
	int GOODMOOD = 10;

	/**
	 * The number of structural features of the '<em>Goodmood</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOODMOOD_FEATURE_COUNT = MOOD_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Goodmood</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOODMOOD_OPERATION_COUNT = MOOD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.NeutralmoodImpl <em>Neutralmood</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.NeutralmoodImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getNeutralmood()
	 * @generated
	 */
	int NEUTRALMOOD = 11;

	/**
	 * The number of structural features of the '<em>Neutralmood</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEUTRALMOOD_FEATURE_COUNT = MOOD_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Neutralmood</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEUTRALMOOD_OPERATION_COUNT = MOOD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.ExperienceLevelImpl <em>Experience Level</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.ExperienceLevelImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getExperienceLevel()
	 * @generated
	 */
	int EXPERIENCE_LEVEL = 12;

	/**
	 * The number of structural features of the '<em>Experience Level</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXPERIENCE_LEVEL_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Experience Level</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXPERIENCE_LEVEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.ExperiencedImpl <em>Experienced</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.ExperiencedImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getExperienced()
	 * @generated
	 */
	int EXPERIENCED = 13;

	/**
	 * The number of structural features of the '<em>Experienced</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXPERIENCED_FEATURE_COUNT = EXPERIENCE_LEVEL_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Experienced</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXPERIENCED_OPERATION_COUNT = EXPERIENCE_LEVEL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.InexperiencedImpl <em>Inexperienced</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.InexperiencedImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getInexperienced()
	 * @generated
	 */
	int INEXPERIENCED = 14;

	/**
	 * The number of structural features of the '<em>Inexperienced</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INEXPERIENCED_FEATURE_COUNT = EXPERIENCE_LEVEL_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Inexperienced</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INEXPERIENCED_OPERATION_COUNT = EXPERIENCE_LEVEL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.IntermediateImpl <em>Intermediate</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.IntermediateImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getIntermediate()
	 * @generated
	 */
	int INTERMEDIATE = 15;

	/**
	 * The number of structural features of the '<em>Intermediate</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERMEDIATE_FEATURE_COUNT = EXPERIENCE_LEVEL_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Intermediate</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERMEDIATE_OPERATION_COUNT = EXPERIENCE_LEVEL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.UsageTimeImpl <em>Usage Time</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.UsageTimeImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getUsageTime()
	 * @generated
	 */
	int USAGE_TIME = 16;

	/**
	 * The feature id for the '<em><b>Usetime</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USAGE_TIME__USETIME = 0;

	/**
	 * The number of structural features of the '<em>Usage Time</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USAGE_TIME_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Usage Time</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USAGE_TIME_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.EnvironmentImpl <em>Environment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.EnvironmentImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getEnvironment()
	 * @generated
	 */
	int ENVIRONMENT = 17;

	/**
	 * The feature id for the '<em><b>Light</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT__LIGHT = 0;

	/**
	 * The feature id for the '<em><b>Time</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT__TIME = 1;

	/**
	 * The feature id for the '<em><b>Activity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT__ACTIVITY = 2;

	/**
	 * The number of structural features of the '<em>Environment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Environment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENVIRONMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.ConnectionSpeedImpl <em>Connection Speed</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.ConnectionSpeedImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getConnectionSpeed()
	 * @generated
	 */
	int CONNECTION_SPEED = 18;

	/**
	 * The number of structural features of the '<em>Connection Speed</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION_SPEED_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Connection Speed</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION_SPEED_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.ThreeGImpl <em>Three G</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.ThreeGImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getThreeG()
	 * @generated
	 */
	int THREE_G = 19;

	/**
	 * The number of structural features of the '<em>Three G</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREE_G_FEATURE_COUNT = CONNECTION_SPEED_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Three G</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREE_G_OPERATION_COUNT = CONNECTION_SPEED_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.TwoGImpl <em>Two G</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.TwoGImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getTwoG()
	 * @generated
	 */
	int TWO_G = 20;

	/**
	 * The number of structural features of the '<em>Two G</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TWO_G_FEATURE_COUNT = CONNECTION_SPEED_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Two G</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TWO_G_OPERATION_COUNT = CONNECTION_SPEED_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.FourGImpl <em>Four G</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.FourGImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getFourG()
	 * @generated
	 */
	int FOUR_G = 21;

	/**
	 * The number of structural features of the '<em>Four G</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOUR_G_FEATURE_COUNT = CONNECTION_SPEED_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Four G</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOUR_G_OPERATION_COUNT = CONNECTION_SPEED_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.ConnectionTypeImpl <em>Connection Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.ConnectionTypeImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getConnectionType()
	 * @generated
	 */
	int CONNECTION_TYPE = 22;

	/**
	 * The feature id for the '<em><b>Wifi</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION_TYPE__WIFI = 0;

	/**
	 * The feature id for the '<em><b>Cellular</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION_TYPE__CELLULAR = 1;

	/**
	 * The number of structural features of the '<em>Connection Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION_TYPE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Connection Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION_TYPE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.WifiImpl <em>Wifi</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.WifiImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getWifi()
	 * @generated
	 */
	int WIFI = 23;

	/**
	 * The number of structural features of the '<em>Wifi</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WIFI_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Wifi</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WIFI_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.CellularImpl <em>Cellular</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.CellularImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getCellular()
	 * @generated
	 */
	int CELLULAR = 24;

	/**
	 * The number of structural features of the '<em>Cellular</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CELLULAR_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Cellular</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CELLULAR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.BatteryLevelImpl <em>Battery Level</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.BatteryLevelImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getBatteryLevel()
	 * @generated
	 */
	int BATTERY_LEVEL = 25;

	/**
	 * The feature id for the '<em><b>Level</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERY_LEVEL__LEVEL = 0;

	/**
	 * The number of structural features of the '<em>Battery Level</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERY_LEVEL_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Battery Level</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERY_LEVEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.ChargingImpl <em>Charging</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.ChargingImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getCharging()
	 * @generated
	 */
	int CHARGING = 26;

	/**
	 * The feature id for the '<em><b>Unit</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARGING__UNIT = 0;

	/**
	 * The number of structural features of the '<em>Charging</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARGING_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Charging</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHARGING_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.AmbientlightImpl <em>Ambientlight</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.AmbientlightImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getAmbientlight()
	 * @generated
	 */
	int AMBIENTLIGHT = 27;

	/**
	 * The feature id for the '<em><b>Low Light</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AMBIENTLIGHT__LOW_LIGHT = 0;

	/**
	 * The feature id for the '<em><b>High Light</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AMBIENTLIGHT__HIGH_LIGHT = 1;

	/**
	 * The feature id for the '<em><b>Normal Light</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AMBIENTLIGHT__NORMAL_LIGHT = 2;

	/**
	 * The number of structural features of the '<em>Ambientlight</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AMBIENTLIGHT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Ambientlight</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AMBIENTLIGHT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.LowLightImpl <em>Low Light</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.LowLightImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getLowLight()
	 * @generated
	 */
	int LOW_LIGHT = 28;

	/**
	 * The number of structural features of the '<em>Low Light</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOW_LIGHT_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Low Light</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOW_LIGHT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.HighLightImpl <em>High Light</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.HighLightImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getHighLight()
	 * @generated
	 */
	int HIGH_LIGHT = 29;

	/**
	 * The number of structural features of the '<em>High Light</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HIGH_LIGHT_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>High Light</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HIGH_LIGHT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.NormalLightImpl <em>Normal Light</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.NormalLightImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getNormalLight()
	 * @generated
	 */
	int NORMAL_LIGHT = 30;

	/**
	 * The number of structural features of the '<em>Normal Light</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NORMAL_LIGHT_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Normal Light</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NORMAL_LIGHT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.TimeImpl <em>Time</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.TimeImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getTime()
	 * @generated
	 */
	int TIME = 31;

	/**
	 * The feature id for the '<em><b>Sun Rise</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME__SUN_RISE = 0;

	/**
	 * The feature id for the '<em><b>Sun Dawn</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME__SUN_DAWN = 1;

	/**
	 * The number of structural features of the '<em>Time</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Time</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIME_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.SunRiseImpl <em>Sun Rise</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.SunRiseImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getSunRise()
	 * @generated
	 */
	int SUN_RISE = 32;

	/**
	 * The number of structural features of the '<em>Sun Rise</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUN_RISE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Sun Rise</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUN_RISE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.SunDawnImpl <em>Sun Dawn</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.SunDawnImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getSunDawn()
	 * @generated
	 */
	int SUN_DAWN = 33;

	/**
	 * The number of structural features of the '<em>Sun Dawn</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUN_DAWN_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Sun Dawn</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUN_DAWN_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.ActivityImpl <em>Activity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.ActivityImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getActivity()
	 * @generated
	 */
	int ACTIVITY = 34;

	/**
	 * The feature id for the '<em><b>Activity Enum</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVITY__ACTIVITY_ENUM = 0;

	/**
	 * The number of structural features of the '<em>Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVITY_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Activity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTIVITY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.PlatformImpl <em>Platform</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.PlatformImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getPlatform()
	 * @generated
	 */
	int PLATFORM = 35;

	/**
	 * The feature id for the '<em><b>Devicetype</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM__DEVICETYPE = 0;

	/**
	 * The feature id for the '<em><b>Batterymode</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM__BATTERYMODE = 1;

	/**
	 * The feature id for the '<em><b>Screen Dim</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM__SCREEN_DIM = 2;

	/**
	 * The feature id for the '<em><b>Hardware</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM__HARDWARE = 3;

	/**
	 * The feature id for the '<em><b>Battery Level</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM__BATTERY_LEVEL = 4;

	/**
	 * The feature id for the '<em><b>Connection Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM__CONNECTION_TYPE = 5;

	/**
	 * The feature id for the '<em><b>Connection Speed</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM__CONNECTION_SPEED = 6;

	/**
	 * The feature id for the '<em><b>Charging</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM__CHARGING = 7;

	/**
	 * The number of structural features of the '<em>Platform</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_FEATURE_COUNT = 8;

	/**
	 * The number of operations of the '<em>Platform</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.DeviceHardwareImpl <em>Device Hardware</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.DeviceHardwareImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getDeviceHardware()
	 * @generated
	 */
	int DEVICE_HARDWARE = 36;

	/**
	 * The number of structural features of the '<em>Device Hardware</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_HARDWARE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Device Hardware</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_HARDWARE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.CameraImpl <em>Camera</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.CameraImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getCamera()
	 * @generated
	 */
	int CAMERA = 37;

	/**
	 * The feature id for the '<em><b>Enable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__ENABLE = DEVICE_HARDWARE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_FEATURE_COUNT = DEVICE_HARDWARE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_OPERATION_COUNT = DEVICE_HARDWARE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.ScreenDimensionImpl <em>Screen Dimension</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.ScreenDimensionImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getScreenDimension()
	 * @generated
	 */
	int SCREEN_DIMENSION = 38;

	/**
	 * The feature id for the '<em><b>Screen Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCREEN_DIMENSION__SCREEN_HEIGHT = 0;

	/**
	 * The feature id for the '<em><b>Screen Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCREEN_DIMENSION__SCREEN_WIDTH = 1;

	/**
	 * The number of structural features of the '<em>Screen Dimension</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCREEN_DIMENSION_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Screen Dimension</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCREEN_DIMENSION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.BatterymodeImpl <em>Batterymode</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.BatterymodeImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getBatterymode()
	 * @generated
	 */
	int BATTERYMODE = 39;

	/**
	 * The number of structural features of the '<em>Batterymode</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERYMODE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Batterymode</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERYMODE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.NormalBatterymodeImpl <em>Normal Batterymode</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.NormalBatterymodeImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getNormalBatterymode()
	 * @generated
	 */
	int NORMAL_BATTERYMODE = 40;

	/**
	 * The number of structural features of the '<em>Normal Batterymode</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NORMAL_BATTERYMODE_FEATURE_COUNT = BATTERYMODE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Normal Batterymode</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NORMAL_BATTERYMODE_OPERATION_COUNT = BATTERYMODE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.LowBatterymodeImpl <em>Low Batterymode</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.LowBatterymodeImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getLowBatterymode()
	 * @generated
	 */
	int LOW_BATTERYMODE = 41;

	/**
	 * The number of structural features of the '<em>Low Batterymode</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOW_BATTERYMODE_FEATURE_COUNT = BATTERYMODE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Low Batterymode</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOW_BATTERYMODE_OPERATION_COUNT = BATTERYMODE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.DevicetypeImpl <em>Devicetype</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.DevicetypeImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getDevicetype()
	 * @generated
	 */
	int DEVICETYPE = 42;

	/**
	 * The number of structural features of the '<em>Devicetype</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICETYPE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Devicetype</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICETYPE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.TabletImpl <em>Tablet</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.TabletImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getTablet()
	 * @generated
	 */
	int TABLET = 43;

	/**
	 * The number of structural features of the '<em>Tablet</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TABLET_FEATURE_COUNT = DEVICETYPE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Tablet</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TABLET_OPERATION_COUNT = DEVICETYPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.impl.SmartphoneImpl <em>Smartphone</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.impl.SmartphoneImpl
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getSmartphone()
	 * @generated
	 */
	int SMARTPHONE = 44;

	/**
	 * The number of structural features of the '<em>Smartphone</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMARTPHONE_FEATURE_COUNT = DEVICETYPE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Smartphone</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMARTPHONE_OPERATION_COUNT = DEVICETYPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UserEnviro.BadEnum <em>Bad Enum</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.BadEnum
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getBadEnum()
	 * @generated
	 */
	int BAD_ENUM = 45;

	/**
	 * The meta object id for the '{@link UserEnviro.ActivityEnum <em>Activity Enum</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UserEnviro.ActivityEnum
	 * @see UserEnviro.impl.UserEnviroPackageImpl#getActivityEnum()
	 * @generated
	 */
	int ACTIVITY_ENUM = 46;

	/**
	 * Returns the meta object for class '{@link UserEnviro.Context <em>Context</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Context</em>'.
	 * @see UserEnviro.Context
	 * @generated
	 */
	EClass getContext();

	/**
	 * Returns the meta object for the containment reference list '{@link UserEnviro.Context#getUsercontext <em>Usercontext</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Usercontext</em>'.
	 * @see UserEnviro.Context#getUsercontext()
	 * @see #getContext()
	 * @generated
	 */
	EReference getContext_Usercontext();

	/**
	 * Returns the meta object for the containment reference '{@link UserEnviro.Context#getEnvirocontext <em>Envirocontext</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Envirocontext</em>'.
	 * @see UserEnviro.Context#getEnvirocontext()
	 * @see #getContext()
	 * @generated
	 */
	EReference getContext_Envirocontext();

	/**
	 * Returns the meta object for the containment reference '{@link UserEnviro.Context#getPlatcontext <em>Platcontext</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Platcontext</em>'.
	 * @see UserEnviro.Context#getPlatcontext()
	 * @see #getContext()
	 * @generated
	 */
	EReference getContext_Platcontext();

	/**
	 * Returns the meta object for class '{@link UserEnviro.User <em>User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>User</em>'.
	 * @see UserEnviro.User
	 * @generated
	 */
	EClass getUser();

	/**
	 * Returns the meta object for the containment reference '{@link UserEnviro.User#getMood <em>Mood</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Mood</em>'.
	 * @see UserEnviro.User#getMood()
	 * @see #getUser()
	 * @generated
	 */
	EReference getUser_Mood();

	/**
	 * Returns the meta object for the containment reference '{@link UserEnviro.User#getExp <em>Exp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Exp</em>'.
	 * @see UserEnviro.User#getExp()
	 * @see #getUser()
	 * @generated
	 */
	EReference getUser_Exp();

	/**
	 * Returns the meta object for the reference '{@link UserEnviro.User#getTime <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Time</em>'.
	 * @see UserEnviro.User#getTime()
	 * @see #getUser()
	 * @generated
	 */
	EReference getUser_Time();

	/**
	 * Returns the meta object for the reference '{@link UserEnviro.User#getVision <em>Vision</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Vision</em>'.
	 * @see UserEnviro.User#getVision()
	 * @see #getUser()
	 * @generated
	 */
	EReference getUser_Vision();

	/**
	 * Returns the meta object for the attribute '{@link UserEnviro.User#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see UserEnviro.User#getName()
	 * @see #getUser()
	 * @generated
	 */
	EAttribute getUser_Name();

	/**
	 * Returns the meta object for the attribute '{@link UserEnviro.User#getAge <em>Age</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Age</em>'.
	 * @see UserEnviro.User#getAge()
	 * @see #getUser()
	 * @generated
	 */
	EAttribute getUser_Age();

	/**
	 * Returns the meta object for class '{@link UserEnviro.OldAgeUser <em>Old Age User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Old Age User</em>'.
	 * @see UserEnviro.OldAgeUser
	 * @generated
	 */
	EClass getOldAgeUser();

	/**
	 * Returns the meta object for class '{@link UserEnviro.MiddleAgeUser <em>Middle Age User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Middle Age User</em>'.
	 * @see UserEnviro.MiddleAgeUser
	 * @generated
	 */
	EClass getMiddleAgeUser();

	/**
	 * Returns the meta object for class '{@link UserEnviro.YoungerUser <em>Younger User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Younger User</em>'.
	 * @see UserEnviro.YoungerUser
	 * @generated
	 */
	EClass getYoungerUser();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Vision <em>Vision</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Vision</em>'.
	 * @see UserEnviro.Vision
	 * @generated
	 */
	EClass getVision();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Normalvision <em>Normalvision</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Normalvision</em>'.
	 * @see UserEnviro.Normalvision
	 * @generated
	 */
	EClass getNormalvision();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Reducedvision <em>Reducedvision</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Reducedvision</em>'.
	 * @see UserEnviro.Reducedvision
	 * @generated
	 */
	EClass getReducedvision();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Mood <em>Mood</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Mood</em>'.
	 * @see UserEnviro.Mood
	 * @generated
	 */
	EClass getMood();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Badmood <em>Badmood</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Badmood</em>'.
	 * @see UserEnviro.Badmood
	 * @generated
	 */
	EClass getBadmood();

	/**
	 * Returns the meta object for the attribute '{@link UserEnviro.Badmood#getBadEnum <em>Bad Enum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bad Enum</em>'.
	 * @see UserEnviro.Badmood#getBadEnum()
	 * @see #getBadmood()
	 * @generated
	 */
	EAttribute getBadmood_BadEnum();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Goodmood <em>Goodmood</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Goodmood</em>'.
	 * @see UserEnviro.Goodmood
	 * @generated
	 */
	EClass getGoodmood();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Neutralmood <em>Neutralmood</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Neutralmood</em>'.
	 * @see UserEnviro.Neutralmood
	 * @generated
	 */
	EClass getNeutralmood();

	/**
	 * Returns the meta object for class '{@link UserEnviro.ExperienceLevel <em>Experience Level</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Experience Level</em>'.
	 * @see UserEnviro.ExperienceLevel
	 * @generated
	 */
	EClass getExperienceLevel();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Experienced <em>Experienced</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Experienced</em>'.
	 * @see UserEnviro.Experienced
	 * @generated
	 */
	EClass getExperienced();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Inexperienced <em>Inexperienced</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Inexperienced</em>'.
	 * @see UserEnviro.Inexperienced
	 * @generated
	 */
	EClass getInexperienced();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Intermediate <em>Intermediate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Intermediate</em>'.
	 * @see UserEnviro.Intermediate
	 * @generated
	 */
	EClass getIntermediate();

	/**
	 * Returns the meta object for class '{@link UserEnviro.UsageTime <em>Usage Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Usage Time</em>'.
	 * @see UserEnviro.UsageTime
	 * @generated
	 */
	EClass getUsageTime();

	/**
	 * Returns the meta object for the attribute '{@link UserEnviro.UsageTime#getUsetime <em>Usetime</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Usetime</em>'.
	 * @see UserEnviro.UsageTime#getUsetime()
	 * @see #getUsageTime()
	 * @generated
	 */
	EAttribute getUsageTime_Usetime();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Environment <em>Environment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Environment</em>'.
	 * @see UserEnviro.Environment
	 * @generated
	 */
	EClass getEnvironment();

	/**
	 * Returns the meta object for the reference '{@link UserEnviro.Environment#getLight <em>Light</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Light</em>'.
	 * @see UserEnviro.Environment#getLight()
	 * @see #getEnvironment()
	 * @generated
	 */
	EReference getEnvironment_Light();

	/**
	 * Returns the meta object for the reference '{@link UserEnviro.Environment#getTime <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Time</em>'.
	 * @see UserEnviro.Environment#getTime()
	 * @see #getEnvironment()
	 * @generated
	 */
	EReference getEnvironment_Time();

	/**
	 * Returns the meta object for the reference '{@link UserEnviro.Environment#getActivity <em>Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Activity</em>'.
	 * @see UserEnviro.Environment#getActivity()
	 * @see #getEnvironment()
	 * @generated
	 */
	EReference getEnvironment_Activity();

	/**
	 * Returns the meta object for class '{@link UserEnviro.ConnectionSpeed <em>Connection Speed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connection Speed</em>'.
	 * @see UserEnviro.ConnectionSpeed
	 * @generated
	 */
	EClass getConnectionSpeed();

	/**
	 * Returns the meta object for class '{@link UserEnviro.ThreeG <em>Three G</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Three G</em>'.
	 * @see UserEnviro.ThreeG
	 * @generated
	 */
	EClass getThreeG();

	/**
	 * Returns the meta object for class '{@link UserEnviro.TwoG <em>Two G</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Two G</em>'.
	 * @see UserEnviro.TwoG
	 * @generated
	 */
	EClass getTwoG();

	/**
	 * Returns the meta object for class '{@link UserEnviro.FourG <em>Four G</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Four G</em>'.
	 * @see UserEnviro.FourG
	 * @generated
	 */
	EClass getFourG();

	/**
	 * Returns the meta object for class '{@link UserEnviro.ConnectionType <em>Connection Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connection Type</em>'.
	 * @see UserEnviro.ConnectionType
	 * @generated
	 */
	EClass getConnectionType();

	/**
	 * Returns the meta object for the reference '{@link UserEnviro.ConnectionType#getWifi <em>Wifi</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Wifi</em>'.
	 * @see UserEnviro.ConnectionType#getWifi()
	 * @see #getConnectionType()
	 * @generated
	 */
	EReference getConnectionType_Wifi();

	/**
	 * Returns the meta object for the reference '{@link UserEnviro.ConnectionType#getCellular <em>Cellular</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cellular</em>'.
	 * @see UserEnviro.ConnectionType#getCellular()
	 * @see #getConnectionType()
	 * @generated
	 */
	EReference getConnectionType_Cellular();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Wifi <em>Wifi</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Wifi</em>'.
	 * @see UserEnviro.Wifi
	 * @generated
	 */
	EClass getWifi();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Cellular <em>Cellular</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cellular</em>'.
	 * @see UserEnviro.Cellular
	 * @generated
	 */
	EClass getCellular();

	/**
	 * Returns the meta object for class '{@link UserEnviro.BatteryLevel <em>Battery Level</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Battery Level</em>'.
	 * @see UserEnviro.BatteryLevel
	 * @generated
	 */
	EClass getBatteryLevel();

	/**
	 * Returns the meta object for the attribute '{@link UserEnviro.BatteryLevel#getLevel <em>Level</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Level</em>'.
	 * @see UserEnviro.BatteryLevel#getLevel()
	 * @see #getBatteryLevel()
	 * @generated
	 */
	EAttribute getBatteryLevel_Level();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Charging <em>Charging</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Charging</em>'.
	 * @see UserEnviro.Charging
	 * @generated
	 */
	EClass getCharging();

	/**
	 * Returns the meta object for the attribute '{@link UserEnviro.Charging#isUnit <em>Unit</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Unit</em>'.
	 * @see UserEnviro.Charging#isUnit()
	 * @see #getCharging()
	 * @generated
	 */
	EAttribute getCharging_Unit();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Ambientlight <em>Ambientlight</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ambientlight</em>'.
	 * @see UserEnviro.Ambientlight
	 * @generated
	 */
	EClass getAmbientlight();

	/**
	 * Returns the meta object for the containment reference '{@link UserEnviro.Ambientlight#getLowLight <em>Low Light</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Low Light</em>'.
	 * @see UserEnviro.Ambientlight#getLowLight()
	 * @see #getAmbientlight()
	 * @generated
	 */
	EReference getAmbientlight_LowLight();

	/**
	 * Returns the meta object for the containment reference '{@link UserEnviro.Ambientlight#getHighLight <em>High Light</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>High Light</em>'.
	 * @see UserEnviro.Ambientlight#getHighLight()
	 * @see #getAmbientlight()
	 * @generated
	 */
	EReference getAmbientlight_HighLight();

	/**
	 * Returns the meta object for the containment reference '{@link UserEnviro.Ambientlight#getNormalLight <em>Normal Light</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Normal Light</em>'.
	 * @see UserEnviro.Ambientlight#getNormalLight()
	 * @see #getAmbientlight()
	 * @generated
	 */
	EReference getAmbientlight_NormalLight();

	/**
	 * Returns the meta object for class '{@link UserEnviro.LowLight <em>Low Light</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Low Light</em>'.
	 * @see UserEnviro.LowLight
	 * @generated
	 */
	EClass getLowLight();

	/**
	 * Returns the meta object for class '{@link UserEnviro.HighLight <em>High Light</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>High Light</em>'.
	 * @see UserEnviro.HighLight
	 * @generated
	 */
	EClass getHighLight();

	/**
	 * Returns the meta object for class '{@link UserEnviro.NormalLight <em>Normal Light</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Normal Light</em>'.
	 * @see UserEnviro.NormalLight
	 * @generated
	 */
	EClass getNormalLight();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Time <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Time</em>'.
	 * @see UserEnviro.Time
	 * @generated
	 */
	EClass getTime();

	/**
	 * Returns the meta object for the reference '{@link UserEnviro.Time#getSunRise <em>Sun Rise</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Sun Rise</em>'.
	 * @see UserEnviro.Time#getSunRise()
	 * @see #getTime()
	 * @generated
	 */
	EReference getTime_SunRise();

	/**
	 * Returns the meta object for the reference '{@link UserEnviro.Time#getSunDawn <em>Sun Dawn</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Sun Dawn</em>'.
	 * @see UserEnviro.Time#getSunDawn()
	 * @see #getTime()
	 * @generated
	 */
	EReference getTime_SunDawn();

	/**
	 * Returns the meta object for class '{@link UserEnviro.SunRise <em>Sun Rise</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sun Rise</em>'.
	 * @see UserEnviro.SunRise
	 * @generated
	 */
	EClass getSunRise();

	/**
	 * Returns the meta object for class '{@link UserEnviro.SunDawn <em>Sun Dawn</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sun Dawn</em>'.
	 * @see UserEnviro.SunDawn
	 * @generated
	 */
	EClass getSunDawn();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Activity <em>Activity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Activity</em>'.
	 * @see UserEnviro.Activity
	 * @generated
	 */
	EClass getActivity();

	/**
	 * Returns the meta object for the attribute '{@link UserEnviro.Activity#getActivityEnum <em>Activity Enum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Activity Enum</em>'.
	 * @see UserEnviro.Activity#getActivityEnum()
	 * @see #getActivity()
	 * @generated
	 */
	EAttribute getActivity_ActivityEnum();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Platform <em>Platform</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Platform</em>'.
	 * @see UserEnviro.Platform
	 * @generated
	 */
	EClass getPlatform();

	/**
	 * Returns the meta object for the containment reference '{@link UserEnviro.Platform#getDevicetype <em>Devicetype</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Devicetype</em>'.
	 * @see UserEnviro.Platform#getDevicetype()
	 * @see #getPlatform()
	 * @generated
	 */
	EReference getPlatform_Devicetype();

	/**
	 * Returns the meta object for the reference '{@link UserEnviro.Platform#getBatterymode <em>Batterymode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Batterymode</em>'.
	 * @see UserEnviro.Platform#getBatterymode()
	 * @see #getPlatform()
	 * @generated
	 */
	EReference getPlatform_Batterymode();

	/**
	 * Returns the meta object for the reference '{@link UserEnviro.Platform#getScreenDim <em>Screen Dim</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Screen Dim</em>'.
	 * @see UserEnviro.Platform#getScreenDim()
	 * @see #getPlatform()
	 * @generated
	 */
	EReference getPlatform_ScreenDim();

	/**
	 * Returns the meta object for the containment reference '{@link UserEnviro.Platform#getHardware <em>Hardware</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Hardware</em>'.
	 * @see UserEnviro.Platform#getHardware()
	 * @see #getPlatform()
	 * @generated
	 */
	EReference getPlatform_Hardware();

	/**
	 * Returns the meta object for the reference '{@link UserEnviro.Platform#getBatteryLevel <em>Battery Level</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Battery Level</em>'.
	 * @see UserEnviro.Platform#getBatteryLevel()
	 * @see #getPlatform()
	 * @generated
	 */
	EReference getPlatform_BatteryLevel();

	/**
	 * Returns the meta object for the containment reference '{@link UserEnviro.Platform#getConnectionType <em>Connection Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Connection Type</em>'.
	 * @see UserEnviro.Platform#getConnectionType()
	 * @see #getPlatform()
	 * @generated
	 */
	EReference getPlatform_ConnectionType();

	/**
	 * Returns the meta object for the containment reference '{@link UserEnviro.Platform#getConnectionSpeed <em>Connection Speed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Connection Speed</em>'.
	 * @see UserEnviro.Platform#getConnectionSpeed()
	 * @see #getPlatform()
	 * @generated
	 */
	EReference getPlatform_ConnectionSpeed();

	/**
	 * Returns the meta object for the reference '{@link UserEnviro.Platform#getCharging <em>Charging</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Charging</em>'.
	 * @see UserEnviro.Platform#getCharging()
	 * @see #getPlatform()
	 * @generated
	 */
	EReference getPlatform_Charging();

	/**
	 * Returns the meta object for class '{@link UserEnviro.DeviceHardware <em>Device Hardware</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Device Hardware</em>'.
	 * @see UserEnviro.DeviceHardware
	 * @generated
	 */
	EClass getDeviceHardware();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Camera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Camera</em>'.
	 * @see UserEnviro.Camera
	 * @generated
	 */
	EClass getCamera();

	/**
	 * Returns the meta object for the attribute '{@link UserEnviro.Camera#isEnable <em>Enable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Enable</em>'.
	 * @see UserEnviro.Camera#isEnable()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Enable();

	/**
	 * Returns the meta object for class '{@link UserEnviro.ScreenDimension <em>Screen Dimension</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Screen Dimension</em>'.
	 * @see UserEnviro.ScreenDimension
	 * @generated
	 */
	EClass getScreenDimension();

	/**
	 * Returns the meta object for the attribute '{@link UserEnviro.ScreenDimension#getScreenHeight <em>Screen Height</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Screen Height</em>'.
	 * @see UserEnviro.ScreenDimension#getScreenHeight()
	 * @see #getScreenDimension()
	 * @generated
	 */
	EAttribute getScreenDimension_ScreenHeight();

	/**
	 * Returns the meta object for the attribute '{@link UserEnviro.ScreenDimension#getScreenWidth <em>Screen Width</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Screen Width</em>'.
	 * @see UserEnviro.ScreenDimension#getScreenWidth()
	 * @see #getScreenDimension()
	 * @generated
	 */
	EAttribute getScreenDimension_ScreenWidth();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Batterymode <em>Batterymode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Batterymode</em>'.
	 * @see UserEnviro.Batterymode
	 * @generated
	 */
	EClass getBatterymode();

	/**
	 * Returns the meta object for class '{@link UserEnviro.NormalBatterymode <em>Normal Batterymode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Normal Batterymode</em>'.
	 * @see UserEnviro.NormalBatterymode
	 * @generated
	 */
	EClass getNormalBatterymode();

	/**
	 * Returns the meta object for class '{@link UserEnviro.LowBatterymode <em>Low Batterymode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Low Batterymode</em>'.
	 * @see UserEnviro.LowBatterymode
	 * @generated
	 */
	EClass getLowBatterymode();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Devicetype <em>Devicetype</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Devicetype</em>'.
	 * @see UserEnviro.Devicetype
	 * @generated
	 */
	EClass getDevicetype();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Tablet <em>Tablet</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tablet</em>'.
	 * @see UserEnviro.Tablet
	 * @generated
	 */
	EClass getTablet();

	/**
	 * Returns the meta object for class '{@link UserEnviro.Smartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Smartphone</em>'.
	 * @see UserEnviro.Smartphone
	 * @generated
	 */
	EClass getSmartphone();

	/**
	 * Returns the meta object for enum '{@link UserEnviro.BadEnum <em>Bad Enum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Bad Enum</em>'.
	 * @see UserEnviro.BadEnum
	 * @generated
	 */
	EEnum getBadEnum();

	/**
	 * Returns the meta object for enum '{@link UserEnviro.ActivityEnum <em>Activity Enum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Activity Enum</em>'.
	 * @see UserEnviro.ActivityEnum
	 * @generated
	 */
	EEnum getActivityEnum();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	UserEnviroFactory getUserEnviroFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link UserEnviro.impl.ContextImpl <em>Context</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.ContextImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getContext()
		 * @generated
		 */
		EClass CONTEXT = eINSTANCE.getContext();

		/**
		 * The meta object literal for the '<em><b>Usercontext</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTEXT__USERCONTEXT = eINSTANCE.getContext_Usercontext();

		/**
		 * The meta object literal for the '<em><b>Envirocontext</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTEXT__ENVIROCONTEXT = eINSTANCE.getContext_Envirocontext();

		/**
		 * The meta object literal for the '<em><b>Platcontext</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTEXT__PLATCONTEXT = eINSTANCE.getContext_Platcontext();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.UserImpl <em>User</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.UserImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getUser()
		 * @generated
		 */
		EClass USER = eINSTANCE.getUser();

		/**
		 * The meta object literal for the '<em><b>Mood</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USER__MOOD = eINSTANCE.getUser_Mood();

		/**
		 * The meta object literal for the '<em><b>Exp</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USER__EXP = eINSTANCE.getUser_Exp();

		/**
		 * The meta object literal for the '<em><b>Time</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USER__TIME = eINSTANCE.getUser_Time();

		/**
		 * The meta object literal for the '<em><b>Vision</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference USER__VISION = eINSTANCE.getUser_Vision();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USER__NAME = eINSTANCE.getUser_Name();

		/**
		 * The meta object literal for the '<em><b>Age</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USER__AGE = eINSTANCE.getUser_Age();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.OldAgeUserImpl <em>Old Age User</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.OldAgeUserImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getOldAgeUser()
		 * @generated
		 */
		EClass OLD_AGE_USER = eINSTANCE.getOldAgeUser();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.MiddleAgeUserImpl <em>Middle Age User</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.MiddleAgeUserImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getMiddleAgeUser()
		 * @generated
		 */
		EClass MIDDLE_AGE_USER = eINSTANCE.getMiddleAgeUser();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.YoungerUserImpl <em>Younger User</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.YoungerUserImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getYoungerUser()
		 * @generated
		 */
		EClass YOUNGER_USER = eINSTANCE.getYoungerUser();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.VisionImpl <em>Vision</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.VisionImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getVision()
		 * @generated
		 */
		EClass VISION = eINSTANCE.getVision();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.NormalvisionImpl <em>Normalvision</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.NormalvisionImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getNormalvision()
		 * @generated
		 */
		EClass NORMALVISION = eINSTANCE.getNormalvision();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.ReducedvisionImpl <em>Reducedvision</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.ReducedvisionImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getReducedvision()
		 * @generated
		 */
		EClass REDUCEDVISION = eINSTANCE.getReducedvision();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.MoodImpl <em>Mood</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.MoodImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getMood()
		 * @generated
		 */
		EClass MOOD = eINSTANCE.getMood();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.BadmoodImpl <em>Badmood</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.BadmoodImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getBadmood()
		 * @generated
		 */
		EClass BADMOOD = eINSTANCE.getBadmood();

		/**
		 * The meta object literal for the '<em><b>Bad Enum</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BADMOOD__BAD_ENUM = eINSTANCE.getBadmood_BadEnum();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.GoodmoodImpl <em>Goodmood</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.GoodmoodImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getGoodmood()
		 * @generated
		 */
		EClass GOODMOOD = eINSTANCE.getGoodmood();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.NeutralmoodImpl <em>Neutralmood</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.NeutralmoodImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getNeutralmood()
		 * @generated
		 */
		EClass NEUTRALMOOD = eINSTANCE.getNeutralmood();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.ExperienceLevelImpl <em>Experience Level</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.ExperienceLevelImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getExperienceLevel()
		 * @generated
		 */
		EClass EXPERIENCE_LEVEL = eINSTANCE.getExperienceLevel();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.ExperiencedImpl <em>Experienced</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.ExperiencedImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getExperienced()
		 * @generated
		 */
		EClass EXPERIENCED = eINSTANCE.getExperienced();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.InexperiencedImpl <em>Inexperienced</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.InexperiencedImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getInexperienced()
		 * @generated
		 */
		EClass INEXPERIENCED = eINSTANCE.getInexperienced();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.IntermediateImpl <em>Intermediate</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.IntermediateImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getIntermediate()
		 * @generated
		 */
		EClass INTERMEDIATE = eINSTANCE.getIntermediate();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.UsageTimeImpl <em>Usage Time</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.UsageTimeImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getUsageTime()
		 * @generated
		 */
		EClass USAGE_TIME = eINSTANCE.getUsageTime();

		/**
		 * The meta object literal for the '<em><b>Usetime</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USAGE_TIME__USETIME = eINSTANCE.getUsageTime_Usetime();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.EnvironmentImpl <em>Environment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.EnvironmentImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getEnvironment()
		 * @generated
		 */
		EClass ENVIRONMENT = eINSTANCE.getEnvironment();

		/**
		 * The meta object literal for the '<em><b>Light</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENVIRONMENT__LIGHT = eINSTANCE.getEnvironment_Light();

		/**
		 * The meta object literal for the '<em><b>Time</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENVIRONMENT__TIME = eINSTANCE.getEnvironment_Time();

		/**
		 * The meta object literal for the '<em><b>Activity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENVIRONMENT__ACTIVITY = eINSTANCE.getEnvironment_Activity();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.ConnectionSpeedImpl <em>Connection Speed</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.ConnectionSpeedImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getConnectionSpeed()
		 * @generated
		 */
		EClass CONNECTION_SPEED = eINSTANCE.getConnectionSpeed();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.ThreeGImpl <em>Three G</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.ThreeGImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getThreeG()
		 * @generated
		 */
		EClass THREE_G = eINSTANCE.getThreeG();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.TwoGImpl <em>Two G</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.TwoGImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getTwoG()
		 * @generated
		 */
		EClass TWO_G = eINSTANCE.getTwoG();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.FourGImpl <em>Four G</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.FourGImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getFourG()
		 * @generated
		 */
		EClass FOUR_G = eINSTANCE.getFourG();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.ConnectionTypeImpl <em>Connection Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.ConnectionTypeImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getConnectionType()
		 * @generated
		 */
		EClass CONNECTION_TYPE = eINSTANCE.getConnectionType();

		/**
		 * The meta object literal for the '<em><b>Wifi</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTION_TYPE__WIFI = eINSTANCE.getConnectionType_Wifi();

		/**
		 * The meta object literal for the '<em><b>Cellular</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTION_TYPE__CELLULAR = eINSTANCE.getConnectionType_Cellular();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.WifiImpl <em>Wifi</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.WifiImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getWifi()
		 * @generated
		 */
		EClass WIFI = eINSTANCE.getWifi();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.CellularImpl <em>Cellular</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.CellularImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getCellular()
		 * @generated
		 */
		EClass CELLULAR = eINSTANCE.getCellular();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.BatteryLevelImpl <em>Battery Level</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.BatteryLevelImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getBatteryLevel()
		 * @generated
		 */
		EClass BATTERY_LEVEL = eINSTANCE.getBatteryLevel();

		/**
		 * The meta object literal for the '<em><b>Level</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BATTERY_LEVEL__LEVEL = eINSTANCE.getBatteryLevel_Level();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.ChargingImpl <em>Charging</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.ChargingImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getCharging()
		 * @generated
		 */
		EClass CHARGING = eINSTANCE.getCharging();

		/**
		 * The meta object literal for the '<em><b>Unit</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CHARGING__UNIT = eINSTANCE.getCharging_Unit();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.AmbientlightImpl <em>Ambientlight</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.AmbientlightImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getAmbientlight()
		 * @generated
		 */
		EClass AMBIENTLIGHT = eINSTANCE.getAmbientlight();

		/**
		 * The meta object literal for the '<em><b>Low Light</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AMBIENTLIGHT__LOW_LIGHT = eINSTANCE.getAmbientlight_LowLight();

		/**
		 * The meta object literal for the '<em><b>High Light</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AMBIENTLIGHT__HIGH_LIGHT = eINSTANCE.getAmbientlight_HighLight();

		/**
		 * The meta object literal for the '<em><b>Normal Light</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AMBIENTLIGHT__NORMAL_LIGHT = eINSTANCE.getAmbientlight_NormalLight();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.LowLightImpl <em>Low Light</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.LowLightImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getLowLight()
		 * @generated
		 */
		EClass LOW_LIGHT = eINSTANCE.getLowLight();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.HighLightImpl <em>High Light</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.HighLightImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getHighLight()
		 * @generated
		 */
		EClass HIGH_LIGHT = eINSTANCE.getHighLight();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.NormalLightImpl <em>Normal Light</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.NormalLightImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getNormalLight()
		 * @generated
		 */
		EClass NORMAL_LIGHT = eINSTANCE.getNormalLight();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.TimeImpl <em>Time</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.TimeImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getTime()
		 * @generated
		 */
		EClass TIME = eINSTANCE.getTime();

		/**
		 * The meta object literal for the '<em><b>Sun Rise</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TIME__SUN_RISE = eINSTANCE.getTime_SunRise();

		/**
		 * The meta object literal for the '<em><b>Sun Dawn</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TIME__SUN_DAWN = eINSTANCE.getTime_SunDawn();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.SunRiseImpl <em>Sun Rise</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.SunRiseImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getSunRise()
		 * @generated
		 */
		EClass SUN_RISE = eINSTANCE.getSunRise();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.SunDawnImpl <em>Sun Dawn</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.SunDawnImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getSunDawn()
		 * @generated
		 */
		EClass SUN_DAWN = eINSTANCE.getSunDawn();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.ActivityImpl <em>Activity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.ActivityImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getActivity()
		 * @generated
		 */
		EClass ACTIVITY = eINSTANCE.getActivity();

		/**
		 * The meta object literal for the '<em><b>Activity Enum</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTIVITY__ACTIVITY_ENUM = eINSTANCE.getActivity_ActivityEnum();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.PlatformImpl <em>Platform</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.PlatformImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getPlatform()
		 * @generated
		 */
		EClass PLATFORM = eINSTANCE.getPlatform();

		/**
		 * The meta object literal for the '<em><b>Devicetype</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLATFORM__DEVICETYPE = eINSTANCE.getPlatform_Devicetype();

		/**
		 * The meta object literal for the '<em><b>Batterymode</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLATFORM__BATTERYMODE = eINSTANCE.getPlatform_Batterymode();

		/**
		 * The meta object literal for the '<em><b>Screen Dim</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLATFORM__SCREEN_DIM = eINSTANCE.getPlatform_ScreenDim();

		/**
		 * The meta object literal for the '<em><b>Hardware</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLATFORM__HARDWARE = eINSTANCE.getPlatform_Hardware();

		/**
		 * The meta object literal for the '<em><b>Battery Level</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLATFORM__BATTERY_LEVEL = eINSTANCE.getPlatform_BatteryLevel();

		/**
		 * The meta object literal for the '<em><b>Connection Type</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLATFORM__CONNECTION_TYPE = eINSTANCE.getPlatform_ConnectionType();

		/**
		 * The meta object literal for the '<em><b>Connection Speed</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLATFORM__CONNECTION_SPEED = eINSTANCE.getPlatform_ConnectionSpeed();

		/**
		 * The meta object literal for the '<em><b>Charging</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLATFORM__CHARGING = eINSTANCE.getPlatform_Charging();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.DeviceHardwareImpl <em>Device Hardware</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.DeviceHardwareImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getDeviceHardware()
		 * @generated
		 */
		EClass DEVICE_HARDWARE = eINSTANCE.getDeviceHardware();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.CameraImpl <em>Camera</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.CameraImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getCamera()
		 * @generated
		 */
		EClass CAMERA = eINSTANCE.getCamera();

		/**
		 * The meta object literal for the '<em><b>Enable</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__ENABLE = eINSTANCE.getCamera_Enable();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.ScreenDimensionImpl <em>Screen Dimension</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.ScreenDimensionImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getScreenDimension()
		 * @generated
		 */
		EClass SCREEN_DIMENSION = eINSTANCE.getScreenDimension();

		/**
		 * The meta object literal for the '<em><b>Screen Height</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SCREEN_DIMENSION__SCREEN_HEIGHT = eINSTANCE.getScreenDimension_ScreenHeight();

		/**
		 * The meta object literal for the '<em><b>Screen Width</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SCREEN_DIMENSION__SCREEN_WIDTH = eINSTANCE.getScreenDimension_ScreenWidth();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.BatterymodeImpl <em>Batterymode</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.BatterymodeImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getBatterymode()
		 * @generated
		 */
		EClass BATTERYMODE = eINSTANCE.getBatterymode();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.NormalBatterymodeImpl <em>Normal Batterymode</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.NormalBatterymodeImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getNormalBatterymode()
		 * @generated
		 */
		EClass NORMAL_BATTERYMODE = eINSTANCE.getNormalBatterymode();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.LowBatterymodeImpl <em>Low Batterymode</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.LowBatterymodeImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getLowBatterymode()
		 * @generated
		 */
		EClass LOW_BATTERYMODE = eINSTANCE.getLowBatterymode();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.DevicetypeImpl <em>Devicetype</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.DevicetypeImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getDevicetype()
		 * @generated
		 */
		EClass DEVICETYPE = eINSTANCE.getDevicetype();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.TabletImpl <em>Tablet</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.TabletImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getTablet()
		 * @generated
		 */
		EClass TABLET = eINSTANCE.getTablet();

		/**
		 * The meta object literal for the '{@link UserEnviro.impl.SmartphoneImpl <em>Smartphone</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.impl.SmartphoneImpl
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getSmartphone()
		 * @generated
		 */
		EClass SMARTPHONE = eINSTANCE.getSmartphone();

		/**
		 * The meta object literal for the '{@link UserEnviro.BadEnum <em>Bad Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.BadEnum
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getBadEnum()
		 * @generated
		 */
		EEnum BAD_ENUM = eINSTANCE.getBadEnum();

		/**
		 * The meta object literal for the '{@link UserEnviro.ActivityEnum <em>Activity Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UserEnviro.ActivityEnum
		 * @see UserEnviro.impl.UserEnviroPackageImpl#getActivityEnum()
		 * @generated
		 */
		EEnum ACTIVITY_ENUM = eINSTANCE.getActivityEnum();

	}

} //UserEnviroPackage
