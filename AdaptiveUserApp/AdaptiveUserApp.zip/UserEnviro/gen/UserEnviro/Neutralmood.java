/**
 */
package UserEnviro;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Neutralmood</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getNeutralmood()
 * @model
 * @generated
 */
public interface Neutralmood extends Mood { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Neutralmood
