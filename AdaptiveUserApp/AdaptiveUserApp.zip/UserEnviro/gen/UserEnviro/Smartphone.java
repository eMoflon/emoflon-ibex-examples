/**
 */
package UserEnviro;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Smartphone</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getSmartphone()
 * @model
 * @generated
 */
public interface Smartphone extends Devicetype { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Smartphone
