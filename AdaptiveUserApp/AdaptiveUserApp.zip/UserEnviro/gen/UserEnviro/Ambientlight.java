/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ambientlight</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UserEnviro.Ambientlight#getLowLight <em>Low Light</em>}</li>
 *   <li>{@link UserEnviro.Ambientlight#getHighLight <em>High Light</em>}</li>
 *   <li>{@link UserEnviro.Ambientlight#getNormalLight <em>Normal Light</em>}</li>
 * </ul>
 * </p>
 *
 * @see UserEnviro.UserEnviroPackage#getAmbientlight()
 * @model
 * @generated
 */
public interface Ambientlight extends EObject {
	/**
	 * Returns the value of the '<em><b>Low Light</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Low Light</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Low Light</em>' containment reference.
	 * @see #setLowLight(LowLight)
	 * @see UserEnviro.UserEnviroPackage#getAmbientlight_LowLight()
	 * @model containment="true"
	 * @generated
	 */
	LowLight getLowLight();

	/**
	 * Sets the value of the '{@link UserEnviro.Ambientlight#getLowLight <em>Low Light</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Low Light</em>' containment reference.
	 * @see #getLowLight()
	 * @generated
	 */
	void setLowLight(LowLight value);

	/**
	 * Returns the value of the '<em><b>High Light</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>High Light</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>High Light</em>' containment reference.
	 * @see #setHighLight(HighLight)
	 * @see UserEnviro.UserEnviroPackage#getAmbientlight_HighLight()
	 * @model containment="true"
	 * @generated
	 */
	HighLight getHighLight();

	/**
	 * Sets the value of the '{@link UserEnviro.Ambientlight#getHighLight <em>High Light</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>High Light</em>' containment reference.
	 * @see #getHighLight()
	 * @generated
	 */
	void setHighLight(HighLight value);

	/**
	 * Returns the value of the '<em><b>Normal Light</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Normal Light</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Normal Light</em>' containment reference.
	 * @see #setNormalLight(NormalLight)
	 * @see UserEnviro.UserEnviroPackage#getAmbientlight_NormalLight()
	 * @model containment="true"
	 * @generated
	 */
	NormalLight getNormalLight();

	/**
	 * Sets the value of the '{@link UserEnviro.Ambientlight#getNormalLight <em>Normal Light</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Normal Light</em>' containment reference.
	 * @see #getNormalLight()
	 * @generated
	 */
	void setNormalLight(NormalLight value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Ambientlight
