/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Low Light</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getLowLight()
 * @model
 * @generated
 */
public interface LowLight extends EObject { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // LowLight
