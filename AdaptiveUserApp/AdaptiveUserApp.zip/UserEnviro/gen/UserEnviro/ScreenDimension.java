/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Screen Dimension</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UserEnviro.ScreenDimension#getScreenHeight <em>Screen Height</em>}</li>
 *   <li>{@link UserEnviro.ScreenDimension#getScreenWidth <em>Screen Width</em>}</li>
 * </ul>
 * </p>
 *
 * @see UserEnviro.UserEnviroPackage#getScreenDimension()
 * @model
 * @generated
 */
public interface ScreenDimension extends EObject {
	/**
	 * Returns the value of the '<em><b>Screen Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Screen Height</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Screen Height</em>' attribute.
	 * @see #setScreenHeight(int)
	 * @see UserEnviro.UserEnviroPackage#getScreenDimension_ScreenHeight()
	 * @model
	 * @generated
	 */
	int getScreenHeight();

	/**
	 * Sets the value of the '{@link UserEnviro.ScreenDimension#getScreenHeight <em>Screen Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Screen Height</em>' attribute.
	 * @see #getScreenHeight()
	 * @generated
	 */
	void setScreenHeight(int value);

	/**
	 * Returns the value of the '<em><b>Screen Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Screen Width</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Screen Width</em>' attribute.
	 * @see #setScreenWidth(int)
	 * @see UserEnviro.UserEnviroPackage#getScreenDimension_ScreenWidth()
	 * @model
	 * @generated
	 */
	int getScreenWidth();

	/**
	 * Sets the value of the '{@link UserEnviro.ScreenDimension#getScreenWidth <em>Screen Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Screen Width</em>' attribute.
	 * @see #getScreenWidth()
	 * @generated
	 */
	void setScreenWidth(int value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // ScreenDimension
