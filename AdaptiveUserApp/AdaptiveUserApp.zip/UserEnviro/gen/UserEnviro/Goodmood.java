/**
 */
package UserEnviro;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Goodmood</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UserEnviro.UserEnviroPackage#getGoodmood()
 * @model
 * @generated
 */
public interface Goodmood extends Mood { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Goodmood
