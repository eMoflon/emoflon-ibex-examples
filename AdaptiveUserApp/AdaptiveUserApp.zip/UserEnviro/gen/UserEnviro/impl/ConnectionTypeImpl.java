/**
 */
package UserEnviro.impl;

import UserEnviro.Cellular;
import UserEnviro.ConnectionType;
import UserEnviro.UserEnviroPackage;
import UserEnviro.Wifi;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Connection Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UserEnviro.impl.ConnectionTypeImpl#getWifi <em>Wifi</em>}</li>
 *   <li>{@link UserEnviro.impl.ConnectionTypeImpl#getCellular <em>Cellular</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ConnectionTypeImpl extends EObjectImpl implements ConnectionType {
	/**
	 * The cached value of the '{@link #getWifi() <em>Wifi</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWifi()
	 * @generated
	 * @ordered
	 */
	protected Wifi wifi;

	/**
	 * The cached value of the '{@link #getCellular() <em>Cellular</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCellular()
	 * @generated
	 * @ordered
	 */
	protected Cellular cellular;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConnectionTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.CONNECTION_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Wifi getWifi() {
		if (wifi != null && wifi.eIsProxy()) {
			InternalEObject oldWifi = (InternalEObject) wifi;
			wifi = (Wifi) eResolveProxy(oldWifi);
			if (wifi != oldWifi) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UserEnviroPackage.CONNECTION_TYPE__WIFI,
							oldWifi, wifi));
			}
		}
		return wifi;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Wifi basicGetWifi() {
		return wifi;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWifi(Wifi newWifi) {
		Wifi oldWifi = wifi;
		wifi = newWifi;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.CONNECTION_TYPE__WIFI, oldWifi,
					wifi));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cellular getCellular() {
		if (cellular != null && cellular.eIsProxy()) {
			InternalEObject oldCellular = (InternalEObject) cellular;
			cellular = (Cellular) eResolveProxy(oldCellular);
			if (cellular != oldCellular) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							UserEnviroPackage.CONNECTION_TYPE__CELLULAR, oldCellular, cellular));
			}
		}
		return cellular;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cellular basicGetCellular() {
		return cellular;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCellular(Cellular newCellular) {
		Cellular oldCellular = cellular;
		cellular = newCellular;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.CONNECTION_TYPE__CELLULAR,
					oldCellular, cellular));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UserEnviroPackage.CONNECTION_TYPE__WIFI:
			if (resolve)
				return getWifi();
			return basicGetWifi();
		case UserEnviroPackage.CONNECTION_TYPE__CELLULAR:
			if (resolve)
				return getCellular();
			return basicGetCellular();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UserEnviroPackage.CONNECTION_TYPE__WIFI:
			setWifi((Wifi) newValue);
			return;
		case UserEnviroPackage.CONNECTION_TYPE__CELLULAR:
			setCellular((Cellular) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.CONNECTION_TYPE__WIFI:
			setWifi((Wifi) null);
			return;
		case UserEnviroPackage.CONNECTION_TYPE__CELLULAR:
			setCellular((Cellular) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.CONNECTION_TYPE__WIFI:
			return wifi != null;
		case UserEnviroPackage.CONNECTION_TYPE__CELLULAR:
			return cellular != null;
		}
		return super.eIsSet(featureID);
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //ConnectionTypeImpl
