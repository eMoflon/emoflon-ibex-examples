/**
 */
package UserEnviro.impl;

import UserEnviro.SunDawn;
import UserEnviro.SunRise;
import UserEnviro.Time;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Time</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UserEnviro.impl.TimeImpl#getSunRise <em>Sun Rise</em>}</li>
 *   <li>{@link UserEnviro.impl.TimeImpl#getSunDawn <em>Sun Dawn</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TimeImpl extends EObjectImpl implements Time {
	/**
	 * The cached value of the '{@link #getSunRise() <em>Sun Rise</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSunRise()
	 * @generated
	 * @ordered
	 */
	protected SunRise sunRise;

	/**
	 * The cached value of the '{@link #getSunDawn() <em>Sun Dawn</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSunDawn()
	 * @generated
	 * @ordered
	 */
	protected SunDawn sunDawn;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TimeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.TIME;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SunRise getSunRise() {
		if (sunRise != null && sunRise.eIsProxy()) {
			InternalEObject oldSunRise = (InternalEObject) sunRise;
			sunRise = (SunRise) eResolveProxy(oldSunRise);
			if (sunRise != oldSunRise) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UserEnviroPackage.TIME__SUN_RISE,
							oldSunRise, sunRise));
			}
		}
		return sunRise;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SunRise basicGetSunRise() {
		return sunRise;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSunRise(SunRise newSunRise) {
		SunRise oldSunRise = sunRise;
		sunRise = newSunRise;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.TIME__SUN_RISE, oldSunRise,
					sunRise));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SunDawn getSunDawn() {
		if (sunDawn != null && sunDawn.eIsProxy()) {
			InternalEObject oldSunDawn = (InternalEObject) sunDawn;
			sunDawn = (SunDawn) eResolveProxy(oldSunDawn);
			if (sunDawn != oldSunDawn) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UserEnviroPackage.TIME__SUN_DAWN,
							oldSunDawn, sunDawn));
			}
		}
		return sunDawn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SunDawn basicGetSunDawn() {
		return sunDawn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSunDawn(SunDawn newSunDawn) {
		SunDawn oldSunDawn = sunDawn;
		sunDawn = newSunDawn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.TIME__SUN_DAWN, oldSunDawn,
					sunDawn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UserEnviroPackage.TIME__SUN_RISE:
			if (resolve)
				return getSunRise();
			return basicGetSunRise();
		case UserEnviroPackage.TIME__SUN_DAWN:
			if (resolve)
				return getSunDawn();
			return basicGetSunDawn();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UserEnviroPackage.TIME__SUN_RISE:
			setSunRise((SunRise) newValue);
			return;
		case UserEnviroPackage.TIME__SUN_DAWN:
			setSunDawn((SunDawn) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.TIME__SUN_RISE:
			setSunRise((SunRise) null);
			return;
		case UserEnviroPackage.TIME__SUN_DAWN:
			setSunDawn((SunDawn) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.TIME__SUN_RISE:
			return sunRise != null;
		case UserEnviroPackage.TIME__SUN_DAWN:
			return sunDawn != null;
		}
		return super.eIsSet(featureID);
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //TimeImpl
