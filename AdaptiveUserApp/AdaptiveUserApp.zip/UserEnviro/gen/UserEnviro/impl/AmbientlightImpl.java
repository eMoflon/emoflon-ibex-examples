/**
 */
package UserEnviro.impl;

import UserEnviro.Ambientlight;
import UserEnviro.HighLight;
import UserEnviro.LowLight;
import UserEnviro.NormalLight;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Ambientlight</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UserEnviro.impl.AmbientlightImpl#getLowLight <em>Low Light</em>}</li>
 *   <li>{@link UserEnviro.impl.AmbientlightImpl#getHighLight <em>High Light</em>}</li>
 *   <li>{@link UserEnviro.impl.AmbientlightImpl#getNormalLight <em>Normal Light</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AmbientlightImpl extends EObjectImpl implements Ambientlight {
	/**
	 * The cached value of the '{@link #getLowLight() <em>Low Light</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLowLight()
	 * @generated
	 * @ordered
	 */
	protected LowLight lowLight;

	/**
	 * The cached value of the '{@link #getHighLight() <em>High Light</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHighLight()
	 * @generated
	 * @ordered
	 */
	protected HighLight highLight;

	/**
	 * The cached value of the '{@link #getNormalLight() <em>Normal Light</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNormalLight()
	 * @generated
	 * @ordered
	 */
	protected NormalLight normalLight;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AmbientlightImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.AMBIENTLIGHT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LowLight getLowLight() {
		return lowLight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLowLight(LowLight newLowLight, NotificationChain msgs) {
		LowLight oldLowLight = lowLight;
		lowLight = newLowLight;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UserEnviroPackage.AMBIENTLIGHT__LOW_LIGHT, oldLowLight, newLowLight);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLowLight(LowLight newLowLight) {
		if (newLowLight != lowLight) {
			NotificationChain msgs = null;
			if (lowLight != null)
				msgs = ((InternalEObject) lowLight).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.AMBIENTLIGHT__LOW_LIGHT, null, msgs);
			if (newLowLight != null)
				msgs = ((InternalEObject) newLowLight).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.AMBIENTLIGHT__LOW_LIGHT, null, msgs);
			msgs = basicSetLowLight(newLowLight, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.AMBIENTLIGHT__LOW_LIGHT,
					newLowLight, newLowLight));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HighLight getHighLight() {
		return highLight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetHighLight(HighLight newHighLight, NotificationChain msgs) {
		HighLight oldHighLight = highLight;
		highLight = newHighLight;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UserEnviroPackage.AMBIENTLIGHT__HIGH_LIGHT, oldHighLight, newHighLight);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHighLight(HighLight newHighLight) {
		if (newHighLight != highLight) {
			NotificationChain msgs = null;
			if (highLight != null)
				msgs = ((InternalEObject) highLight).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.AMBIENTLIGHT__HIGH_LIGHT, null, msgs);
			if (newHighLight != null)
				msgs = ((InternalEObject) newHighLight).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.AMBIENTLIGHT__HIGH_LIGHT, null, msgs);
			msgs = basicSetHighLight(newHighLight, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.AMBIENTLIGHT__HIGH_LIGHT,
					newHighLight, newHighLight));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NormalLight getNormalLight() {
		return normalLight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetNormalLight(NormalLight newNormalLight, NotificationChain msgs) {
		NormalLight oldNormalLight = normalLight;
		normalLight = newNormalLight;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UserEnviroPackage.AMBIENTLIGHT__NORMAL_LIGHT, oldNormalLight, newNormalLight);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNormalLight(NormalLight newNormalLight) {
		if (newNormalLight != normalLight) {
			NotificationChain msgs = null;
			if (normalLight != null)
				msgs = ((InternalEObject) normalLight).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.AMBIENTLIGHT__NORMAL_LIGHT, null, msgs);
			if (newNormalLight != null)
				msgs = ((InternalEObject) newNormalLight).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.AMBIENTLIGHT__NORMAL_LIGHT, null, msgs);
			msgs = basicSetNormalLight(newNormalLight, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.AMBIENTLIGHT__NORMAL_LIGHT,
					newNormalLight, newNormalLight));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UserEnviroPackage.AMBIENTLIGHT__LOW_LIGHT:
			return basicSetLowLight(null, msgs);
		case UserEnviroPackage.AMBIENTLIGHT__HIGH_LIGHT:
			return basicSetHighLight(null, msgs);
		case UserEnviroPackage.AMBIENTLIGHT__NORMAL_LIGHT:
			return basicSetNormalLight(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UserEnviroPackage.AMBIENTLIGHT__LOW_LIGHT:
			return getLowLight();
		case UserEnviroPackage.AMBIENTLIGHT__HIGH_LIGHT:
			return getHighLight();
		case UserEnviroPackage.AMBIENTLIGHT__NORMAL_LIGHT:
			return getNormalLight();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UserEnviroPackage.AMBIENTLIGHT__LOW_LIGHT:
			setLowLight((LowLight) newValue);
			return;
		case UserEnviroPackage.AMBIENTLIGHT__HIGH_LIGHT:
			setHighLight((HighLight) newValue);
			return;
		case UserEnviroPackage.AMBIENTLIGHT__NORMAL_LIGHT:
			setNormalLight((NormalLight) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.AMBIENTLIGHT__LOW_LIGHT:
			setLowLight((LowLight) null);
			return;
		case UserEnviroPackage.AMBIENTLIGHT__HIGH_LIGHT:
			setHighLight((HighLight) null);
			return;
		case UserEnviroPackage.AMBIENTLIGHT__NORMAL_LIGHT:
			setNormalLight((NormalLight) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.AMBIENTLIGHT__LOW_LIGHT:
			return lowLight != null;
		case UserEnviroPackage.AMBIENTLIGHT__HIGH_LIGHT:
			return highLight != null;
		case UserEnviroPackage.AMBIENTLIGHT__NORMAL_LIGHT:
			return normalLight != null;
		}
		return super.eIsSet(featureID);
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //AmbientlightImpl
