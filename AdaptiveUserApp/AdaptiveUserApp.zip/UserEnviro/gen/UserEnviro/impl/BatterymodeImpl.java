/**
 */
package UserEnviro.impl;

import UserEnviro.Batterymode;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Batterymode</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public abstract class BatterymodeImpl extends EObjectImpl implements Batterymode {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BatterymodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.BATTERYMODE;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //BatterymodeImpl
