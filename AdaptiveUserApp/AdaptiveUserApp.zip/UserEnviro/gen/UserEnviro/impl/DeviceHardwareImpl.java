/**
 */
package UserEnviro.impl;

import UserEnviro.DeviceHardware;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Device Hardware</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public abstract class DeviceHardwareImpl extends EObjectImpl implements DeviceHardware {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DeviceHardwareImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.DEVICE_HARDWARE;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //DeviceHardwareImpl
