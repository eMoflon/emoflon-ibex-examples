/**
 */
package UserEnviro.impl;

import UserEnviro.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class UserEnviroFactoryImpl extends EFactoryImpl implements UserEnviroFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static UserEnviroFactory init() {
		try {
			UserEnviroFactory theUserEnviroFactory = (UserEnviroFactory) EPackage.Registry.INSTANCE
					.getEFactory(UserEnviroPackage.eNS_URI);
			if (theUserEnviroFactory != null) {
				return theUserEnviroFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new UserEnviroFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserEnviroFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case UserEnviroPackage.CONTEXT:
			return createContext();
		case UserEnviroPackage.USER:
			return createUser();
		case UserEnviroPackage.OLD_AGE_USER:
			return createOldAgeUser();
		case UserEnviroPackage.MIDDLE_AGE_USER:
			return createMiddleAgeUser();
		case UserEnviroPackage.YOUNGER_USER:
			return createYoungerUser();
		case UserEnviroPackage.NORMALVISION:
			return createNormalvision();
		case UserEnviroPackage.REDUCEDVISION:
			return createReducedvision();
		case UserEnviroPackage.BADMOOD:
			return createBadmood();
		case UserEnviroPackage.GOODMOOD:
			return createGoodmood();
		case UserEnviroPackage.NEUTRALMOOD:
			return createNeutralmood();
		case UserEnviroPackage.EXPERIENCED:
			return createExperienced();
		case UserEnviroPackage.INEXPERIENCED:
			return createInexperienced();
		case UserEnviroPackage.INTERMEDIATE:
			return createIntermediate();
		case UserEnviroPackage.USAGE_TIME:
			return createUsageTime();
		case UserEnviroPackage.ENVIRONMENT:
			return createEnvironment();
		case UserEnviroPackage.THREE_G:
			return createThreeG();
		case UserEnviroPackage.TWO_G:
			return createTwoG();
		case UserEnviroPackage.FOUR_G:
			return createFourG();
		case UserEnviroPackage.CONNECTION_TYPE:
			return createConnectionType();
		case UserEnviroPackage.WIFI:
			return createWifi();
		case UserEnviroPackage.CELLULAR:
			return createCellular();
		case UserEnviroPackage.BATTERY_LEVEL:
			return createBatteryLevel();
		case UserEnviroPackage.CHARGING:
			return createCharging();
		case UserEnviroPackage.AMBIENTLIGHT:
			return createAmbientlight();
		case UserEnviroPackage.LOW_LIGHT:
			return createLowLight();
		case UserEnviroPackage.HIGH_LIGHT:
			return createHighLight();
		case UserEnviroPackage.NORMAL_LIGHT:
			return createNormalLight();
		case UserEnviroPackage.TIME:
			return createTime();
		case UserEnviroPackage.SUN_RISE:
			return createSunRise();
		case UserEnviroPackage.SUN_DAWN:
			return createSunDawn();
		case UserEnviroPackage.ACTIVITY:
			return createActivity();
		case UserEnviroPackage.PLATFORM:
			return createPlatform();
		case UserEnviroPackage.CAMERA:
			return createCamera();
		case UserEnviroPackage.SCREEN_DIMENSION:
			return createScreenDimension();
		case UserEnviroPackage.NORMAL_BATTERYMODE:
			return createNormalBatterymode();
		case UserEnviroPackage.LOW_BATTERYMODE:
			return createLowBatterymode();
		case UserEnviroPackage.TABLET:
			return createTablet();
		case UserEnviroPackage.SMARTPHONE:
			return createSmartphone();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case UserEnviroPackage.BAD_ENUM:
			return createBadEnumFromString(eDataType, initialValue);
		case UserEnviroPackage.ACTIVITY_ENUM:
			return createActivityEnumFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case UserEnviroPackage.BAD_ENUM:
			return convertBadEnumToString(eDataType, instanceValue);
		case UserEnviroPackage.ACTIVITY_ENUM:
			return convertActivityEnumToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Context createContext() {
		ContextImpl context = new ContextImpl();
		return context;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public User createUser() {
		UserImpl user = new UserImpl();
		return user;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public OldAgeUser createOldAgeUser() {
		OldAgeUserImpl oldAgeUser = new OldAgeUserImpl();
		return oldAgeUser;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MiddleAgeUser createMiddleAgeUser() {
		MiddleAgeUserImpl middleAgeUser = new MiddleAgeUserImpl();
		return middleAgeUser;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public YoungerUser createYoungerUser() {
		YoungerUserImpl youngerUser = new YoungerUserImpl();
		return youngerUser;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Normalvision createNormalvision() {
		NormalvisionImpl normalvision = new NormalvisionImpl();
		return normalvision;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Reducedvision createReducedvision() {
		ReducedvisionImpl reducedvision = new ReducedvisionImpl();
		return reducedvision;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Badmood createBadmood() {
		BadmoodImpl badmood = new BadmoodImpl();
		return badmood;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Goodmood createGoodmood() {
		GoodmoodImpl goodmood = new GoodmoodImpl();
		return goodmood;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Neutralmood createNeutralmood() {
		NeutralmoodImpl neutralmood = new NeutralmoodImpl();
		return neutralmood;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Experienced createExperienced() {
		ExperiencedImpl experienced = new ExperiencedImpl();
		return experienced;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Inexperienced createInexperienced() {
		InexperiencedImpl inexperienced = new InexperiencedImpl();
		return inexperienced;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Intermediate createIntermediate() {
		IntermediateImpl intermediate = new IntermediateImpl();
		return intermediate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public UsageTime createUsageTime() {
		UsageTimeImpl usageTime = new UsageTimeImpl();
		return usageTime;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Environment createEnvironment() {
		EnvironmentImpl environment = new EnvironmentImpl();
		return environment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ThreeG createThreeG() {
		ThreeGImpl threeG = new ThreeGImpl();
		return threeG;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TwoG createTwoG() {
		TwoGImpl twoG = new TwoGImpl();
		return twoG;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FourG createFourG() {
		FourGImpl fourG = new FourGImpl();
		return fourG;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConnectionType createConnectionType() {
		ConnectionTypeImpl connectionType = new ConnectionTypeImpl();
		return connectionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Wifi createWifi() {
		WifiImpl wifi = new WifiImpl();
		return wifi;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Cellular createCellular() {
		CellularImpl cellular = new CellularImpl();
		return cellular;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BatteryLevel createBatteryLevel() {
		BatteryLevelImpl batteryLevel = new BatteryLevelImpl();
		return batteryLevel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Charging createCharging() {
		ChargingImpl charging = new ChargingImpl();
		return charging;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Ambientlight createAmbientlight() {
		AmbientlightImpl ambientlight = new AmbientlightImpl();
		return ambientlight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LowLight createLowLight() {
		LowLightImpl lowLight = new LowLightImpl();
		return lowLight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HighLight createHighLight() {
		HighLightImpl highLight = new HighLightImpl();
		return highLight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NormalLight createNormalLight() {
		NormalLightImpl normalLight = new NormalLightImpl();
		return normalLight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Time createTime() {
		TimeImpl time = new TimeImpl();
		return time;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SunRise createSunRise() {
		SunRiseImpl sunRise = new SunRiseImpl();
		return sunRise;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SunDawn createSunDawn() {
		SunDawnImpl sunDawn = new SunDawnImpl();
		return sunDawn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Activity createActivity() {
		ActivityImpl activity = new ActivityImpl();
		return activity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Platform createPlatform() {
		PlatformImpl platform = new PlatformImpl();
		return platform;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Camera createCamera() {
		CameraImpl camera = new CameraImpl();
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ScreenDimension createScreenDimension() {
		ScreenDimensionImpl screenDimension = new ScreenDimensionImpl();
		return screenDimension;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NormalBatterymode createNormalBatterymode() {
		NormalBatterymodeImpl normalBatterymode = new NormalBatterymodeImpl();
		return normalBatterymode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LowBatterymode createLowBatterymode() {
		LowBatterymodeImpl lowBatterymode = new LowBatterymodeImpl();
		return lowBatterymode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Tablet createTablet() {
		TabletImpl tablet = new TabletImpl();
		return tablet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Smartphone createSmartphone() {
		SmartphoneImpl smartphone = new SmartphoneImpl();
		return smartphone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BadEnum createBadEnumFromString(EDataType eDataType, String initialValue) {
		BadEnum result = BadEnum.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertBadEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ActivityEnum createActivityEnumFromString(EDataType eDataType, String initialValue) {
		ActivityEnum result = ActivityEnum.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertActivityEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public UserEnviroPackage getUserEnviroPackage() {
		return (UserEnviroPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static UserEnviroPackage getPackage() {
		return UserEnviroPackage.eINSTANCE;
	}

} //UserEnviroFactoryImpl
