/**
 */
package UserEnviro.impl;

import UserEnviro.MiddleAgeUser;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Middle Age User</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class MiddleAgeUserImpl extends UserImpl implements MiddleAgeUser {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MiddleAgeUserImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.MIDDLE_AGE_USER;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //MiddleAgeUserImpl
