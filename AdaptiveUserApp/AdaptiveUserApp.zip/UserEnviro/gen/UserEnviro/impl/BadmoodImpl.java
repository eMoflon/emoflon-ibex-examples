/**
 */
package UserEnviro.impl;

import UserEnviro.BadEnum;
import UserEnviro.Badmood;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Badmood</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UserEnviro.impl.BadmoodImpl#getBadEnum <em>Bad Enum</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class BadmoodImpl extends MoodImpl implements Badmood {
	/**
	 * The default value of the '{@link #getBadEnum() <em>Bad Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBadEnum()
	 * @generated
	 * @ordered
	 */
	protected static final BadEnum BAD_ENUM_EDEFAULT = BadEnum.ANGER;

	/**
	 * The cached value of the '{@link #getBadEnum() <em>Bad Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBadEnum()
	 * @generated
	 * @ordered
	 */
	protected BadEnum badEnum = BAD_ENUM_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BadmoodImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.BADMOOD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BadEnum getBadEnum() {
		return badEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBadEnum(BadEnum newBadEnum) {
		BadEnum oldBadEnum = badEnum;
		badEnum = newBadEnum == null ? BAD_ENUM_EDEFAULT : newBadEnum;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.BADMOOD__BAD_ENUM, oldBadEnum,
					badEnum));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UserEnviroPackage.BADMOOD__BAD_ENUM:
			return getBadEnum();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UserEnviroPackage.BADMOOD__BAD_ENUM:
			setBadEnum((BadEnum) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.BADMOOD__BAD_ENUM:
			setBadEnum(BAD_ENUM_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.BADMOOD__BAD_ENUM:
			return badEnum != BAD_ENUM_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (badEnum: ");
		result.append(badEnum);
		result.append(')');
		return result.toString();
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //BadmoodImpl
