/**
 */
package UserEnviro.impl;

import UserEnviro.ThreeG;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Three G</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ThreeGImpl extends ConnectionSpeedImpl implements ThreeG {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ThreeGImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.THREE_G;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //ThreeGImpl
