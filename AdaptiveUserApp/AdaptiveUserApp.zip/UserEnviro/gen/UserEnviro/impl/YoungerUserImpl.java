/**
 */
package UserEnviro.impl;

import UserEnviro.UserEnviroPackage;
import UserEnviro.YoungerUser;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Younger User</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class YoungerUserImpl extends UserImpl implements YoungerUser {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected YoungerUserImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.YOUNGER_USER;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //YoungerUserImpl
