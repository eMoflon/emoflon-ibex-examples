/**
 */
package UserEnviro.impl;

import UserEnviro.ExperienceLevel;
import UserEnviro.Mood;
import UserEnviro.UsageTime;
import UserEnviro.User;
import UserEnviro.UserEnviroPackage;
import UserEnviro.Vision;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>User</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UserEnviro.impl.UserImpl#getMood <em>Mood</em>}</li>
 *   <li>{@link UserEnviro.impl.UserImpl#getExp <em>Exp</em>}</li>
 *   <li>{@link UserEnviro.impl.UserImpl#getTime <em>Time</em>}</li>
 *   <li>{@link UserEnviro.impl.UserImpl#getVision <em>Vision</em>}</li>
 *   <li>{@link UserEnviro.impl.UserImpl#getName <em>Name</em>}</li>
 *   <li>{@link UserEnviro.impl.UserImpl#getAge <em>Age</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class UserImpl extends EObjectImpl implements User {
	/**
	 * The cached value of the '{@link #getMood() <em>Mood</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMood()
	 * @generated
	 * @ordered
	 */
	protected Mood mood;

	/**
	 * The cached value of the '{@link #getExp() <em>Exp</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExp()
	 * @generated
	 * @ordered
	 */
	protected ExperienceLevel exp;

	/**
	 * The cached value of the '{@link #getTime() <em>Time</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTime()
	 * @generated
	 * @ordered
	 */
	protected UsageTime time;

	/**
	 * The cached value of the '{@link #getVision() <em>Vision</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVision()
	 * @generated
	 * @ordered
	 */
	protected Vision vision;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getAge() <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAge()
	 * @generated
	 * @ordered
	 */
	protected static final int AGE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getAge() <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAge()
	 * @generated
	 * @ordered
	 */
	protected int age = AGE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UserImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.USER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Mood getMood() {
		return mood;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetMood(Mood newMood, NotificationChain msgs) {
		Mood oldMood = mood;
		mood = newMood;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, UserEnviroPackage.USER__MOOD,
					oldMood, newMood);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMood(Mood newMood) {
		if (newMood != mood) {
			NotificationChain msgs = null;
			if (mood != null)
				msgs = ((InternalEObject) mood).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.USER__MOOD, null, msgs);
			if (newMood != null)
				msgs = ((InternalEObject) newMood).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.USER__MOOD, null, msgs);
			msgs = basicSetMood(newMood, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.USER__MOOD, newMood, newMood));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExperienceLevel getExp() {
		return exp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetExp(ExperienceLevel newExp, NotificationChain msgs) {
		ExperienceLevel oldExp = exp;
		exp = newExp;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, UserEnviroPackage.USER__EXP,
					oldExp, newExp);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExp(ExperienceLevel newExp) {
		if (newExp != exp) {
			NotificationChain msgs = null;
			if (exp != null)
				msgs = ((InternalEObject) exp).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.USER__EXP, null, msgs);
			if (newExp != null)
				msgs = ((InternalEObject) newExp).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.USER__EXP, null, msgs);
			msgs = basicSetExp(newExp, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.USER__EXP, newExp, newExp));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UsageTime getTime() {
		if (time != null && time.eIsProxy()) {
			InternalEObject oldTime = (InternalEObject) time;
			time = (UsageTime) eResolveProxy(oldTime);
			if (time != oldTime) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UserEnviroPackage.USER__TIME, oldTime,
							time));
			}
		}
		return time;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UsageTime basicGetTime() {
		return time;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTime(UsageTime newTime) {
		UsageTime oldTime = time;
		time = newTime;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.USER__TIME, oldTime, time));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Vision getVision() {
		if (vision != null && vision.eIsProxy()) {
			InternalEObject oldVision = (InternalEObject) vision;
			vision = (Vision) eResolveProxy(oldVision);
			if (vision != oldVision) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UserEnviroPackage.USER__VISION, oldVision,
							vision));
			}
		}
		return vision;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Vision basicGetVision() {
		return vision;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVision(Vision newVision) {
		Vision oldVision = vision;
		vision = newVision;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.USER__VISION, oldVision, vision));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.USER__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getAge() {
		return age;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAge(int newAge) {
		int oldAge = age;
		age = newAge;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.USER__AGE, oldAge, age));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UserEnviroPackage.USER__MOOD:
			return basicSetMood(null, msgs);
		case UserEnviroPackage.USER__EXP:
			return basicSetExp(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UserEnviroPackage.USER__MOOD:
			return getMood();
		case UserEnviroPackage.USER__EXP:
			return getExp();
		case UserEnviroPackage.USER__TIME:
			if (resolve)
				return getTime();
			return basicGetTime();
		case UserEnviroPackage.USER__VISION:
			if (resolve)
				return getVision();
			return basicGetVision();
		case UserEnviroPackage.USER__NAME:
			return getName();
		case UserEnviroPackage.USER__AGE:
			return getAge();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UserEnviroPackage.USER__MOOD:
			setMood((Mood) newValue);
			return;
		case UserEnviroPackage.USER__EXP:
			setExp((ExperienceLevel) newValue);
			return;
		case UserEnviroPackage.USER__TIME:
			setTime((UsageTime) newValue);
			return;
		case UserEnviroPackage.USER__VISION:
			setVision((Vision) newValue);
			return;
		case UserEnviroPackage.USER__NAME:
			setName((String) newValue);
			return;
		case UserEnviroPackage.USER__AGE:
			setAge((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.USER__MOOD:
			setMood((Mood) null);
			return;
		case UserEnviroPackage.USER__EXP:
			setExp((ExperienceLevel) null);
			return;
		case UserEnviroPackage.USER__TIME:
			setTime((UsageTime) null);
			return;
		case UserEnviroPackage.USER__VISION:
			setVision((Vision) null);
			return;
		case UserEnviroPackage.USER__NAME:
			setName(NAME_EDEFAULT);
			return;
		case UserEnviroPackage.USER__AGE:
			setAge(AGE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.USER__MOOD:
			return mood != null;
		case UserEnviroPackage.USER__EXP:
			return exp != null;
		case UserEnviroPackage.USER__TIME:
			return time != null;
		case UserEnviroPackage.USER__VISION:
			return vision != null;
		case UserEnviroPackage.USER__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case UserEnviroPackage.USER__AGE:
			return age != AGE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", Age: ");
		result.append(age);
		result.append(')');
		return result.toString();
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //UserImpl
