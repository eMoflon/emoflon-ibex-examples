/**
 */
package UserEnviro.impl;

import UserEnviro.ExperienceLevel;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Experience Level</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public abstract class ExperienceLevelImpl extends EObjectImpl implements ExperienceLevel {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ExperienceLevelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.EXPERIENCE_LEVEL;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //ExperienceLevelImpl
