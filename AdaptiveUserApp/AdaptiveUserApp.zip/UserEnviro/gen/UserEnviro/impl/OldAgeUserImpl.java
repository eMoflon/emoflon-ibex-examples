/**
 */
package UserEnviro.impl;

import UserEnviro.OldAgeUser;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Old Age User</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class OldAgeUserImpl extends UserImpl implements OldAgeUser {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OldAgeUserImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.OLD_AGE_USER;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //OldAgeUserImpl
