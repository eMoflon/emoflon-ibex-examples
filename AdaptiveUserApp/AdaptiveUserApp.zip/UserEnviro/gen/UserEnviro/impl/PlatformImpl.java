/**
 */
package UserEnviro.impl;

import UserEnviro.BatteryLevel;
import UserEnviro.Batterymode;
import UserEnviro.Charging;
import UserEnviro.ConnectionSpeed;
import UserEnviro.ConnectionType;
import UserEnviro.DeviceHardware;
import UserEnviro.Devicetype;
import UserEnviro.Platform;
import UserEnviro.ScreenDimension;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Platform</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UserEnviro.impl.PlatformImpl#getDevicetype <em>Devicetype</em>}</li>
 *   <li>{@link UserEnviro.impl.PlatformImpl#getBatterymode <em>Batterymode</em>}</li>
 *   <li>{@link UserEnviro.impl.PlatformImpl#getScreenDim <em>Screen Dim</em>}</li>
 *   <li>{@link UserEnviro.impl.PlatformImpl#getHardware <em>Hardware</em>}</li>
 *   <li>{@link UserEnviro.impl.PlatformImpl#getBatteryLevel <em>Battery Level</em>}</li>
 *   <li>{@link UserEnviro.impl.PlatformImpl#getConnectionType <em>Connection Type</em>}</li>
 *   <li>{@link UserEnviro.impl.PlatformImpl#getConnectionSpeed <em>Connection Speed</em>}</li>
 *   <li>{@link UserEnviro.impl.PlatformImpl#getCharging <em>Charging</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class PlatformImpl extends EObjectImpl implements Platform {
	/**
	 * The cached value of the '{@link #getDevicetype() <em>Devicetype</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDevicetype()
	 * @generated
	 * @ordered
	 */
	protected Devicetype devicetype;

	/**
	 * The cached value of the '{@link #getBatterymode() <em>Batterymode</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBatterymode()
	 * @generated
	 * @ordered
	 */
	protected Batterymode batterymode;

	/**
	 * The cached value of the '{@link #getScreenDim() <em>Screen Dim</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScreenDim()
	 * @generated
	 * @ordered
	 */
	protected ScreenDimension screenDim;

	/**
	 * The cached value of the '{@link #getHardware() <em>Hardware</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHardware()
	 * @generated
	 * @ordered
	 */
	protected DeviceHardware hardware;

	/**
	 * The cached value of the '{@link #getBatteryLevel() <em>Battery Level</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBatteryLevel()
	 * @generated
	 * @ordered
	 */
	protected BatteryLevel batteryLevel;

	/**
	 * The cached value of the '{@link #getConnectionType() <em>Connection Type</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnectionType()
	 * @generated
	 * @ordered
	 */
	protected ConnectionType connectionType;

	/**
	 * The cached value of the '{@link #getConnectionSpeed() <em>Connection Speed</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnectionSpeed()
	 * @generated
	 * @ordered
	 */
	protected ConnectionSpeed connectionSpeed;

	/**
	 * The cached value of the '{@link #getCharging() <em>Charging</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCharging()
	 * @generated
	 * @ordered
	 */
	protected Charging charging;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PlatformImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.PLATFORM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Devicetype getDevicetype() {
		return devicetype;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDevicetype(Devicetype newDevicetype, NotificationChain msgs) {
		Devicetype oldDevicetype = devicetype;
		devicetype = newDevicetype;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UserEnviroPackage.PLATFORM__DEVICETYPE, oldDevicetype, newDevicetype);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDevicetype(Devicetype newDevicetype) {
		if (newDevicetype != devicetype) {
			NotificationChain msgs = null;
			if (devicetype != null)
				msgs = ((InternalEObject) devicetype).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.PLATFORM__DEVICETYPE, null, msgs);
			if (newDevicetype != null)
				msgs = ((InternalEObject) newDevicetype).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.PLATFORM__DEVICETYPE, null, msgs);
			msgs = basicSetDevicetype(newDevicetype, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.PLATFORM__DEVICETYPE, newDevicetype,
					newDevicetype));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Batterymode getBatterymode() {
		if (batterymode != null && batterymode.eIsProxy()) {
			InternalEObject oldBatterymode = (InternalEObject) batterymode;
			batterymode = (Batterymode) eResolveProxy(oldBatterymode);
			if (batterymode != oldBatterymode) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UserEnviroPackage.PLATFORM__BATTERYMODE,
							oldBatterymode, batterymode));
			}
		}
		return batterymode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Batterymode basicGetBatterymode() {
		return batterymode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBatterymode(Batterymode newBatterymode) {
		Batterymode oldBatterymode = batterymode;
		batterymode = newBatterymode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.PLATFORM__BATTERYMODE,
					oldBatterymode, batterymode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ScreenDimension getScreenDim() {
		if (screenDim != null && screenDim.eIsProxy()) {
			InternalEObject oldScreenDim = (InternalEObject) screenDim;
			screenDim = (ScreenDimension) eResolveProxy(oldScreenDim);
			if (screenDim != oldScreenDim) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UserEnviroPackage.PLATFORM__SCREEN_DIM,
							oldScreenDim, screenDim));
			}
		}
		return screenDim;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ScreenDimension basicGetScreenDim() {
		return screenDim;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setScreenDim(ScreenDimension newScreenDim) {
		ScreenDimension oldScreenDim = screenDim;
		screenDim = newScreenDim;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.PLATFORM__SCREEN_DIM, oldScreenDim,
					screenDim));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DeviceHardware getHardware() {
		return hardware;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetHardware(DeviceHardware newHardware, NotificationChain msgs) {
		DeviceHardware oldHardware = hardware;
		hardware = newHardware;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UserEnviroPackage.PLATFORM__HARDWARE, oldHardware, newHardware);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHardware(DeviceHardware newHardware) {
		if (newHardware != hardware) {
			NotificationChain msgs = null;
			if (hardware != null)
				msgs = ((InternalEObject) hardware).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.PLATFORM__HARDWARE, null, msgs);
			if (newHardware != null)
				msgs = ((InternalEObject) newHardware).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.PLATFORM__HARDWARE, null, msgs);
			msgs = basicSetHardware(newHardware, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.PLATFORM__HARDWARE, newHardware,
					newHardware));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BatteryLevel getBatteryLevel() {
		if (batteryLevel != null && batteryLevel.eIsProxy()) {
			InternalEObject oldBatteryLevel = (InternalEObject) batteryLevel;
			batteryLevel = (BatteryLevel) eResolveProxy(oldBatteryLevel);
			if (batteryLevel != oldBatteryLevel) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UserEnviroPackage.PLATFORM__BATTERY_LEVEL,
							oldBatteryLevel, batteryLevel));
			}
		}
		return batteryLevel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BatteryLevel basicGetBatteryLevel() {
		return batteryLevel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBatteryLevel(BatteryLevel newBatteryLevel) {
		BatteryLevel oldBatteryLevel = batteryLevel;
		batteryLevel = newBatteryLevel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.PLATFORM__BATTERY_LEVEL,
					oldBatteryLevel, batteryLevel));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConnectionType getConnectionType() {
		return connectionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetConnectionType(ConnectionType newConnectionType, NotificationChain msgs) {
		ConnectionType oldConnectionType = connectionType;
		connectionType = newConnectionType;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UserEnviroPackage.PLATFORM__CONNECTION_TYPE, oldConnectionType, newConnectionType);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConnectionType(ConnectionType newConnectionType) {
		if (newConnectionType != connectionType) {
			NotificationChain msgs = null;
			if (connectionType != null)
				msgs = ((InternalEObject) connectionType).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.PLATFORM__CONNECTION_TYPE, null, msgs);
			if (newConnectionType != null)
				msgs = ((InternalEObject) newConnectionType).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.PLATFORM__CONNECTION_TYPE, null, msgs);
			msgs = basicSetConnectionType(newConnectionType, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.PLATFORM__CONNECTION_TYPE,
					newConnectionType, newConnectionType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConnectionSpeed getConnectionSpeed() {
		return connectionSpeed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetConnectionSpeed(ConnectionSpeed newConnectionSpeed, NotificationChain msgs) {
		ConnectionSpeed oldConnectionSpeed = connectionSpeed;
		connectionSpeed = newConnectionSpeed;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UserEnviroPackage.PLATFORM__CONNECTION_SPEED, oldConnectionSpeed, newConnectionSpeed);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConnectionSpeed(ConnectionSpeed newConnectionSpeed) {
		if (newConnectionSpeed != connectionSpeed) {
			NotificationChain msgs = null;
			if (connectionSpeed != null)
				msgs = ((InternalEObject) connectionSpeed).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.PLATFORM__CONNECTION_SPEED, null, msgs);
			if (newConnectionSpeed != null)
				msgs = ((InternalEObject) newConnectionSpeed).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.PLATFORM__CONNECTION_SPEED, null, msgs);
			msgs = basicSetConnectionSpeed(newConnectionSpeed, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.PLATFORM__CONNECTION_SPEED,
					newConnectionSpeed, newConnectionSpeed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Charging getCharging() {
		if (charging != null && charging.eIsProxy()) {
			InternalEObject oldCharging = (InternalEObject) charging;
			charging = (Charging) eResolveProxy(oldCharging);
			if (charging != oldCharging) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UserEnviroPackage.PLATFORM__CHARGING,
							oldCharging, charging));
			}
		}
		return charging;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Charging basicGetCharging() {
		return charging;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCharging(Charging newCharging) {
		Charging oldCharging = charging;
		charging = newCharging;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.PLATFORM__CHARGING, oldCharging,
					charging));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UserEnviroPackage.PLATFORM__DEVICETYPE:
			return basicSetDevicetype(null, msgs);
		case UserEnviroPackage.PLATFORM__HARDWARE:
			return basicSetHardware(null, msgs);
		case UserEnviroPackage.PLATFORM__CONNECTION_TYPE:
			return basicSetConnectionType(null, msgs);
		case UserEnviroPackage.PLATFORM__CONNECTION_SPEED:
			return basicSetConnectionSpeed(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UserEnviroPackage.PLATFORM__DEVICETYPE:
			return getDevicetype();
		case UserEnviroPackage.PLATFORM__BATTERYMODE:
			if (resolve)
				return getBatterymode();
			return basicGetBatterymode();
		case UserEnviroPackage.PLATFORM__SCREEN_DIM:
			if (resolve)
				return getScreenDim();
			return basicGetScreenDim();
		case UserEnviroPackage.PLATFORM__HARDWARE:
			return getHardware();
		case UserEnviroPackage.PLATFORM__BATTERY_LEVEL:
			if (resolve)
				return getBatteryLevel();
			return basicGetBatteryLevel();
		case UserEnviroPackage.PLATFORM__CONNECTION_TYPE:
			return getConnectionType();
		case UserEnviroPackage.PLATFORM__CONNECTION_SPEED:
			return getConnectionSpeed();
		case UserEnviroPackage.PLATFORM__CHARGING:
			if (resolve)
				return getCharging();
			return basicGetCharging();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UserEnviroPackage.PLATFORM__DEVICETYPE:
			setDevicetype((Devicetype) newValue);
			return;
		case UserEnviroPackage.PLATFORM__BATTERYMODE:
			setBatterymode((Batterymode) newValue);
			return;
		case UserEnviroPackage.PLATFORM__SCREEN_DIM:
			setScreenDim((ScreenDimension) newValue);
			return;
		case UserEnviroPackage.PLATFORM__HARDWARE:
			setHardware((DeviceHardware) newValue);
			return;
		case UserEnviroPackage.PLATFORM__BATTERY_LEVEL:
			setBatteryLevel((BatteryLevel) newValue);
			return;
		case UserEnviroPackage.PLATFORM__CONNECTION_TYPE:
			setConnectionType((ConnectionType) newValue);
			return;
		case UserEnviroPackage.PLATFORM__CONNECTION_SPEED:
			setConnectionSpeed((ConnectionSpeed) newValue);
			return;
		case UserEnviroPackage.PLATFORM__CHARGING:
			setCharging((Charging) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.PLATFORM__DEVICETYPE:
			setDevicetype((Devicetype) null);
			return;
		case UserEnviroPackage.PLATFORM__BATTERYMODE:
			setBatterymode((Batterymode) null);
			return;
		case UserEnviroPackage.PLATFORM__SCREEN_DIM:
			setScreenDim((ScreenDimension) null);
			return;
		case UserEnviroPackage.PLATFORM__HARDWARE:
			setHardware((DeviceHardware) null);
			return;
		case UserEnviroPackage.PLATFORM__BATTERY_LEVEL:
			setBatteryLevel((BatteryLevel) null);
			return;
		case UserEnviroPackage.PLATFORM__CONNECTION_TYPE:
			setConnectionType((ConnectionType) null);
			return;
		case UserEnviroPackage.PLATFORM__CONNECTION_SPEED:
			setConnectionSpeed((ConnectionSpeed) null);
			return;
		case UserEnviroPackage.PLATFORM__CHARGING:
			setCharging((Charging) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.PLATFORM__DEVICETYPE:
			return devicetype != null;
		case UserEnviroPackage.PLATFORM__BATTERYMODE:
			return batterymode != null;
		case UserEnviroPackage.PLATFORM__SCREEN_DIM:
			return screenDim != null;
		case UserEnviroPackage.PLATFORM__HARDWARE:
			return hardware != null;
		case UserEnviroPackage.PLATFORM__BATTERY_LEVEL:
			return batteryLevel != null;
		case UserEnviroPackage.PLATFORM__CONNECTION_TYPE:
			return connectionType != null;
		case UserEnviroPackage.PLATFORM__CONNECTION_SPEED:
			return connectionSpeed != null;
		case UserEnviroPackage.PLATFORM__CHARGING:
			return charging != null;
		}
		return super.eIsSet(featureID);
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //PlatformImpl
