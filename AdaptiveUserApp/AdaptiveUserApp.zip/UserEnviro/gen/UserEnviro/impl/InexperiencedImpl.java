/**
 */
package UserEnviro.impl;

import UserEnviro.Inexperienced;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Inexperienced</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class InexperiencedImpl extends ExperienceLevelImpl implements Inexperienced {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InexperiencedImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.INEXPERIENCED;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //InexperiencedImpl
