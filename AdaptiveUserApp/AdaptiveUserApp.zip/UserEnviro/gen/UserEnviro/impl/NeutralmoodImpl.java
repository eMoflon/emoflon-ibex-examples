/**
 */
package UserEnviro.impl;

import UserEnviro.Neutralmood;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Neutralmood</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class NeutralmoodImpl extends MoodImpl implements Neutralmood {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NeutralmoodImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.NEUTRALMOOD;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //NeutralmoodImpl
