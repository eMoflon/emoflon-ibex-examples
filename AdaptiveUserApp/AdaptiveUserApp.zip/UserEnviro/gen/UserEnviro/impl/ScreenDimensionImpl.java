/**
 */
package UserEnviro.impl;

import UserEnviro.ScreenDimension;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Screen Dimension</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UserEnviro.impl.ScreenDimensionImpl#getScreenHeight <em>Screen Height</em>}</li>
 *   <li>{@link UserEnviro.impl.ScreenDimensionImpl#getScreenWidth <em>Screen Width</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ScreenDimensionImpl extends EObjectImpl implements ScreenDimension {
	/**
	 * The default value of the '{@link #getScreenHeight() <em>Screen Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScreenHeight()
	 * @generated
	 * @ordered
	 */
	protected static final int SCREEN_HEIGHT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getScreenHeight() <em>Screen Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScreenHeight()
	 * @generated
	 * @ordered
	 */
	protected int screenHeight = SCREEN_HEIGHT_EDEFAULT;

	/**
	 * The default value of the '{@link #getScreenWidth() <em>Screen Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScreenWidth()
	 * @generated
	 * @ordered
	 */
	protected static final int SCREEN_WIDTH_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getScreenWidth() <em>Screen Width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getScreenWidth()
	 * @generated
	 * @ordered
	 */
	protected int screenWidth = SCREEN_WIDTH_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ScreenDimensionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.SCREEN_DIMENSION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getScreenHeight() {
		return screenHeight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setScreenHeight(int newScreenHeight) {
		int oldScreenHeight = screenHeight;
		screenHeight = newScreenHeight;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.SCREEN_DIMENSION__SCREEN_HEIGHT,
					oldScreenHeight, screenHeight));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getScreenWidth() {
		return screenWidth;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setScreenWidth(int newScreenWidth) {
		int oldScreenWidth = screenWidth;
		screenWidth = newScreenWidth;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.SCREEN_DIMENSION__SCREEN_WIDTH,
					oldScreenWidth, screenWidth));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UserEnviroPackage.SCREEN_DIMENSION__SCREEN_HEIGHT:
			return getScreenHeight();
		case UserEnviroPackage.SCREEN_DIMENSION__SCREEN_WIDTH:
			return getScreenWidth();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UserEnviroPackage.SCREEN_DIMENSION__SCREEN_HEIGHT:
			setScreenHeight((Integer) newValue);
			return;
		case UserEnviroPackage.SCREEN_DIMENSION__SCREEN_WIDTH:
			setScreenWidth((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.SCREEN_DIMENSION__SCREEN_HEIGHT:
			setScreenHeight(SCREEN_HEIGHT_EDEFAULT);
			return;
		case UserEnviroPackage.SCREEN_DIMENSION__SCREEN_WIDTH:
			setScreenWidth(SCREEN_WIDTH_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.SCREEN_DIMENSION__SCREEN_HEIGHT:
			return screenHeight != SCREEN_HEIGHT_EDEFAULT;
		case UserEnviroPackage.SCREEN_DIMENSION__SCREEN_WIDTH:
			return screenWidth != SCREEN_WIDTH_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (ScreenHeight: ");
		result.append(screenHeight);
		result.append(", ScreenWidth: ");
		result.append(screenWidth);
		result.append(')');
		return result.toString();
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //ScreenDimensionImpl
