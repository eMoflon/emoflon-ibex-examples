/**
 */
package UserEnviro.impl;

import UserEnviro.Context;
import UserEnviro.Environment;
import UserEnviro.Platform;
import UserEnviro.User;
import UserEnviro.UserEnviroPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Context</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UserEnviro.impl.ContextImpl#getUsercontext <em>Usercontext</em>}</li>
 *   <li>{@link UserEnviro.impl.ContextImpl#getEnvirocontext <em>Envirocontext</em>}</li>
 *   <li>{@link UserEnviro.impl.ContextImpl#getPlatcontext <em>Platcontext</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ContextImpl extends EObjectImpl implements Context {
	/**
	 * The cached value of the '{@link #getUsercontext() <em>Usercontext</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUsercontext()
	 * @generated
	 * @ordered
	 */
	protected EList<User> usercontext;

	/**
	 * The cached value of the '{@link #getEnvirocontext() <em>Envirocontext</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnvirocontext()
	 * @generated
	 * @ordered
	 */
	protected Environment envirocontext;

	/**
	 * The cached value of the '{@link #getPlatcontext() <em>Platcontext</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlatcontext()
	 * @generated
	 * @ordered
	 */
	protected Platform platcontext;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ContextImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.CONTEXT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<User> getUsercontext() {
		if (usercontext == null) {
			usercontext = new EObjectContainmentEList<User>(User.class, this, UserEnviroPackage.CONTEXT__USERCONTEXT);
		}
		return usercontext;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Environment getEnvirocontext() {
		return envirocontext;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetEnvirocontext(Environment newEnvirocontext, NotificationChain msgs) {
		Environment oldEnvirocontext = envirocontext;
		envirocontext = newEnvirocontext;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UserEnviroPackage.CONTEXT__ENVIROCONTEXT, oldEnvirocontext, newEnvirocontext);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEnvirocontext(Environment newEnvirocontext) {
		if (newEnvirocontext != envirocontext) {
			NotificationChain msgs = null;
			if (envirocontext != null)
				msgs = ((InternalEObject) envirocontext).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.CONTEXT__ENVIROCONTEXT, null, msgs);
			if (newEnvirocontext != null)
				msgs = ((InternalEObject) newEnvirocontext).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.CONTEXT__ENVIROCONTEXT, null, msgs);
			msgs = basicSetEnvirocontext(newEnvirocontext, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.CONTEXT__ENVIROCONTEXT,
					newEnvirocontext, newEnvirocontext));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Platform getPlatcontext() {
		return platcontext;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPlatcontext(Platform newPlatcontext, NotificationChain msgs) {
		Platform oldPlatcontext = platcontext;
		platcontext = newPlatcontext;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UserEnviroPackage.CONTEXT__PLATCONTEXT, oldPlatcontext, newPlatcontext);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlatcontext(Platform newPlatcontext) {
		if (newPlatcontext != platcontext) {
			NotificationChain msgs = null;
			if (platcontext != null)
				msgs = ((InternalEObject) platcontext).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.CONTEXT__PLATCONTEXT, null, msgs);
			if (newPlatcontext != null)
				msgs = ((InternalEObject) newPlatcontext).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UserEnviroPackage.CONTEXT__PLATCONTEXT, null, msgs);
			msgs = basicSetPlatcontext(newPlatcontext, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UserEnviroPackage.CONTEXT__PLATCONTEXT,
					newPlatcontext, newPlatcontext));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UserEnviroPackage.CONTEXT__USERCONTEXT:
			return ((InternalEList<?>) getUsercontext()).basicRemove(otherEnd, msgs);
		case UserEnviroPackage.CONTEXT__ENVIROCONTEXT:
			return basicSetEnvirocontext(null, msgs);
		case UserEnviroPackage.CONTEXT__PLATCONTEXT:
			return basicSetPlatcontext(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UserEnviroPackage.CONTEXT__USERCONTEXT:
			return getUsercontext();
		case UserEnviroPackage.CONTEXT__ENVIROCONTEXT:
			return getEnvirocontext();
		case UserEnviroPackage.CONTEXT__PLATCONTEXT:
			return getPlatcontext();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UserEnviroPackage.CONTEXT__USERCONTEXT:
			getUsercontext().clear();
			getUsercontext().addAll((Collection<? extends User>) newValue);
			return;
		case UserEnviroPackage.CONTEXT__ENVIROCONTEXT:
			setEnvirocontext((Environment) newValue);
			return;
		case UserEnviroPackage.CONTEXT__PLATCONTEXT:
			setPlatcontext((Platform) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.CONTEXT__USERCONTEXT:
			getUsercontext().clear();
			return;
		case UserEnviroPackage.CONTEXT__ENVIROCONTEXT:
			setEnvirocontext((Environment) null);
			return;
		case UserEnviroPackage.CONTEXT__PLATCONTEXT:
			setPlatcontext((Platform) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UserEnviroPackage.CONTEXT__USERCONTEXT:
			return usercontext != null && !usercontext.isEmpty();
		case UserEnviroPackage.CONTEXT__ENVIROCONTEXT:
			return envirocontext != null;
		case UserEnviroPackage.CONTEXT__PLATCONTEXT:
			return platcontext != null;
		}
		return super.eIsSet(featureID);
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //ContextImpl
