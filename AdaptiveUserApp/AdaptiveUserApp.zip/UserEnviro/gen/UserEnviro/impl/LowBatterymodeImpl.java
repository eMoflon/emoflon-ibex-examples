/**
 */
package UserEnviro.impl;

import UserEnviro.LowBatterymode;
import UserEnviro.UserEnviroPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Low Batterymode</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class LowBatterymodeImpl extends BatterymodeImpl implements LowBatterymode {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LowBatterymodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UserEnviroPackage.Literals.LOW_BATTERYMODE;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //LowBatterymodeImpl
