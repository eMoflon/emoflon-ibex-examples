/**
 */
package UserEnviro;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Platform</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UserEnviro.Platform#getDevicetype <em>Devicetype</em>}</li>
 *   <li>{@link UserEnviro.Platform#getBatterymode <em>Batterymode</em>}</li>
 *   <li>{@link UserEnviro.Platform#getScreenDim <em>Screen Dim</em>}</li>
 *   <li>{@link UserEnviro.Platform#getHardware <em>Hardware</em>}</li>
 *   <li>{@link UserEnviro.Platform#getBatteryLevel <em>Battery Level</em>}</li>
 *   <li>{@link UserEnviro.Platform#getConnectionType <em>Connection Type</em>}</li>
 *   <li>{@link UserEnviro.Platform#getConnectionSpeed <em>Connection Speed</em>}</li>
 *   <li>{@link UserEnviro.Platform#getCharging <em>Charging</em>}</li>
 * </ul>
 * </p>
 *
 * @see UserEnviro.UserEnviroPackage#getPlatform()
 * @model
 * @generated
 */
public interface Platform extends EObject {
	/**
	 * Returns the value of the '<em><b>Devicetype</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Devicetype</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Devicetype</em>' containment reference.
	 * @see #setDevicetype(Devicetype)
	 * @see UserEnviro.UserEnviroPackage#getPlatform_Devicetype()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Devicetype getDevicetype();

	/**
	 * Sets the value of the '{@link UserEnviro.Platform#getDevicetype <em>Devicetype</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Devicetype</em>' containment reference.
	 * @see #getDevicetype()
	 * @generated
	 */
	void setDevicetype(Devicetype value);

	/**
	 * Returns the value of the '<em><b>Batterymode</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Batterymode</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Batterymode</em>' reference.
	 * @see #setBatterymode(Batterymode)
	 * @see UserEnviro.UserEnviroPackage#getPlatform_Batterymode()
	 * @model
	 * @generated
	 */
	Batterymode getBatterymode();

	/**
	 * Sets the value of the '{@link UserEnviro.Platform#getBatterymode <em>Batterymode</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Batterymode</em>' reference.
	 * @see #getBatterymode()
	 * @generated
	 */
	void setBatterymode(Batterymode value);

	/**
	 * Returns the value of the '<em><b>Screen Dim</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Screen Dim</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Screen Dim</em>' reference.
	 * @see #setScreenDim(ScreenDimension)
	 * @see UserEnviro.UserEnviroPackage#getPlatform_ScreenDim()
	 * @model
	 * @generated
	 */
	ScreenDimension getScreenDim();

	/**
	 * Sets the value of the '{@link UserEnviro.Platform#getScreenDim <em>Screen Dim</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Screen Dim</em>' reference.
	 * @see #getScreenDim()
	 * @generated
	 */
	void setScreenDim(ScreenDimension value);

	/**
	 * Returns the value of the '<em><b>Hardware</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Hardware</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hardware</em>' containment reference.
	 * @see #setHardware(DeviceHardware)
	 * @see UserEnviro.UserEnviroPackage#getPlatform_Hardware()
	 * @model containment="true"
	 * @generated
	 */
	DeviceHardware getHardware();

	/**
	 * Sets the value of the '{@link UserEnviro.Platform#getHardware <em>Hardware</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Hardware</em>' containment reference.
	 * @see #getHardware()
	 * @generated
	 */
	void setHardware(DeviceHardware value);

	/**
	 * Returns the value of the '<em><b>Battery Level</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Battery Level</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Battery Level</em>' reference.
	 * @see #setBatteryLevel(BatteryLevel)
	 * @see UserEnviro.UserEnviroPackage#getPlatform_BatteryLevel()
	 * @model
	 * @generated
	 */
	BatteryLevel getBatteryLevel();

	/**
	 * Sets the value of the '{@link UserEnviro.Platform#getBatteryLevel <em>Battery Level</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Battery Level</em>' reference.
	 * @see #getBatteryLevel()
	 * @generated
	 */
	void setBatteryLevel(BatteryLevel value);

	/**
	 * Returns the value of the '<em><b>Connection Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Connection Type</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connection Type</em>' containment reference.
	 * @see #setConnectionType(ConnectionType)
	 * @see UserEnviro.UserEnviroPackage#getPlatform_ConnectionType()
	 * @model containment="true"
	 * @generated
	 */
	ConnectionType getConnectionType();

	/**
	 * Sets the value of the '{@link UserEnviro.Platform#getConnectionType <em>Connection Type</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Connection Type</em>' containment reference.
	 * @see #getConnectionType()
	 * @generated
	 */
	void setConnectionType(ConnectionType value);

	/**
	 * Returns the value of the '<em><b>Connection Speed</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Connection Speed</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connection Speed</em>' containment reference.
	 * @see #setConnectionSpeed(ConnectionSpeed)
	 * @see UserEnviro.UserEnviroPackage#getPlatform_ConnectionSpeed()
	 * @model containment="true"
	 * @generated
	 */
	ConnectionSpeed getConnectionSpeed();

	/**
	 * Sets the value of the '{@link UserEnviro.Platform#getConnectionSpeed <em>Connection Speed</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Connection Speed</em>' containment reference.
	 * @see #getConnectionSpeed()
	 * @generated
	 */
	void setConnectionSpeed(ConnectionSpeed value);

	/**
	 * Returns the value of the '<em><b>Charging</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Charging</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Charging</em>' reference.
	 * @see #setCharging(Charging)
	 * @see UserEnviro.UserEnviroPackage#getPlatform_Charging()
	 * @model
	 * @generated
	 */
	Charging getCharging();

	/**
	 * Sets the value of the '{@link UserEnviro.Platform#getCharging <em>Charging</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Charging</em>' reference.
	 * @see #getCharging()
	 * @generated
	 */
	void setCharging(Charging value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Platform
