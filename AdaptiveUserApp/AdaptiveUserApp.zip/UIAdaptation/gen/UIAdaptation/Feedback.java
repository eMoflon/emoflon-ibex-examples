/**
 */
package UIAdaptation;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Feedback</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UIAdaptation.UIAdaptationPackage#getFeedback()
 * @model
 * @generated
 */
public interface Feedback extends View { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Feedback
