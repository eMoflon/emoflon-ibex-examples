/**
 */
package UIAdaptation;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * TODO: Add documentation for Blup
 * <!-- end-model-doc -->
 * @see UIAdaptation.UIAdaptationFactory
 * @model kind="package"
 * @generated
 */
public interface UIAdaptationPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "UIAdaptation";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "platform:/resource/UIAdaptation/model/UIAdaptation.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "UIAdaptation";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	UIAdaptationPackage eINSTANCE = UIAdaptation.impl.UIAdaptationPackageImpl.init();

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.AppImpl <em>App</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.AppImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getApp()
	 * @generated
	 */
	int APP = 0;

	/**
	 * The feature id for the '<em><b>Navigation</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int APP__NAVIGATION = 0;

	/**
	 * The feature id for the '<em><b>Layout</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int APP__LAYOUT = 1;

	/**
	 * The feature id for the '<em><b>Taskset</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int APP__TASKSET = 2;

	/**
	 * The number of structural features of the '<em>App</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int APP_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>App</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int APP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.NavigationImpl <em>Navigation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.NavigationImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getNavigation()
	 * @generated
	 */
	int NAVIGATION = 1;

	/**
	 * The feature id for the '<em><b>Button</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVIGATION__BUTTON = 0;

	/**
	 * The feature id for the '<em><b>Menu</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVIGATION__MENU = 1;

	/**
	 * The feature id for the '<em><b>Driving Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVIGATION__DRIVING_MODE = 2;

	/**
	 * The number of structural features of the '<em>Navigation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVIGATION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Navigation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVIGATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.NaviTypeImpl <em>Navi Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.NaviTypeImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getNaviType()
	 * @generated
	 */
	int NAVI_TYPE = 2;

	/**
	 * The number of structural features of the '<em>Navi Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVI_TYPE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Navi Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVI_TYPE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.GridNavImpl <em>Grid Nav</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.GridNavImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getGridNav()
	 * @generated
	 */
	int GRID_NAV = 3;

	/**
	 * The feature id for the '<em><b>Activate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GRID_NAV__ACTIVATE = NAVI_TYPE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Grid Nav</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GRID_NAV_FEATURE_COUNT = NAVI_TYPE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Grid Nav</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GRID_NAV_OPERATION_COUNT = NAVI_TYPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.DefaultNavImpl <em>Default Nav</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.DefaultNavImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getDefaultNav()
	 * @generated
	 */
	int DEFAULT_NAV = 4;

	/**
	 * The number of structural features of the '<em>Default Nav</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFAULT_NAV_FEATURE_COUNT = NAVI_TYPE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Default Nav</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFAULT_NAV_OPERATION_COUNT = NAVI_TYPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.TabletNavImpl <em>Tablet Nav</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.TabletNavImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getTabletNav()
	 * @generated
	 */
	int TABLET_NAV = 5;

	/**
	 * The feature id for the '<em><b>Activate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TABLET_NAV__ACTIVATE = NAVI_TYPE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Tablet Nav</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TABLET_NAV_FEATURE_COUNT = NAVI_TYPE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Tablet Nav</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TABLET_NAV_OPERATION_COUNT = NAVI_TYPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.MinimumNavigationImpl <em>Minimum Navigation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.MinimumNavigationImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getMinimumNavigation()
	 * @generated
	 */
	int MINIMUM_NAVIGATION = 6;

	/**
	 * The feature id for the '<em><b>Button</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MINIMUM_NAVIGATION__BUTTON = NAVIGATION__BUTTON;

	/**
	 * The feature id for the '<em><b>Menu</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MINIMUM_NAVIGATION__MENU = NAVIGATION__MENU;

	/**
	 * The feature id for the '<em><b>Driving Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MINIMUM_NAVIGATION__DRIVING_MODE = NAVIGATION__DRIVING_MODE;

	/**
	 * The number of structural features of the '<em>Minimum Navigation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MINIMUM_NAVIGATION_FEATURE_COUNT = NAVIGATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Minimum Navigation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MINIMUM_NAVIGATION_OPERATION_COUNT = NAVIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.LessInformedNavImpl <em>Less Informed Nav</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.LessInformedNavImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getLessInformedNav()
	 * @generated
	 */
	int LESS_INFORMED_NAV = 7;

	/**
	 * The feature id for the '<em><b>Button</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LESS_INFORMED_NAV__BUTTON = NAVIGATION__BUTTON;

	/**
	 * The feature id for the '<em><b>Menu</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LESS_INFORMED_NAV__MENU = NAVIGATION__MENU;

	/**
	 * The feature id for the '<em><b>Driving Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LESS_INFORMED_NAV__DRIVING_MODE = NAVIGATION__DRIVING_MODE;

	/**
	 * The number of structural features of the '<em>Less Informed Nav</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LESS_INFORMED_NAV_FEATURE_COUNT = NAVIGATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Less Informed Nav</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LESS_INFORMED_NAV_OPERATION_COUNT = NAVIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.MoreInformedNavImpl <em>More Informed Nav</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.MoreInformedNavImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getMoreInformedNav()
	 * @generated
	 */
	int MORE_INFORMED_NAV = 8;

	/**
	 * The feature id for the '<em><b>Button</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MORE_INFORMED_NAV__BUTTON = NAVIGATION__BUTTON;

	/**
	 * The feature id for the '<em><b>Menu</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MORE_INFORMED_NAV__MENU = NAVIGATION__MENU;

	/**
	 * The feature id for the '<em><b>Driving Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MORE_INFORMED_NAV__DRIVING_MODE = NAVIGATION__DRIVING_MODE;

	/**
	 * The number of structural features of the '<em>More Informed Nav</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MORE_INFORMED_NAV_FEATURE_COUNT = NAVIGATION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>More Informed Nav</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MORE_INFORMED_NAV_OPERATION_COUNT = NAVIGATION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.FeedbackBarImpl <em>Feedback Bar</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.FeedbackBarImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getFeedbackBar()
	 * @generated
	 */
	int FEEDBACK_BAR = 9;

	/**
	 * The feature id for the '<em><b>Clickevent</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEEDBACK_BAR__CLICKEVENT = 0;

	/**
	 * The number of structural features of the '<em>Feedback Bar</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEEDBACK_BAR_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Feedback Bar</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEEDBACK_BAR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.ClickEventImpl <em>Click Event</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.ClickEventImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getClickEvent()
	 * @generated
	 */
	int CLICK_EVENT = 10;

	/**
	 * The feature id for the '<em><b>View</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLICK_EVENT__VIEW = 0;

	/**
	 * The number of structural features of the '<em>Click Event</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLICK_EVENT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Click Event</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLICK_EVENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.ViewImpl <em>View</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.ViewImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getView()
	 * @generated
	 */
	int VIEW = 11;

	/**
	 * The number of structural features of the '<em>View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIEW_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIEW_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.FeedbackImpl <em>Feedback</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.FeedbackImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getFeedback()
	 * @generated
	 */
	int FEEDBACK = 12;

	/**
	 * The number of structural features of the '<em>Feedback</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEEDBACK_FEATURE_COUNT = VIEW_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Feedback</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEEDBACK_OPERATION_COUNT = VIEW_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.InspirationImpl <em>Inspiration</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.InspirationImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getInspiration()
	 * @generated
	 */
	int INSPIRATION = 13;

	/**
	 * The number of structural features of the '<em>Inspiration</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSPIRATION_FEATURE_COUNT = VIEW_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Inspiration</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSPIRATION_OPERATION_COUNT = VIEW_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.LayoutImpl <em>Layout</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.LayoutImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getLayout()
	 * @generated
	 */
	int LAYOUT = 14;

	/**
	 * The feature id for the '<em><b>Color Scheme</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYOUT__COLOR_SCHEME = 0;

	/**
	 * The feature id for the '<em><b>Font Size</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYOUT__FONT_SIZE = 1;

	/**
	 * The number of structural features of the '<em>Layout</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYOUT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Layout</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYOUT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.FontSizeImpl <em>Font Size</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.FontSizeImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getFontSize()
	 * @generated
	 */
	int FONT_SIZE = 15;

	/**
	 * The number of structural features of the '<em>Font Size</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FONT_SIZE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Font Size</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FONT_SIZE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.DefaultSizeImpl <em>Default Size</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.DefaultSizeImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getDefaultSize()
	 * @generated
	 */
	int DEFAULT_SIZE = 16;

	/**
	 * The number of structural features of the '<em>Default Size</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFAULT_SIZE_FEATURE_COUNT = FONT_SIZE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Default Size</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFAULT_SIZE_OPERATION_COUNT = FONT_SIZE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.LargeSizeImpl <em>Large Size</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.LargeSizeImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getLargeSize()
	 * @generated
	 */
	int LARGE_SIZE = 17;

	/**
	 * The number of structural features of the '<em>Large Size</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LARGE_SIZE_FEATURE_COUNT = FONT_SIZE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Large Size</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LARGE_SIZE_OPERATION_COUNT = FONT_SIZE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.MiddleSizeImpl <em>Middle Size</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.MiddleSizeImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getMiddleSize()
	 * @generated
	 */
	int MIDDLE_SIZE = 18;

	/**
	 * The number of structural features of the '<em>Middle Size</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIDDLE_SIZE_FEATURE_COUNT = FONT_SIZE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Middle Size</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIDDLE_SIZE_OPERATION_COUNT = FONT_SIZE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.ColorSchemeImpl <em>Color Scheme</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.ColorSchemeImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getColorScheme()
	 * @generated
	 */
	int COLOR_SCHEME = 19;

	/**
	 * The feature id for the '<em><b>Blackn White Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLOR_SCHEME__BLACKN_WHITE_MODE = 0;

	/**
	 * The feature id for the '<em><b>Night Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLOR_SCHEME__NIGHT_MODE = 1;

	/**
	 * The number of structural features of the '<em>Color Scheme</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLOR_SCHEME_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Color Scheme</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLOR_SCHEME_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.CustomColorImpl <em>Custom Color</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.CustomColorImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getCustomColor()
	 * @generated
	 */
	int CUSTOM_COLOR = 20;

	/**
	 * The feature id for the '<em><b>Blackn White Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOM_COLOR__BLACKN_WHITE_MODE = COLOR_SCHEME__BLACKN_WHITE_MODE;

	/**
	 * The feature id for the '<em><b>Night Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOM_COLOR__NIGHT_MODE = COLOR_SCHEME__NIGHT_MODE;

	/**
	 * The number of structural features of the '<em>Custom Color</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOM_COLOR_FEATURE_COUNT = COLOR_SCHEME_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Custom Color</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOM_COLOR_OPERATION_COUNT = COLOR_SCHEME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.BlacknWhiteImpl <em>Blackn White</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.BlacknWhiteImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getBlacknWhite()
	 * @generated
	 */
	int BLACKN_WHITE = 21;

	/**
	 * The feature id for the '<em><b>Blackn White Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLACKN_WHITE__BLACKN_WHITE_MODE = COLOR_SCHEME__BLACKN_WHITE_MODE;

	/**
	 * The feature id for the '<em><b>Night Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLACKN_WHITE__NIGHT_MODE = COLOR_SCHEME__NIGHT_MODE;

	/**
	 * The number of structural features of the '<em>Blackn White</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLACKN_WHITE_FEATURE_COUNT = COLOR_SCHEME_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Blackn White</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLACKN_WHITE_OPERATION_COUNT = COLOR_SCHEME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.MonoChromaticImpl <em>Mono Chromatic</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.MonoChromaticImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getMonoChromatic()
	 * @generated
	 */
	int MONO_CHROMATIC = 22;

	/**
	 * The feature id for the '<em><b>Blackn White Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONO_CHROMATIC__BLACKN_WHITE_MODE = COLOR_SCHEME__BLACKN_WHITE_MODE;

	/**
	 * The feature id for the '<em><b>Night Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONO_CHROMATIC__NIGHT_MODE = COLOR_SCHEME__NIGHT_MODE;

	/**
	 * The number of structural features of the '<em>Mono Chromatic</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONO_CHROMATIC_FEATURE_COUNT = COLOR_SCHEME_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Mono Chromatic</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONO_CHROMATIC_OPERATION_COUNT = COLOR_SCHEME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.NightModeSchemeImpl <em>Night Mode Scheme</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.NightModeSchemeImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getNightModeScheme()
	 * @generated
	 */
	int NIGHT_MODE_SCHEME = 23;

	/**
	 * The feature id for the '<em><b>Blackn White Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NIGHT_MODE_SCHEME__BLACKN_WHITE_MODE = COLOR_SCHEME__BLACKN_WHITE_MODE;

	/**
	 * The feature id for the '<em><b>Night Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NIGHT_MODE_SCHEME__NIGHT_MODE = COLOR_SCHEME__NIGHT_MODE;

	/**
	 * The number of structural features of the '<em>Night Mode Scheme</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NIGHT_MODE_SCHEME_FEATURE_COUNT = COLOR_SCHEME_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Night Mode Scheme</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NIGHT_MODE_SCHEME_OPERATION_COUNT = COLOR_SCHEME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.TaskFeatureImpl <em>Task Feature</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.TaskFeatureImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getTaskFeature()
	 * @generated
	 */
	int TASK_FEATURE = 24;

	/**
	 * The feature id for the '<em><b>Read Email</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_FEATURE__READ_EMAIL = 0;

	/**
	 * The feature id for the '<em><b>Show Email</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_FEATURE__SHOW_EMAIL = 1;

	/**
	 * The feature id for the '<em><b>Write Email</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_FEATURE__WRITE_EMAIL = 2;

	/**
	 * The feature id for the '<em><b>Menu</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_FEATURE__MENU = 3;

	/**
	 * The feature id for the '<em><b>Vocal UI</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_FEATURE__VOCAL_UI = 4;

	/**
	 * The number of structural features of the '<em>Task Feature</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_FEATURE_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Task Feature</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TASK_FEATURE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.MenuImpl <em>Menu</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.MenuImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getMenu()
	 * @generated
	 */
	int MENU = 25;

	/**
	 * The feature id for the '<em><b>Menu Enum</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MENU__MENU_ENUM = 0;

	/**
	 * The number of structural features of the '<em>Menu</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MENU_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Menu</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MENU_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.AttachmentsImpl <em>Attachments</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.AttachmentsImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getAttachments()
	 * @generated
	 */
	int ATTACHMENTS = 26;

	/**
	 * The feature id for the '<em><b>Auto Download</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHMENTS__AUTO_DOWNLOAD = 0;

	/**
	 * The number of structural features of the '<em>Attachments</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHMENTS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Attachments</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHMENTS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.AutoDownloadImpl <em>Auto Download</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.AutoDownloadImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getAutoDownload()
	 * @generated
	 */
	int AUTO_DOWNLOAD = 27;

	/**
	 * The feature id for the '<em><b>Enable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTO_DOWNLOAD__ENABLE = 0;

	/**
	 * The number of structural features of the '<em>Auto Download</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTO_DOWNLOAD_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Auto Download</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTO_DOWNLOAD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.ReadEmailImpl <em>Read Email</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.ReadEmailImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getReadEmail()
	 * @generated
	 */
	int READ_EMAIL = 28;

	/**
	 * The feature id for the '<em><b>Attachments</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ_EMAIL__ATTACHMENTS = 0;

	/**
	 * The number of structural features of the '<em>Read Email</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ_EMAIL_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Read Email</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int READ_EMAIL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.ShowEmailImpl <em>Show Email</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.ShowEmailImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getShowEmail()
	 * @generated
	 */
	int SHOW_EMAIL = 29;

	/**
	 * The feature id for the '<em><b>Email Form</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOW_EMAIL__EMAIL_FORM = 0;

	/**
	 * The number of structural features of the '<em>Show Email</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOW_EMAIL_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Show Email</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOW_EMAIL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.WriteEmailImpl <em>Write Email</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.WriteEmailImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getWriteEmail()
	 * @generated
	 */
	int WRITE_EMAIL = 30;

	/**
	 * The number of structural features of the '<em>Write Email</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WRITE_EMAIL_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Write Email</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WRITE_EMAIL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.EmailFormImpl <em>Email Form</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.EmailFormImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getEmailForm()
	 * @generated
	 */
	int EMAIL_FORM = 31;

	/**
	 * The feature id for the '<em><b>Html</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMAIL_FORM__HTML = 0;

	/**
	 * The feature id for the '<em><b>Text Form</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMAIL_FORM__TEXT_FORM = 1;

	/**
	 * The number of structural features of the '<em>Email Form</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMAIL_FORM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Email Form</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMAIL_FORM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.HTMLImpl <em>HTML</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.HTMLImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getHTML()
	 * @generated
	 */
	int HTML = 32;

	/**
	 * The number of structural features of the '<em>HTML</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HTML_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>HTML</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HTML_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.impl.TextFormImpl <em>Text Form</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.impl.TextFormImpl
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getTextForm()
	 * @generated
	 */
	int TEXT_FORM = 33;

	/**
	 * The number of structural features of the '<em>Text Form</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_FORM_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Text Form</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_FORM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link UIAdaptation.MenuEnum <em>Menu Enum</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see UIAdaptation.MenuEnum
	 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getMenuEnum()
	 * @generated
	 */
	int MENU_ENUM = 34;

	/**
	 * Returns the meta object for class '{@link UIAdaptation.App <em>App</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>App</em>'.
	 * @see UIAdaptation.App
	 * @generated
	 */
	EClass getApp();

	/**
	 * Returns the meta object for the containment reference '{@link UIAdaptation.App#getNavigation <em>Navigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Navigation</em>'.
	 * @see UIAdaptation.App#getNavigation()
	 * @see #getApp()
	 * @generated
	 */
	EReference getApp_Navigation();

	/**
	 * Returns the meta object for the containment reference '{@link UIAdaptation.App#getLayout <em>Layout</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Layout</em>'.
	 * @see UIAdaptation.App#getLayout()
	 * @see #getApp()
	 * @generated
	 */
	EReference getApp_Layout();

	/**
	 * Returns the meta object for the containment reference '{@link UIAdaptation.App#getTaskset <em>Taskset</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Taskset</em>'.
	 * @see UIAdaptation.App#getTaskset()
	 * @see #getApp()
	 * @generated
	 */
	EReference getApp_Taskset();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.Navigation <em>Navigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Navigation</em>'.
	 * @see UIAdaptation.Navigation
	 * @generated
	 */
	EClass getNavigation();

	/**
	 * Returns the meta object for the containment reference '{@link UIAdaptation.Navigation#getButton <em>Button</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Button</em>'.
	 * @see UIAdaptation.Navigation#getButton()
	 * @see #getNavigation()
	 * @generated
	 */
	EReference getNavigation_Button();

	/**
	 * Returns the meta object for the reference '{@link UIAdaptation.Navigation#getMenu <em>Menu</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Menu</em>'.
	 * @see UIAdaptation.Navigation#getMenu()
	 * @see #getNavigation()
	 * @generated
	 */
	EReference getNavigation_Menu();

	/**
	 * Returns the meta object for the attribute '{@link UIAdaptation.Navigation#isDrivingMode <em>Driving Mode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Driving Mode</em>'.
	 * @see UIAdaptation.Navigation#isDrivingMode()
	 * @see #getNavigation()
	 * @generated
	 */
	EAttribute getNavigation_DrivingMode();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.NaviType <em>Navi Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Navi Type</em>'.
	 * @see UIAdaptation.NaviType
	 * @generated
	 */
	EClass getNaviType();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.GridNav <em>Grid Nav</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Grid Nav</em>'.
	 * @see UIAdaptation.GridNav
	 * @generated
	 */
	EClass getGridNav();

	/**
	 * Returns the meta object for the attribute '{@link UIAdaptation.GridNav#isActivate <em>Activate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Activate</em>'.
	 * @see UIAdaptation.GridNav#isActivate()
	 * @see #getGridNav()
	 * @generated
	 */
	EAttribute getGridNav_Activate();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.DefaultNav <em>Default Nav</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Default Nav</em>'.
	 * @see UIAdaptation.DefaultNav
	 * @generated
	 */
	EClass getDefaultNav();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.TabletNav <em>Tablet Nav</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tablet Nav</em>'.
	 * @see UIAdaptation.TabletNav
	 * @generated
	 */
	EClass getTabletNav();

	/**
	 * Returns the meta object for the attribute '{@link UIAdaptation.TabletNav#isActivate <em>Activate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Activate</em>'.
	 * @see UIAdaptation.TabletNav#isActivate()
	 * @see #getTabletNav()
	 * @generated
	 */
	EAttribute getTabletNav_Activate();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.MinimumNavigation <em>Minimum Navigation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Minimum Navigation</em>'.
	 * @see UIAdaptation.MinimumNavigation
	 * @generated
	 */
	EClass getMinimumNavigation();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.LessInformedNav <em>Less Informed Nav</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Less Informed Nav</em>'.
	 * @see UIAdaptation.LessInformedNav
	 * @generated
	 */
	EClass getLessInformedNav();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.MoreInformedNav <em>More Informed Nav</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>More Informed Nav</em>'.
	 * @see UIAdaptation.MoreInformedNav
	 * @generated
	 */
	EClass getMoreInformedNav();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.FeedbackBar <em>Feedback Bar</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Feedback Bar</em>'.
	 * @see UIAdaptation.FeedbackBar
	 * @generated
	 */
	EClass getFeedbackBar();

	/**
	 * Returns the meta object for the reference '{@link UIAdaptation.FeedbackBar#getClickevent <em>Clickevent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Clickevent</em>'.
	 * @see UIAdaptation.FeedbackBar#getClickevent()
	 * @see #getFeedbackBar()
	 * @generated
	 */
	EReference getFeedbackBar_Clickevent();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.ClickEvent <em>Click Event</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Click Event</em>'.
	 * @see UIAdaptation.ClickEvent
	 * @generated
	 */
	EClass getClickEvent();

	/**
	 * Returns the meta object for the reference list '{@link UIAdaptation.ClickEvent#getView <em>View</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>View</em>'.
	 * @see UIAdaptation.ClickEvent#getView()
	 * @see #getClickEvent()
	 * @generated
	 */
	EReference getClickEvent_View();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.View <em>View</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>View</em>'.
	 * @see UIAdaptation.View
	 * @generated
	 */
	EClass getView();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.Feedback <em>Feedback</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Feedback</em>'.
	 * @see UIAdaptation.Feedback
	 * @generated
	 */
	EClass getFeedback();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.Inspiration <em>Inspiration</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Inspiration</em>'.
	 * @see UIAdaptation.Inspiration
	 * @generated
	 */
	EClass getInspiration();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.Layout <em>Layout</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Layout</em>'.
	 * @see UIAdaptation.Layout
	 * @generated
	 */
	EClass getLayout();

	/**
	 * Returns the meta object for the containment reference '{@link UIAdaptation.Layout#getColorScheme <em>Color Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Color Scheme</em>'.
	 * @see UIAdaptation.Layout#getColorScheme()
	 * @see #getLayout()
	 * @generated
	 */
	EReference getLayout_ColorScheme();

	/**
	 * Returns the meta object for the reference '{@link UIAdaptation.Layout#getFontSize <em>Font Size</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Font Size</em>'.
	 * @see UIAdaptation.Layout#getFontSize()
	 * @see #getLayout()
	 * @generated
	 */
	EReference getLayout_FontSize();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.FontSize <em>Font Size</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Font Size</em>'.
	 * @see UIAdaptation.FontSize
	 * @generated
	 */
	EClass getFontSize();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.DefaultSize <em>Default Size</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Default Size</em>'.
	 * @see UIAdaptation.DefaultSize
	 * @generated
	 */
	EClass getDefaultSize();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.LargeSize <em>Large Size</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Large Size</em>'.
	 * @see UIAdaptation.LargeSize
	 * @generated
	 */
	EClass getLargeSize();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.MiddleSize <em>Middle Size</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Middle Size</em>'.
	 * @see UIAdaptation.MiddleSize
	 * @generated
	 */
	EClass getMiddleSize();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.ColorScheme <em>Color Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Color Scheme</em>'.
	 * @see UIAdaptation.ColorScheme
	 * @generated
	 */
	EClass getColorScheme();

	/**
	 * Returns the meta object for the attribute '{@link UIAdaptation.ColorScheme#isBlacknWhiteMode <em>Blackn White Mode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Blackn White Mode</em>'.
	 * @see UIAdaptation.ColorScheme#isBlacknWhiteMode()
	 * @see #getColorScheme()
	 * @generated
	 */
	EAttribute getColorScheme_BlacknWhiteMode();

	/**
	 * Returns the meta object for the attribute '{@link UIAdaptation.ColorScheme#isNightMode <em>Night Mode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Night Mode</em>'.
	 * @see UIAdaptation.ColorScheme#isNightMode()
	 * @see #getColorScheme()
	 * @generated
	 */
	EAttribute getColorScheme_NightMode();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.CustomColor <em>Custom Color</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Custom Color</em>'.
	 * @see UIAdaptation.CustomColor
	 * @generated
	 */
	EClass getCustomColor();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.BlacknWhite <em>Blackn White</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Blackn White</em>'.
	 * @see UIAdaptation.BlacknWhite
	 * @generated
	 */
	EClass getBlacknWhite();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.MonoChromatic <em>Mono Chromatic</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Mono Chromatic</em>'.
	 * @see UIAdaptation.MonoChromatic
	 * @generated
	 */
	EClass getMonoChromatic();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.NightModeScheme <em>Night Mode Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Night Mode Scheme</em>'.
	 * @see UIAdaptation.NightModeScheme
	 * @generated
	 */
	EClass getNightModeScheme();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.TaskFeature <em>Task Feature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Task Feature</em>'.
	 * @see UIAdaptation.TaskFeature
	 * @generated
	 */
	EClass getTaskFeature();

	/**
	 * Returns the meta object for the containment reference '{@link UIAdaptation.TaskFeature#getReadEmail <em>Read Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Read Email</em>'.
	 * @see UIAdaptation.TaskFeature#getReadEmail()
	 * @see #getTaskFeature()
	 * @generated
	 */
	EReference getTaskFeature_ReadEmail();

	/**
	 * Returns the meta object for the containment reference '{@link UIAdaptation.TaskFeature#getShowEmail <em>Show Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Show Email</em>'.
	 * @see UIAdaptation.TaskFeature#getShowEmail()
	 * @see #getTaskFeature()
	 * @generated
	 */
	EReference getTaskFeature_ShowEmail();

	/**
	 * Returns the meta object for the containment reference '{@link UIAdaptation.TaskFeature#getWriteEmail <em>Write Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Write Email</em>'.
	 * @see UIAdaptation.TaskFeature#getWriteEmail()
	 * @see #getTaskFeature()
	 * @generated
	 */
	EReference getTaskFeature_WriteEmail();

	/**
	 * Returns the meta object for the containment reference '{@link UIAdaptation.TaskFeature#getMenu <em>Menu</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Menu</em>'.
	 * @see UIAdaptation.TaskFeature#getMenu()
	 * @see #getTaskFeature()
	 * @generated
	 */
	EReference getTaskFeature_Menu();

	/**
	 * Returns the meta object for the attribute '{@link UIAdaptation.TaskFeature#isVocalUI <em>Vocal UI</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Vocal UI</em>'.
	 * @see UIAdaptation.TaskFeature#isVocalUI()
	 * @see #getTaskFeature()
	 * @generated
	 */
	EAttribute getTaskFeature_VocalUI();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.Menu <em>Menu</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Menu</em>'.
	 * @see UIAdaptation.Menu
	 * @generated
	 */
	EClass getMenu();

	/**
	 * Returns the meta object for the attribute '{@link UIAdaptation.Menu#getMenuEnum <em>Menu Enum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Menu Enum</em>'.
	 * @see UIAdaptation.Menu#getMenuEnum()
	 * @see #getMenu()
	 * @generated
	 */
	EAttribute getMenu_MenuEnum();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.Attachments <em>Attachments</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attachments</em>'.
	 * @see UIAdaptation.Attachments
	 * @generated
	 */
	EClass getAttachments();

	/**
	 * Returns the meta object for the reference '{@link UIAdaptation.Attachments#getAutoDownload <em>Auto Download</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Auto Download</em>'.
	 * @see UIAdaptation.Attachments#getAutoDownload()
	 * @see #getAttachments()
	 * @generated
	 */
	EReference getAttachments_AutoDownload();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.AutoDownload <em>Auto Download</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Auto Download</em>'.
	 * @see UIAdaptation.AutoDownload
	 * @generated
	 */
	EClass getAutoDownload();

	/**
	 * Returns the meta object for the attribute '{@link UIAdaptation.AutoDownload#isEnable <em>Enable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Enable</em>'.
	 * @see UIAdaptation.AutoDownload#isEnable()
	 * @see #getAutoDownload()
	 * @generated
	 */
	EAttribute getAutoDownload_Enable();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.ReadEmail <em>Read Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Read Email</em>'.
	 * @see UIAdaptation.ReadEmail
	 * @generated
	 */
	EClass getReadEmail();

	/**
	 * Returns the meta object for the reference '{@link UIAdaptation.ReadEmail#getAttachments <em>Attachments</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Attachments</em>'.
	 * @see UIAdaptation.ReadEmail#getAttachments()
	 * @see #getReadEmail()
	 * @generated
	 */
	EReference getReadEmail_Attachments();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.ShowEmail <em>Show Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Show Email</em>'.
	 * @see UIAdaptation.ShowEmail
	 * @generated
	 */
	EClass getShowEmail();

	/**
	 * Returns the meta object for the reference '{@link UIAdaptation.ShowEmail#getEmailForm <em>Email Form</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Email Form</em>'.
	 * @see UIAdaptation.ShowEmail#getEmailForm()
	 * @see #getShowEmail()
	 * @generated
	 */
	EReference getShowEmail_EmailForm();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.WriteEmail <em>Write Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Write Email</em>'.
	 * @see UIAdaptation.WriteEmail
	 * @generated
	 */
	EClass getWriteEmail();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.EmailForm <em>Email Form</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Email Form</em>'.
	 * @see UIAdaptation.EmailForm
	 * @generated
	 */
	EClass getEmailForm();

	/**
	 * Returns the meta object for the containment reference '{@link UIAdaptation.EmailForm#getHtml <em>Html</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Html</em>'.
	 * @see UIAdaptation.EmailForm#getHtml()
	 * @see #getEmailForm()
	 * @generated
	 */
	EReference getEmailForm_Html();

	/**
	 * Returns the meta object for the containment reference '{@link UIAdaptation.EmailForm#getTextForm <em>Text Form</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Text Form</em>'.
	 * @see UIAdaptation.EmailForm#getTextForm()
	 * @see #getEmailForm()
	 * @generated
	 */
	EReference getEmailForm_TextForm();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.HTML <em>HTML</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>HTML</em>'.
	 * @see UIAdaptation.HTML
	 * @generated
	 */
	EClass getHTML();

	/**
	 * Returns the meta object for class '{@link UIAdaptation.TextForm <em>Text Form</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Text Form</em>'.
	 * @see UIAdaptation.TextForm
	 * @generated
	 */
	EClass getTextForm();

	/**
	 * Returns the meta object for enum '{@link UIAdaptation.MenuEnum <em>Menu Enum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Menu Enum</em>'.
	 * @see UIAdaptation.MenuEnum
	 * @generated
	 */
	EEnum getMenuEnum();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	UIAdaptationFactory getUIAdaptationFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.AppImpl <em>App</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.AppImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getApp()
		 * @generated
		 */
		EClass APP = eINSTANCE.getApp();

		/**
		 * The meta object literal for the '<em><b>Navigation</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference APP__NAVIGATION = eINSTANCE.getApp_Navigation();

		/**
		 * The meta object literal for the '<em><b>Layout</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference APP__LAYOUT = eINSTANCE.getApp_Layout();

		/**
		 * The meta object literal for the '<em><b>Taskset</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference APP__TASKSET = eINSTANCE.getApp_Taskset();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.NavigationImpl <em>Navigation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.NavigationImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getNavigation()
		 * @generated
		 */
		EClass NAVIGATION = eINSTANCE.getNavigation();

		/**
		 * The meta object literal for the '<em><b>Button</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NAVIGATION__BUTTON = eINSTANCE.getNavigation_Button();

		/**
		 * The meta object literal for the '<em><b>Menu</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NAVIGATION__MENU = eINSTANCE.getNavigation_Menu();

		/**
		 * The meta object literal for the '<em><b>Driving Mode</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NAVIGATION__DRIVING_MODE = eINSTANCE.getNavigation_DrivingMode();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.NaviTypeImpl <em>Navi Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.NaviTypeImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getNaviType()
		 * @generated
		 */
		EClass NAVI_TYPE = eINSTANCE.getNaviType();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.GridNavImpl <em>Grid Nav</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.GridNavImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getGridNav()
		 * @generated
		 */
		EClass GRID_NAV = eINSTANCE.getGridNav();

		/**
		 * The meta object literal for the '<em><b>Activate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GRID_NAV__ACTIVATE = eINSTANCE.getGridNav_Activate();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.DefaultNavImpl <em>Default Nav</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.DefaultNavImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getDefaultNav()
		 * @generated
		 */
		EClass DEFAULT_NAV = eINSTANCE.getDefaultNav();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.TabletNavImpl <em>Tablet Nav</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.TabletNavImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getTabletNav()
		 * @generated
		 */
		EClass TABLET_NAV = eINSTANCE.getTabletNav();

		/**
		 * The meta object literal for the '<em><b>Activate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TABLET_NAV__ACTIVATE = eINSTANCE.getTabletNav_Activate();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.MinimumNavigationImpl <em>Minimum Navigation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.MinimumNavigationImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getMinimumNavigation()
		 * @generated
		 */
		EClass MINIMUM_NAVIGATION = eINSTANCE.getMinimumNavigation();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.LessInformedNavImpl <em>Less Informed Nav</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.LessInformedNavImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getLessInformedNav()
		 * @generated
		 */
		EClass LESS_INFORMED_NAV = eINSTANCE.getLessInformedNav();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.MoreInformedNavImpl <em>More Informed Nav</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.MoreInformedNavImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getMoreInformedNav()
		 * @generated
		 */
		EClass MORE_INFORMED_NAV = eINSTANCE.getMoreInformedNav();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.FeedbackBarImpl <em>Feedback Bar</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.FeedbackBarImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getFeedbackBar()
		 * @generated
		 */
		EClass FEEDBACK_BAR = eINSTANCE.getFeedbackBar();

		/**
		 * The meta object literal for the '<em><b>Clickevent</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEEDBACK_BAR__CLICKEVENT = eINSTANCE.getFeedbackBar_Clickevent();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.ClickEventImpl <em>Click Event</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.ClickEventImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getClickEvent()
		 * @generated
		 */
		EClass CLICK_EVENT = eINSTANCE.getClickEvent();

		/**
		 * The meta object literal for the '<em><b>View</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLICK_EVENT__VIEW = eINSTANCE.getClickEvent_View();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.ViewImpl <em>View</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.ViewImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getView()
		 * @generated
		 */
		EClass VIEW = eINSTANCE.getView();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.FeedbackImpl <em>Feedback</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.FeedbackImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getFeedback()
		 * @generated
		 */
		EClass FEEDBACK = eINSTANCE.getFeedback();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.InspirationImpl <em>Inspiration</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.InspirationImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getInspiration()
		 * @generated
		 */
		EClass INSPIRATION = eINSTANCE.getInspiration();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.LayoutImpl <em>Layout</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.LayoutImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getLayout()
		 * @generated
		 */
		EClass LAYOUT = eINSTANCE.getLayout();

		/**
		 * The meta object literal for the '<em><b>Color Scheme</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LAYOUT__COLOR_SCHEME = eINSTANCE.getLayout_ColorScheme();

		/**
		 * The meta object literal for the '<em><b>Font Size</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LAYOUT__FONT_SIZE = eINSTANCE.getLayout_FontSize();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.FontSizeImpl <em>Font Size</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.FontSizeImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getFontSize()
		 * @generated
		 */
		EClass FONT_SIZE = eINSTANCE.getFontSize();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.DefaultSizeImpl <em>Default Size</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.DefaultSizeImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getDefaultSize()
		 * @generated
		 */
		EClass DEFAULT_SIZE = eINSTANCE.getDefaultSize();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.LargeSizeImpl <em>Large Size</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.LargeSizeImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getLargeSize()
		 * @generated
		 */
		EClass LARGE_SIZE = eINSTANCE.getLargeSize();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.MiddleSizeImpl <em>Middle Size</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.MiddleSizeImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getMiddleSize()
		 * @generated
		 */
		EClass MIDDLE_SIZE = eINSTANCE.getMiddleSize();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.ColorSchemeImpl <em>Color Scheme</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.ColorSchemeImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getColorScheme()
		 * @generated
		 */
		EClass COLOR_SCHEME = eINSTANCE.getColorScheme();

		/**
		 * The meta object literal for the '<em><b>Blackn White Mode</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLOR_SCHEME__BLACKN_WHITE_MODE = eINSTANCE.getColorScheme_BlacknWhiteMode();

		/**
		 * The meta object literal for the '<em><b>Night Mode</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLOR_SCHEME__NIGHT_MODE = eINSTANCE.getColorScheme_NightMode();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.CustomColorImpl <em>Custom Color</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.CustomColorImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getCustomColor()
		 * @generated
		 */
		EClass CUSTOM_COLOR = eINSTANCE.getCustomColor();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.BlacknWhiteImpl <em>Blackn White</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.BlacknWhiteImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getBlacknWhite()
		 * @generated
		 */
		EClass BLACKN_WHITE = eINSTANCE.getBlacknWhite();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.MonoChromaticImpl <em>Mono Chromatic</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.MonoChromaticImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getMonoChromatic()
		 * @generated
		 */
		EClass MONO_CHROMATIC = eINSTANCE.getMonoChromatic();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.NightModeSchemeImpl <em>Night Mode Scheme</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.NightModeSchemeImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getNightModeScheme()
		 * @generated
		 */
		EClass NIGHT_MODE_SCHEME = eINSTANCE.getNightModeScheme();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.TaskFeatureImpl <em>Task Feature</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.TaskFeatureImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getTaskFeature()
		 * @generated
		 */
		EClass TASK_FEATURE = eINSTANCE.getTaskFeature();

		/**
		 * The meta object literal for the '<em><b>Read Email</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TASK_FEATURE__READ_EMAIL = eINSTANCE.getTaskFeature_ReadEmail();

		/**
		 * The meta object literal for the '<em><b>Show Email</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TASK_FEATURE__SHOW_EMAIL = eINSTANCE.getTaskFeature_ShowEmail();

		/**
		 * The meta object literal for the '<em><b>Write Email</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TASK_FEATURE__WRITE_EMAIL = eINSTANCE.getTaskFeature_WriteEmail();

		/**
		 * The meta object literal for the '<em><b>Menu</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TASK_FEATURE__MENU = eINSTANCE.getTaskFeature_Menu();

		/**
		 * The meta object literal for the '<em><b>Vocal UI</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TASK_FEATURE__VOCAL_UI = eINSTANCE.getTaskFeature_VocalUI();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.MenuImpl <em>Menu</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.MenuImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getMenu()
		 * @generated
		 */
		EClass MENU = eINSTANCE.getMenu();

		/**
		 * The meta object literal for the '<em><b>Menu Enum</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MENU__MENU_ENUM = eINSTANCE.getMenu_MenuEnum();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.AttachmentsImpl <em>Attachments</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.AttachmentsImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getAttachments()
		 * @generated
		 */
		EClass ATTACHMENTS = eINSTANCE.getAttachments();

		/**
		 * The meta object literal for the '<em><b>Auto Download</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHMENTS__AUTO_DOWNLOAD = eINSTANCE.getAttachments_AutoDownload();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.AutoDownloadImpl <em>Auto Download</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.AutoDownloadImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getAutoDownload()
		 * @generated
		 */
		EClass AUTO_DOWNLOAD = eINSTANCE.getAutoDownload();

		/**
		 * The meta object literal for the '<em><b>Enable</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUTO_DOWNLOAD__ENABLE = eINSTANCE.getAutoDownload_Enable();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.ReadEmailImpl <em>Read Email</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.ReadEmailImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getReadEmail()
		 * @generated
		 */
		EClass READ_EMAIL = eINSTANCE.getReadEmail();

		/**
		 * The meta object literal for the '<em><b>Attachments</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference READ_EMAIL__ATTACHMENTS = eINSTANCE.getReadEmail_Attachments();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.ShowEmailImpl <em>Show Email</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.ShowEmailImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getShowEmail()
		 * @generated
		 */
		EClass SHOW_EMAIL = eINSTANCE.getShowEmail();

		/**
		 * The meta object literal for the '<em><b>Email Form</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHOW_EMAIL__EMAIL_FORM = eINSTANCE.getShowEmail_EmailForm();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.WriteEmailImpl <em>Write Email</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.WriteEmailImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getWriteEmail()
		 * @generated
		 */
		EClass WRITE_EMAIL = eINSTANCE.getWriteEmail();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.EmailFormImpl <em>Email Form</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.EmailFormImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getEmailForm()
		 * @generated
		 */
		EClass EMAIL_FORM = eINSTANCE.getEmailForm();

		/**
		 * The meta object literal for the '<em><b>Html</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EMAIL_FORM__HTML = eINSTANCE.getEmailForm_Html();

		/**
		 * The meta object literal for the '<em><b>Text Form</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EMAIL_FORM__TEXT_FORM = eINSTANCE.getEmailForm_TextForm();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.HTMLImpl <em>HTML</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.HTMLImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getHTML()
		 * @generated
		 */
		EClass HTML = eINSTANCE.getHTML();

		/**
		 * The meta object literal for the '{@link UIAdaptation.impl.TextFormImpl <em>Text Form</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.impl.TextFormImpl
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getTextForm()
		 * @generated
		 */
		EClass TEXT_FORM = eINSTANCE.getTextForm();

		/**
		 * The meta object literal for the '{@link UIAdaptation.MenuEnum <em>Menu Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see UIAdaptation.MenuEnum
		 * @see UIAdaptation.impl.UIAdaptationPackageImpl#getMenuEnum()
		 * @generated
		 */
		EEnum MENU_ENUM = eINSTANCE.getMenuEnum();

	}

} //UIAdaptationPackage
