/**
 */
package UIAdaptation;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Grid Nav</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UIAdaptation.GridNav#isActivate <em>Activate</em>}</li>
 * </ul>
 * </p>
 *
 * @see UIAdaptation.UIAdaptationPackage#getGridNav()
 * @model
 * @generated
 */
public interface GridNav extends NaviType {
	/**
	 * Returns the value of the '<em><b>Activate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Activate</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Activate</em>' attribute.
	 * @see #setActivate(boolean)
	 * @see UIAdaptation.UIAdaptationPackage#getGridNav_Activate()
	 * @model
	 * @generated
	 */
	boolean isActivate();

	/**
	 * Sets the value of the '{@link UIAdaptation.GridNav#isActivate <em>Activate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Activate</em>' attribute.
	 * @see #isActivate()
	 * @generated
	 */
	void setActivate(boolean value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // GridNav
