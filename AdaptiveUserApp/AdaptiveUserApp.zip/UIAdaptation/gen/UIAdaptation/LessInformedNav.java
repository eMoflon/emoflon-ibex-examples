/**
 */
package UIAdaptation;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Less Informed Nav</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UIAdaptation.UIAdaptationPackage#getLessInformedNav()
 * @model
 * @generated
 */
public interface LessInformedNav extends Navigation { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // LessInformedNav
