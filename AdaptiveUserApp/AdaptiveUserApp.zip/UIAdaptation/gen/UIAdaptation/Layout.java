/**
 */
package UIAdaptation;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Layout</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UIAdaptation.Layout#getColorScheme <em>Color Scheme</em>}</li>
 *   <li>{@link UIAdaptation.Layout#getFontSize <em>Font Size</em>}</li>
 * </ul>
 * </p>
 *
 * @see UIAdaptation.UIAdaptationPackage#getLayout()
 * @model
 * @generated
 */
public interface Layout extends EObject {
	/**
	 * Returns the value of the '<em><b>Color Scheme</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Color Scheme</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Color Scheme</em>' containment reference.
	 * @see #setColorScheme(ColorScheme)
	 * @see UIAdaptation.UIAdaptationPackage#getLayout_ColorScheme()
	 * @model containment="true" required="true"
	 * @generated
	 */
	ColorScheme getColorScheme();

	/**
	 * Sets the value of the '{@link UIAdaptation.Layout#getColorScheme <em>Color Scheme</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Color Scheme</em>' containment reference.
	 * @see #getColorScheme()
	 * @generated
	 */
	void setColorScheme(ColorScheme value);

	/**
	 * Returns the value of the '<em><b>Font Size</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Font Size</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Font Size</em>' reference.
	 * @see #setFontSize(FontSize)
	 * @see UIAdaptation.UIAdaptationPackage#getLayout_FontSize()
	 * @model required="true"
	 * @generated
	 */
	FontSize getFontSize();

	/**
	 * Sets the value of the '{@link UIAdaptation.Layout#getFontSize <em>Font Size</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Font Size</em>' reference.
	 * @see #getFontSize()
	 * @generated
	 */
	void setFontSize(FontSize value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Layout
