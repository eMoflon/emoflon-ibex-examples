/**
 */
package UIAdaptation.impl;

import UIAdaptation.DefaultSize;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Default Size</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class DefaultSizeImpl extends FontSizeImpl implements DefaultSize {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DefaultSizeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.DEFAULT_SIZE;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //DefaultSizeImpl
