/**
 */
package UIAdaptation.impl;

import UIAdaptation.ColorScheme;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Color Scheme</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UIAdaptation.impl.ColorSchemeImpl#isBlacknWhiteMode <em>Blackn White Mode</em>}</li>
 *   <li>{@link UIAdaptation.impl.ColorSchemeImpl#isNightMode <em>Night Mode</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class ColorSchemeImpl extends EObjectImpl implements ColorScheme {
	/**
	 * The default value of the '{@link #isBlacknWhiteMode() <em>Blackn White Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isBlacknWhiteMode()
	 * @generated
	 * @ordered
	 */
	protected static final boolean BLACKN_WHITE_MODE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isBlacknWhiteMode() <em>Blackn White Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isBlacknWhiteMode()
	 * @generated
	 * @ordered
	 */
	protected boolean blacknWhiteMode = BLACKN_WHITE_MODE_EDEFAULT;

	/**
	 * The default value of the '{@link #isNightMode() <em>Night Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isNightMode()
	 * @generated
	 * @ordered
	 */
	protected static final boolean NIGHT_MODE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isNightMode() <em>Night Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isNightMode()
	 * @generated
	 * @ordered
	 */
	protected boolean nightMode = NIGHT_MODE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ColorSchemeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.COLOR_SCHEME;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isBlacknWhiteMode() {
		return blacknWhiteMode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBlacknWhiteMode(boolean newBlacknWhiteMode) {
		boolean oldBlacknWhiteMode = blacknWhiteMode;
		blacknWhiteMode = newBlacknWhiteMode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.COLOR_SCHEME__BLACKN_WHITE_MODE,
					oldBlacknWhiteMode, blacknWhiteMode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isNightMode() {
		return nightMode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNightMode(boolean newNightMode) {
		boolean oldNightMode = nightMode;
		nightMode = newNightMode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.COLOR_SCHEME__NIGHT_MODE,
					oldNightMode, nightMode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UIAdaptationPackage.COLOR_SCHEME__BLACKN_WHITE_MODE:
			return isBlacknWhiteMode();
		case UIAdaptationPackage.COLOR_SCHEME__NIGHT_MODE:
			return isNightMode();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UIAdaptationPackage.COLOR_SCHEME__BLACKN_WHITE_MODE:
			setBlacknWhiteMode((Boolean) newValue);
			return;
		case UIAdaptationPackage.COLOR_SCHEME__NIGHT_MODE:
			setNightMode((Boolean) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.COLOR_SCHEME__BLACKN_WHITE_MODE:
			setBlacknWhiteMode(BLACKN_WHITE_MODE_EDEFAULT);
			return;
		case UIAdaptationPackage.COLOR_SCHEME__NIGHT_MODE:
			setNightMode(NIGHT_MODE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.COLOR_SCHEME__BLACKN_WHITE_MODE:
			return blacknWhiteMode != BLACKN_WHITE_MODE_EDEFAULT;
		case UIAdaptationPackage.COLOR_SCHEME__NIGHT_MODE:
			return nightMode != NIGHT_MODE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (BlacknWhiteMode: ");
		result.append(blacknWhiteMode);
		result.append(", NightMode: ");
		result.append(nightMode);
		result.append(')');
		return result.toString();
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //ColorSchemeImpl
