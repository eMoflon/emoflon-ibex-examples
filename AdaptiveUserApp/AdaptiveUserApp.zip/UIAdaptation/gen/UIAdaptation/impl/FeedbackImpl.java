/**
 */
package UIAdaptation.impl;

import UIAdaptation.Feedback;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Feedback</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class FeedbackImpl extends ViewImpl implements Feedback {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FeedbackImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.FEEDBACK;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //FeedbackImpl
