/**
 */
package UIAdaptation.impl;

import UIAdaptation.NightModeScheme;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Night Mode Scheme</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class NightModeSchemeImpl extends ColorSchemeImpl implements NightModeScheme {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NightModeSchemeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.NIGHT_MODE_SCHEME;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //NightModeSchemeImpl
