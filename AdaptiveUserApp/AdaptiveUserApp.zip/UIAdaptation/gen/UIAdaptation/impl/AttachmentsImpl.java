/**
 */
package UIAdaptation.impl;

import UIAdaptation.Attachments;
import UIAdaptation.AutoDownload;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Attachments</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UIAdaptation.impl.AttachmentsImpl#getAutoDownload <em>Auto Download</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AttachmentsImpl extends EObjectImpl implements Attachments {
	/**
	 * The cached value of the '{@link #getAutoDownload() <em>Auto Download</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAutoDownload()
	 * @generated
	 * @ordered
	 */
	protected AutoDownload autoDownload;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AttachmentsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.ATTACHMENTS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AutoDownload getAutoDownload() {
		if (autoDownload != null && autoDownload.eIsProxy()) {
			InternalEObject oldAutoDownload = (InternalEObject) autoDownload;
			autoDownload = (AutoDownload) eResolveProxy(oldAutoDownload);
			if (autoDownload != oldAutoDownload) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							UIAdaptationPackage.ATTACHMENTS__AUTO_DOWNLOAD, oldAutoDownload, autoDownload));
			}
		}
		return autoDownload;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AutoDownload basicGetAutoDownload() {
		return autoDownload;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAutoDownload(AutoDownload newAutoDownload) {
		AutoDownload oldAutoDownload = autoDownload;
		autoDownload = newAutoDownload;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.ATTACHMENTS__AUTO_DOWNLOAD,
					oldAutoDownload, autoDownload));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UIAdaptationPackage.ATTACHMENTS__AUTO_DOWNLOAD:
			if (resolve)
				return getAutoDownload();
			return basicGetAutoDownload();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UIAdaptationPackage.ATTACHMENTS__AUTO_DOWNLOAD:
			setAutoDownload((AutoDownload) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.ATTACHMENTS__AUTO_DOWNLOAD:
			setAutoDownload((AutoDownload) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.ATTACHMENTS__AUTO_DOWNLOAD:
			return autoDownload != null;
		}
		return super.eIsSet(featureID);
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //AttachmentsImpl
