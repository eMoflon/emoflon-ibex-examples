/**
 */
package UIAdaptation.impl;

import UIAdaptation.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class UIAdaptationFactoryImpl extends EFactoryImpl implements UIAdaptationFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static UIAdaptationFactory init() {
		try {
			UIAdaptationFactory theUIAdaptationFactory = (UIAdaptationFactory) EPackage.Registry.INSTANCE
					.getEFactory(UIAdaptationPackage.eNS_URI);
			if (theUIAdaptationFactory != null) {
				return theUIAdaptationFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new UIAdaptationFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UIAdaptationFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case UIAdaptationPackage.APP:
			return createApp();
		case UIAdaptationPackage.NAVIGATION:
			return createNavigation();
		case UIAdaptationPackage.GRID_NAV:
			return createGridNav();
		case UIAdaptationPackage.DEFAULT_NAV:
			return createDefaultNav();
		case UIAdaptationPackage.TABLET_NAV:
			return createTabletNav();
		case UIAdaptationPackage.MINIMUM_NAVIGATION:
			return createMinimumNavigation();
		case UIAdaptationPackage.LESS_INFORMED_NAV:
			return createLessInformedNav();
		case UIAdaptationPackage.MORE_INFORMED_NAV:
			return createMoreInformedNav();
		case UIAdaptationPackage.FEEDBACK_BAR:
			return createFeedbackBar();
		case UIAdaptationPackage.CLICK_EVENT:
			return createClickEvent();
		case UIAdaptationPackage.FEEDBACK:
			return createFeedback();
		case UIAdaptationPackage.INSPIRATION:
			return createInspiration();
		case UIAdaptationPackage.LAYOUT:
			return createLayout();
		case UIAdaptationPackage.DEFAULT_SIZE:
			return createDefaultSize();
		case UIAdaptationPackage.LARGE_SIZE:
			return createLargeSize();
		case UIAdaptationPackage.MIDDLE_SIZE:
			return createMiddleSize();
		case UIAdaptationPackage.CUSTOM_COLOR:
			return createCustomColor();
		case UIAdaptationPackage.BLACKN_WHITE:
			return createBlacknWhite();
		case UIAdaptationPackage.MONO_CHROMATIC:
			return createMonoChromatic();
		case UIAdaptationPackage.NIGHT_MODE_SCHEME:
			return createNightModeScheme();
		case UIAdaptationPackage.TASK_FEATURE:
			return createTaskFeature();
		case UIAdaptationPackage.ATTACHMENTS:
			return createAttachments();
		case UIAdaptationPackage.AUTO_DOWNLOAD:
			return createAutoDownload();
		case UIAdaptationPackage.READ_EMAIL:
			return createReadEmail();
		case UIAdaptationPackage.SHOW_EMAIL:
			return createShowEmail();
		case UIAdaptationPackage.EMAIL_FORM:
			return createEmailForm();
		case UIAdaptationPackage.HTML:
			return createHTML();
		case UIAdaptationPackage.TEXT_FORM:
			return createTextForm();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case UIAdaptationPackage.MENU_ENUM:
			return createMenuEnumFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case UIAdaptationPackage.MENU_ENUM:
			return convertMenuEnumToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public App createApp() {
		AppImpl app = new AppImpl();
		return app;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Navigation createNavigation() {
		NavigationImpl navigation = new NavigationImpl();
		return navigation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public GridNav createGridNav() {
		GridNavImpl gridNav = new GridNavImpl();
		return gridNav;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DefaultNav createDefaultNav() {
		DefaultNavImpl defaultNav = new DefaultNavImpl();
		return defaultNav;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TabletNav createTabletNav() {
		TabletNavImpl tabletNav = new TabletNavImpl();
		return tabletNav;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MinimumNavigation createMinimumNavigation() {
		MinimumNavigationImpl minimumNavigation = new MinimumNavigationImpl();
		return minimumNavigation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LessInformedNav createLessInformedNav() {
		LessInformedNavImpl lessInformedNav = new LessInformedNavImpl();
		return lessInformedNav;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MoreInformedNav createMoreInformedNav() {
		MoreInformedNavImpl moreInformedNav = new MoreInformedNavImpl();
		return moreInformedNav;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FeedbackBar createFeedbackBar() {
		FeedbackBarImpl feedbackBar = new FeedbackBarImpl();
		return feedbackBar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ClickEvent createClickEvent() {
		ClickEventImpl clickEvent = new ClickEventImpl();
		return clickEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Feedback createFeedback() {
		FeedbackImpl feedback = new FeedbackImpl();
		return feedback;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Inspiration createInspiration() {
		InspirationImpl inspiration = new InspirationImpl();
		return inspiration;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Layout createLayout() {
		LayoutImpl layout = new LayoutImpl();
		return layout;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DefaultSize createDefaultSize() {
		DefaultSizeImpl defaultSize = new DefaultSizeImpl();
		return defaultSize;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LargeSize createLargeSize() {
		LargeSizeImpl largeSize = new LargeSizeImpl();
		return largeSize;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MiddleSize createMiddleSize() {
		MiddleSizeImpl middleSize = new MiddleSizeImpl();
		return middleSize;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CustomColor createCustomColor() {
		CustomColorImpl customColor = new CustomColorImpl();
		return customColor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BlacknWhite createBlacknWhite() {
		BlacknWhiteImpl blacknWhite = new BlacknWhiteImpl();
		return blacknWhite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MonoChromatic createMonoChromatic() {
		MonoChromaticImpl monoChromatic = new MonoChromaticImpl();
		return monoChromatic;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NightModeScheme createNightModeScheme() {
		NightModeSchemeImpl nightModeScheme = new NightModeSchemeImpl();
		return nightModeScheme;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TaskFeature createTaskFeature() {
		TaskFeatureImpl taskFeature = new TaskFeatureImpl();
		return taskFeature;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Attachments createAttachments() {
		AttachmentsImpl attachments = new AttachmentsImpl();
		return attachments;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AutoDownload createAutoDownload() {
		AutoDownloadImpl autoDownload = new AutoDownloadImpl();
		return autoDownload;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ReadEmail createReadEmail() {
		ReadEmailImpl readEmail = new ReadEmailImpl();
		return readEmail;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ShowEmail createShowEmail() {
		ShowEmailImpl showEmail = new ShowEmailImpl();
		return showEmail;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EmailForm createEmailForm() {
		EmailFormImpl emailForm = new EmailFormImpl();
		return emailForm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public HTML createHTML() {
		HTMLImpl html = new HTMLImpl();
		return html;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TextForm createTextForm() {
		TextFormImpl textForm = new TextFormImpl();
		return textForm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MenuEnum createMenuEnumFromString(EDataType eDataType, String initialValue) {
		MenuEnum result = MenuEnum.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertMenuEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public UIAdaptationPackage getUIAdaptationPackage() {
		return (UIAdaptationPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static UIAdaptationPackage getPackage() {
		return UIAdaptationPackage.eINSTANCE;
	}

} //UIAdaptationFactoryImpl
