/**
 */
package UIAdaptation.impl;

import UIAdaptation.DefaultNav;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Default Nav</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class DefaultNavImpl extends NaviTypeImpl implements DefaultNav {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DefaultNavImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.DEFAULT_NAV;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //DefaultNavImpl
