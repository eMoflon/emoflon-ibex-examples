/**
 */
package UIAdaptation.impl;

import UIAdaptation.MoreInformedNav;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>More Informed Nav</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class MoreInformedNavImpl extends NavigationImpl implements MoreInformedNav {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MoreInformedNavImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.MORE_INFORMED_NAV;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //MoreInformedNavImpl
