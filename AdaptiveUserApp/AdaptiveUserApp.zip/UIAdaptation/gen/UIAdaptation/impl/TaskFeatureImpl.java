/**
 */
package UIAdaptation.impl;

import UIAdaptation.Menu;
import UIAdaptation.ReadEmail;
import UIAdaptation.ShowEmail;
import UIAdaptation.TaskFeature;
import UIAdaptation.UIAdaptationPackage;
import UIAdaptation.WriteEmail;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Task Feature</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UIAdaptation.impl.TaskFeatureImpl#getReadEmail <em>Read Email</em>}</li>
 *   <li>{@link UIAdaptation.impl.TaskFeatureImpl#getShowEmail <em>Show Email</em>}</li>
 *   <li>{@link UIAdaptation.impl.TaskFeatureImpl#getWriteEmail <em>Write Email</em>}</li>
 *   <li>{@link UIAdaptation.impl.TaskFeatureImpl#getMenu <em>Menu</em>}</li>
 *   <li>{@link UIAdaptation.impl.TaskFeatureImpl#isVocalUI <em>Vocal UI</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TaskFeatureImpl extends EObjectImpl implements TaskFeature {
	/**
	 * The cached value of the '{@link #getReadEmail() <em>Read Email</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReadEmail()
	 * @generated
	 * @ordered
	 */
	protected ReadEmail readEmail;

	/**
	 * The cached value of the '{@link #getShowEmail() <em>Show Email</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getShowEmail()
	 * @generated
	 * @ordered
	 */
	protected ShowEmail showEmail;

	/**
	 * The cached value of the '{@link #getWriteEmail() <em>Write Email</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWriteEmail()
	 * @generated
	 * @ordered
	 */
	protected WriteEmail writeEmail;

	/**
	 * The cached value of the '{@link #getMenu() <em>Menu</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMenu()
	 * @generated
	 * @ordered
	 */
	protected Menu menu;

	/**
	 * The default value of the '{@link #isVocalUI() <em>Vocal UI</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isVocalUI()
	 * @generated
	 * @ordered
	 */
	protected static final boolean VOCAL_UI_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isVocalUI() <em>Vocal UI</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isVocalUI()
	 * @generated
	 * @ordered
	 */
	protected boolean vocalUI = VOCAL_UI_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TaskFeatureImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.TASK_FEATURE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ReadEmail getReadEmail() {
		return readEmail;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetReadEmail(ReadEmail newReadEmail, NotificationChain msgs) {
		ReadEmail oldReadEmail = readEmail;
		readEmail = newReadEmail;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UIAdaptationPackage.TASK_FEATURE__READ_EMAIL, oldReadEmail, newReadEmail);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReadEmail(ReadEmail newReadEmail) {
		if (newReadEmail != readEmail) {
			NotificationChain msgs = null;
			if (readEmail != null)
				msgs = ((InternalEObject) readEmail).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.TASK_FEATURE__READ_EMAIL, null, msgs);
			if (newReadEmail != null)
				msgs = ((InternalEObject) newReadEmail).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.TASK_FEATURE__READ_EMAIL, null, msgs);
			msgs = basicSetReadEmail(newReadEmail, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.TASK_FEATURE__READ_EMAIL,
					newReadEmail, newReadEmail));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ShowEmail getShowEmail() {
		return showEmail;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetShowEmail(ShowEmail newShowEmail, NotificationChain msgs) {
		ShowEmail oldShowEmail = showEmail;
		showEmail = newShowEmail;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UIAdaptationPackage.TASK_FEATURE__SHOW_EMAIL, oldShowEmail, newShowEmail);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setShowEmail(ShowEmail newShowEmail) {
		if (newShowEmail != showEmail) {
			NotificationChain msgs = null;
			if (showEmail != null)
				msgs = ((InternalEObject) showEmail).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.TASK_FEATURE__SHOW_EMAIL, null, msgs);
			if (newShowEmail != null)
				msgs = ((InternalEObject) newShowEmail).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.TASK_FEATURE__SHOW_EMAIL, null, msgs);
			msgs = basicSetShowEmail(newShowEmail, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.TASK_FEATURE__SHOW_EMAIL,
					newShowEmail, newShowEmail));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WriteEmail getWriteEmail() {
		return writeEmail;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetWriteEmail(WriteEmail newWriteEmail, NotificationChain msgs) {
		WriteEmail oldWriteEmail = writeEmail;
		writeEmail = newWriteEmail;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UIAdaptationPackage.TASK_FEATURE__WRITE_EMAIL, oldWriteEmail, newWriteEmail);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWriteEmail(WriteEmail newWriteEmail) {
		if (newWriteEmail != writeEmail) {
			NotificationChain msgs = null;
			if (writeEmail != null)
				msgs = ((InternalEObject) writeEmail).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.TASK_FEATURE__WRITE_EMAIL, null, msgs);
			if (newWriteEmail != null)
				msgs = ((InternalEObject) newWriteEmail).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.TASK_FEATURE__WRITE_EMAIL, null, msgs);
			msgs = basicSetWriteEmail(newWriteEmail, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.TASK_FEATURE__WRITE_EMAIL,
					newWriteEmail, newWriteEmail));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Menu getMenu() {
		return menu;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetMenu(Menu newMenu, NotificationChain msgs) {
		Menu oldMenu = menu;
		menu = newMenu;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UIAdaptationPackage.TASK_FEATURE__MENU, oldMenu, newMenu);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMenu(Menu newMenu) {
		if (newMenu != menu) {
			NotificationChain msgs = null;
			if (menu != null)
				msgs = ((InternalEObject) menu).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.TASK_FEATURE__MENU, null, msgs);
			if (newMenu != null)
				msgs = ((InternalEObject) newMenu).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.TASK_FEATURE__MENU, null, msgs);
			msgs = basicSetMenu(newMenu, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.TASK_FEATURE__MENU, newMenu,
					newMenu));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isVocalUI() {
		return vocalUI;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVocalUI(boolean newVocalUI) {
		boolean oldVocalUI = vocalUI;
		vocalUI = newVocalUI;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.TASK_FEATURE__VOCAL_UI,
					oldVocalUI, vocalUI));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UIAdaptationPackage.TASK_FEATURE__READ_EMAIL:
			return basicSetReadEmail(null, msgs);
		case UIAdaptationPackage.TASK_FEATURE__SHOW_EMAIL:
			return basicSetShowEmail(null, msgs);
		case UIAdaptationPackage.TASK_FEATURE__WRITE_EMAIL:
			return basicSetWriteEmail(null, msgs);
		case UIAdaptationPackage.TASK_FEATURE__MENU:
			return basicSetMenu(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UIAdaptationPackage.TASK_FEATURE__READ_EMAIL:
			return getReadEmail();
		case UIAdaptationPackage.TASK_FEATURE__SHOW_EMAIL:
			return getShowEmail();
		case UIAdaptationPackage.TASK_FEATURE__WRITE_EMAIL:
			return getWriteEmail();
		case UIAdaptationPackage.TASK_FEATURE__MENU:
			return getMenu();
		case UIAdaptationPackage.TASK_FEATURE__VOCAL_UI:
			return isVocalUI();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UIAdaptationPackage.TASK_FEATURE__READ_EMAIL:
			setReadEmail((ReadEmail) newValue);
			return;
		case UIAdaptationPackage.TASK_FEATURE__SHOW_EMAIL:
			setShowEmail((ShowEmail) newValue);
			return;
		case UIAdaptationPackage.TASK_FEATURE__WRITE_EMAIL:
			setWriteEmail((WriteEmail) newValue);
			return;
		case UIAdaptationPackage.TASK_FEATURE__MENU:
			setMenu((Menu) newValue);
			return;
		case UIAdaptationPackage.TASK_FEATURE__VOCAL_UI:
			setVocalUI((Boolean) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.TASK_FEATURE__READ_EMAIL:
			setReadEmail((ReadEmail) null);
			return;
		case UIAdaptationPackage.TASK_FEATURE__SHOW_EMAIL:
			setShowEmail((ShowEmail) null);
			return;
		case UIAdaptationPackage.TASK_FEATURE__WRITE_EMAIL:
			setWriteEmail((WriteEmail) null);
			return;
		case UIAdaptationPackage.TASK_FEATURE__MENU:
			setMenu((Menu) null);
			return;
		case UIAdaptationPackage.TASK_FEATURE__VOCAL_UI:
			setVocalUI(VOCAL_UI_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.TASK_FEATURE__READ_EMAIL:
			return readEmail != null;
		case UIAdaptationPackage.TASK_FEATURE__SHOW_EMAIL:
			return showEmail != null;
		case UIAdaptationPackage.TASK_FEATURE__WRITE_EMAIL:
			return writeEmail != null;
		case UIAdaptationPackage.TASK_FEATURE__MENU:
			return menu != null;
		case UIAdaptationPackage.TASK_FEATURE__VOCAL_UI:
			return vocalUI != VOCAL_UI_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (VocalUI: ");
		result.append(vocalUI);
		result.append(')');
		return result.toString();
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //TaskFeatureImpl
