/**
 */
package UIAdaptation.impl;

import UIAdaptation.LessInformedNav;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Less Informed Nav</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class LessInformedNavImpl extends NavigationImpl implements LessInformedNav {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LessInformedNavImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.LESS_INFORMED_NAV;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //LessInformedNavImpl
