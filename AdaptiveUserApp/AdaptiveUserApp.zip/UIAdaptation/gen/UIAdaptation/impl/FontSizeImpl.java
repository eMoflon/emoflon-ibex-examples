/**
 */
package UIAdaptation.impl;

import UIAdaptation.FontSize;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Font Size</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public abstract class FontSizeImpl extends EObjectImpl implements FontSize {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FontSizeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.FONT_SIZE;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //FontSizeImpl
