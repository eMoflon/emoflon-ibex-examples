/**
 */
package UIAdaptation.impl;

import UIAdaptation.App;
import UIAdaptation.Attachments;
import UIAdaptation.AutoDownload;
import UIAdaptation.BlacknWhite;
import UIAdaptation.ClickEvent;
import UIAdaptation.ColorScheme;
import UIAdaptation.CustomColor;
import UIAdaptation.DefaultNav;
import UIAdaptation.DefaultSize;
import UIAdaptation.EmailForm;
import UIAdaptation.Feedback;
import UIAdaptation.FeedbackBar;
import UIAdaptation.FontSize;
import UIAdaptation.GridNav;
import UIAdaptation.Inspiration;
import UIAdaptation.LargeSize;
import UIAdaptation.Layout;
import UIAdaptation.LessInformedNav;
import UIAdaptation.Menu;
import UIAdaptation.MenuEnum;
import UIAdaptation.MiddleSize;
import UIAdaptation.MinimumNavigation;
import UIAdaptation.MonoChromatic;
import UIAdaptation.MoreInformedNav;
import UIAdaptation.NaviType;
import UIAdaptation.Navigation;
import UIAdaptation.NightModeScheme;
import UIAdaptation.ReadEmail;
import UIAdaptation.ShowEmail;
import UIAdaptation.TabletNav;
import UIAdaptation.TaskFeature;
import UIAdaptation.TextForm;
import UIAdaptation.UIAdaptationFactory;
import UIAdaptation.UIAdaptationPackage;
import UIAdaptation.View;
import UIAdaptation.WriteEmail;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class UIAdaptationPackageImpl extends EPackageImpl implements UIAdaptationPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass appEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass navigationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass naviTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass gridNavEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass defaultNavEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tabletNavEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass minimumNavigationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass lessInformedNavEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass moreInformedNavEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass feedbackBarEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass clickEventEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass viewEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass feedbackEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass inspirationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass layoutEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fontSizeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass defaultSizeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass largeSizeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass middleSizeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass colorSchemeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass customColorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass blacknWhiteEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass monoChromaticEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass nightModeSchemeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass taskFeatureEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass menuEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attachmentsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass autoDownloadEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass readEmailEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass showEmailEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass writeEmailEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass emailFormEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass htmlEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass textFormEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum menuEnumEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see UIAdaptation.UIAdaptationPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private UIAdaptationPackageImpl() {
		super(eNS_URI, UIAdaptationFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link UIAdaptationPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static UIAdaptationPackage init() {
		if (isInited)
			return (UIAdaptationPackage) EPackage.Registry.INSTANCE.getEPackage(UIAdaptationPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredUIAdaptationPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		UIAdaptationPackageImpl theUIAdaptationPackage = registeredUIAdaptationPackage instanceof UIAdaptationPackageImpl
				? (UIAdaptationPackageImpl) registeredUIAdaptationPackage
				: new UIAdaptationPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theUIAdaptationPackage.createPackageContents();

		// Initialize created meta-data
		theUIAdaptationPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theUIAdaptationPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(UIAdaptationPackage.eNS_URI, theUIAdaptationPackage);
		return theUIAdaptationPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getApp() {
		return appEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getApp_Navigation() {
		return (EReference) appEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getApp_Layout() {
		return (EReference) appEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getApp_Taskset() {
		return (EReference) appEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getNavigation() {
		return navigationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getNavigation_Button() {
		return (EReference) navigationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getNavigation_Menu() {
		return (EReference) navigationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getNavigation_DrivingMode() {
		return (EAttribute) navigationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getNaviType() {
		return naviTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getGridNav() {
		return gridNavEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getGridNav_Activate() {
		return (EAttribute) gridNavEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDefaultNav() {
		return defaultNavEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTabletNav() {
		return tabletNavEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTabletNav_Activate() {
		return (EAttribute) tabletNavEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMinimumNavigation() {
		return minimumNavigationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLessInformedNav() {
		return lessInformedNavEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMoreInformedNav() {
		return moreInformedNavEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFeedbackBar() {
		return feedbackBarEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getFeedbackBar_Clickevent() {
		return (EReference) feedbackBarEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getClickEvent() {
		return clickEventEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getClickEvent_View() {
		return (EReference) clickEventEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getView() {
		return viewEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFeedback() {
		return feedbackEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInspiration() {
		return inspirationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLayout() {
		return layoutEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getLayout_ColorScheme() {
		return (EReference) layoutEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getLayout_FontSize() {
		return (EReference) layoutEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFontSize() {
		return fontSizeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDefaultSize() {
		return defaultSizeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLargeSize() {
		return largeSizeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMiddleSize() {
		return middleSizeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getColorScheme() {
		return colorSchemeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getColorScheme_BlacknWhiteMode() {
		return (EAttribute) colorSchemeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getColorScheme_NightMode() {
		return (EAttribute) colorSchemeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCustomColor() {
		return customColorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getBlacknWhite() {
		return blacknWhiteEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMonoChromatic() {
		return monoChromaticEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getNightModeScheme() {
		return nightModeSchemeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTaskFeature() {
		return taskFeatureEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getTaskFeature_ReadEmail() {
		return (EReference) taskFeatureEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getTaskFeature_ShowEmail() {
		return (EReference) taskFeatureEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getTaskFeature_WriteEmail() {
		return (EReference) taskFeatureEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getTaskFeature_Menu() {
		return (EReference) taskFeatureEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTaskFeature_VocalUI() {
		return (EAttribute) taskFeatureEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMenu() {
		return menuEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getMenu_MenuEnum() {
		return (EAttribute) menuEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAttachments() {
		return attachmentsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachments_AutoDownload() {
		return (EReference) attachmentsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAutoDownload() {
		return autoDownloadEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getAutoDownload_Enable() {
		return (EAttribute) autoDownloadEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getReadEmail() {
		return readEmailEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getReadEmail_Attachments() {
		return (EReference) readEmailEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getShowEmail() {
		return showEmailEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getShowEmail_EmailForm() {
		return (EReference) showEmailEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getWriteEmail() {
		return writeEmailEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getEmailForm() {
		return emailFormEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getEmailForm_Html() {
		return (EReference) emailFormEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getEmailForm_TextForm() {
		return (EReference) emailFormEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getHTML() {
		return htmlEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTextForm() {
		return textFormEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getMenuEnum() {
		return menuEnumEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public UIAdaptationFactory getUIAdaptationFactory() {
		return (UIAdaptationFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		appEClass = createEClass(APP);
		createEReference(appEClass, APP__NAVIGATION);
		createEReference(appEClass, APP__LAYOUT);
		createEReference(appEClass, APP__TASKSET);

		navigationEClass = createEClass(NAVIGATION);
		createEReference(navigationEClass, NAVIGATION__BUTTON);
		createEReference(navigationEClass, NAVIGATION__MENU);
		createEAttribute(navigationEClass, NAVIGATION__DRIVING_MODE);

		naviTypeEClass = createEClass(NAVI_TYPE);

		gridNavEClass = createEClass(GRID_NAV);
		createEAttribute(gridNavEClass, GRID_NAV__ACTIVATE);

		defaultNavEClass = createEClass(DEFAULT_NAV);

		tabletNavEClass = createEClass(TABLET_NAV);
		createEAttribute(tabletNavEClass, TABLET_NAV__ACTIVATE);

		minimumNavigationEClass = createEClass(MINIMUM_NAVIGATION);

		lessInformedNavEClass = createEClass(LESS_INFORMED_NAV);

		moreInformedNavEClass = createEClass(MORE_INFORMED_NAV);

		feedbackBarEClass = createEClass(FEEDBACK_BAR);
		createEReference(feedbackBarEClass, FEEDBACK_BAR__CLICKEVENT);

		clickEventEClass = createEClass(CLICK_EVENT);
		createEReference(clickEventEClass, CLICK_EVENT__VIEW);

		viewEClass = createEClass(VIEW);

		feedbackEClass = createEClass(FEEDBACK);

		inspirationEClass = createEClass(INSPIRATION);

		layoutEClass = createEClass(LAYOUT);
		createEReference(layoutEClass, LAYOUT__COLOR_SCHEME);
		createEReference(layoutEClass, LAYOUT__FONT_SIZE);

		fontSizeEClass = createEClass(FONT_SIZE);

		defaultSizeEClass = createEClass(DEFAULT_SIZE);

		largeSizeEClass = createEClass(LARGE_SIZE);

		middleSizeEClass = createEClass(MIDDLE_SIZE);

		colorSchemeEClass = createEClass(COLOR_SCHEME);
		createEAttribute(colorSchemeEClass, COLOR_SCHEME__BLACKN_WHITE_MODE);
		createEAttribute(colorSchemeEClass, COLOR_SCHEME__NIGHT_MODE);

		customColorEClass = createEClass(CUSTOM_COLOR);

		blacknWhiteEClass = createEClass(BLACKN_WHITE);

		monoChromaticEClass = createEClass(MONO_CHROMATIC);

		nightModeSchemeEClass = createEClass(NIGHT_MODE_SCHEME);

		taskFeatureEClass = createEClass(TASK_FEATURE);
		createEReference(taskFeatureEClass, TASK_FEATURE__READ_EMAIL);
		createEReference(taskFeatureEClass, TASK_FEATURE__SHOW_EMAIL);
		createEReference(taskFeatureEClass, TASK_FEATURE__WRITE_EMAIL);
		createEReference(taskFeatureEClass, TASK_FEATURE__MENU);
		createEAttribute(taskFeatureEClass, TASK_FEATURE__VOCAL_UI);

		menuEClass = createEClass(MENU);
		createEAttribute(menuEClass, MENU__MENU_ENUM);

		attachmentsEClass = createEClass(ATTACHMENTS);
		createEReference(attachmentsEClass, ATTACHMENTS__AUTO_DOWNLOAD);

		autoDownloadEClass = createEClass(AUTO_DOWNLOAD);
		createEAttribute(autoDownloadEClass, AUTO_DOWNLOAD__ENABLE);

		readEmailEClass = createEClass(READ_EMAIL);
		createEReference(readEmailEClass, READ_EMAIL__ATTACHMENTS);

		showEmailEClass = createEClass(SHOW_EMAIL);
		createEReference(showEmailEClass, SHOW_EMAIL__EMAIL_FORM);

		writeEmailEClass = createEClass(WRITE_EMAIL);

		emailFormEClass = createEClass(EMAIL_FORM);
		createEReference(emailFormEClass, EMAIL_FORM__HTML);
		createEReference(emailFormEClass, EMAIL_FORM__TEXT_FORM);

		htmlEClass = createEClass(HTML);

		textFormEClass = createEClass(TEXT_FORM);

		// Create enums
		menuEnumEEnum = createEEnum(MENU_ENUM);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		gridNavEClass.getESuperTypes().add(this.getNaviType());
		defaultNavEClass.getESuperTypes().add(this.getNaviType());
		tabletNavEClass.getESuperTypes().add(this.getNaviType());
		minimumNavigationEClass.getESuperTypes().add(this.getNavigation());
		lessInformedNavEClass.getESuperTypes().add(this.getNavigation());
		moreInformedNavEClass.getESuperTypes().add(this.getNavigation());
		feedbackEClass.getESuperTypes().add(this.getView());
		inspirationEClass.getESuperTypes().add(this.getView());
		defaultSizeEClass.getESuperTypes().add(this.getFontSize());
		largeSizeEClass.getESuperTypes().add(this.getFontSize());
		middleSizeEClass.getESuperTypes().add(this.getFontSize());
		customColorEClass.getESuperTypes().add(this.getColorScheme());
		blacknWhiteEClass.getESuperTypes().add(this.getColorScheme());
		monoChromaticEClass.getESuperTypes().add(this.getColorScheme());
		nightModeSchemeEClass.getESuperTypes().add(this.getColorScheme());

		// Initialize classes, features, and operations; add parameters
		initEClass(appEClass, App.class, "App", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getApp_Navigation(), this.getNavigation(), null, "navigation", null, 1, 1, App.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getApp_Layout(), this.getLayout(), null, "layout", null, 1, 1, App.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getApp_Taskset(), this.getTaskFeature(), null, "taskset", null, 1, 1, App.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(navigationEClass, Navigation.class, "Navigation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getNavigation_Button(), this.getFeedbackBar(), null, "button", null, 0, 1, Navigation.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getNavigation_Menu(), this.getNaviType(), null, "menu", null, 1, 1, Navigation.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getNavigation_DrivingMode(), ecorePackage.getEBoolean(), "DrivingMode", null, 0, 1,
				Navigation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(naviTypeEClass, NaviType.class, "NaviType", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(gridNavEClass, GridNav.class, "GridNav", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getGridNav_Activate(), ecorePackage.getEBoolean(), "activate", null, 0, 1, GridNav.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(defaultNavEClass, DefaultNav.class, "DefaultNav", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(tabletNavEClass, TabletNav.class, "TabletNav", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTabletNav_Activate(), ecorePackage.getEBoolean(), "activate", null, 0, 1, TabletNav.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(minimumNavigationEClass, MinimumNavigation.class, "MinimumNavigation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(lessInformedNavEClass, LessInformedNav.class, "LessInformedNav", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(moreInformedNavEClass, MoreInformedNav.class, "MoreInformedNav", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(feedbackBarEClass, FeedbackBar.class, "FeedbackBar", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFeedbackBar_Clickevent(), this.getClickEvent(), null, "clickevent", null, 0, 1,
				FeedbackBar.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(clickEventEClass, ClickEvent.class, "ClickEvent", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getClickEvent_View(), this.getView(), null, "view", null, 0, -1, ClickEvent.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(viewEClass, View.class, "View", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(feedbackEClass, Feedback.class, "Feedback", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(inspirationEClass, Inspiration.class, "Inspiration", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(layoutEClass, Layout.class, "Layout", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getLayout_ColorScheme(), this.getColorScheme(), null, "colorScheme", null, 1, 1, Layout.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getLayout_FontSize(), this.getFontSize(), null, "fontSize", null, 1, 1, Layout.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(fontSizeEClass, FontSize.class, "FontSize", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(defaultSizeEClass, DefaultSize.class, "DefaultSize", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(largeSizeEClass, LargeSize.class, "LargeSize", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(middleSizeEClass, MiddleSize.class, "MiddleSize", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(colorSchemeEClass, ColorScheme.class, "ColorScheme", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getColorScheme_BlacknWhiteMode(), ecorePackage.getEBoolean(), "BlacknWhiteMode", null, 0, 1,
				ColorScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getColorScheme_NightMode(), ecorePackage.getEBoolean(), "NightMode", null, 0, 1,
				ColorScheme.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(customColorEClass, CustomColor.class, "CustomColor", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(blacknWhiteEClass, BlacknWhite.class, "BlacknWhite", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(monoChromaticEClass, MonoChromatic.class, "MonoChromatic", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(nightModeSchemeEClass, NightModeScheme.class, "NightModeScheme", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(taskFeatureEClass, TaskFeature.class, "TaskFeature", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTaskFeature_ReadEmail(), this.getReadEmail(), null, "readEmail", null, 0, 1,
				TaskFeature.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTaskFeature_ShowEmail(), this.getShowEmail(), null, "showEmail", null, 1, 1,
				TaskFeature.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTaskFeature_WriteEmail(), this.getWriteEmail(), null, "writeEmail", null, 0, 1,
				TaskFeature.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTaskFeature_Menu(), this.getMenu(), null, "menu", null, 1, 1, TaskFeature.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTaskFeature_VocalUI(), ecorePackage.getEBoolean(), "VocalUI", null, 0, 1, TaskFeature.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(menuEClass, Menu.class, "Menu", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMenu_MenuEnum(), this.getMenuEnum(), "menuEnum", null, 0, 1, Menu.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(attachmentsEClass, Attachments.class, "Attachments", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAttachments_AutoDownload(), this.getAutoDownload(), null, "autoDownload", null, 0, 1,
				Attachments.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(autoDownloadEClass, AutoDownload.class, "AutoDownload", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAutoDownload_Enable(), ecorePackage.getEBoolean(), "enable", null, 0, 1, AutoDownload.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(readEmailEClass, ReadEmail.class, "ReadEmail", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getReadEmail_Attachments(), this.getAttachments(), null, "attachments", null, 0, 1,
				ReadEmail.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(showEmailEClass, ShowEmail.class, "ShowEmail", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getShowEmail_EmailForm(), this.getEmailForm(), null, "emailForm", null, 0, 1, ShowEmail.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(writeEmailEClass, WriteEmail.class, "WriteEmail", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(emailFormEClass, EmailForm.class, "EmailForm", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getEmailForm_Html(), this.getHTML(), null, "html", null, 0, 1, EmailForm.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getEmailForm_TextForm(), this.getTextForm(), null, "textForm", null, 0, 1, EmailForm.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(htmlEClass, UIAdaptation.HTML.class, "HTML", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(textFormEClass, TextForm.class, "TextForm", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		// Initialize enums and add enum literals
		initEEnum(menuEnumEEnum, MenuEnum.class, "MenuEnum");
		addEEnumLiteral(menuEnumEEnum, MenuEnum.INBOX);
		addEEnumLiteral(menuEnumEEnum, MenuEnum.DRAFTS);
		addEEnumLiteral(menuEnumEEnum, MenuEnum.SENT);
		addEEnumLiteral(menuEnumEEnum, MenuEnum.SPAM);
		addEEnumLiteral(menuEnumEEnum, MenuEnum.TRASH);
		addEEnumLiteral(menuEnumEEnum, MenuEnum.SETTING);
		addEEnumLiteral(menuEnumEEnum, MenuEnum.LOGOUT);

		// Create resource
		createResource(eNS_URI);
	}

} //UIAdaptationPackageImpl
