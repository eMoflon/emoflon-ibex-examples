/**
 */
package UIAdaptation.impl;

import UIAdaptation.ClickEvent;
import UIAdaptation.FeedbackBar;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Feedback Bar</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UIAdaptation.impl.FeedbackBarImpl#getClickevent <em>Clickevent</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FeedbackBarImpl extends EObjectImpl implements FeedbackBar {
	/**
	 * The cached value of the '{@link #getClickevent() <em>Clickevent</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClickevent()
	 * @generated
	 * @ordered
	 */
	protected ClickEvent clickevent;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FeedbackBarImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.FEEDBACK_BAR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClickEvent getClickevent() {
		if (clickevent != null && clickevent.eIsProxy()) {
			InternalEObject oldClickevent = (InternalEObject) clickevent;
			clickevent = (ClickEvent) eResolveProxy(oldClickevent);
			if (clickevent != oldClickevent) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							UIAdaptationPackage.FEEDBACK_BAR__CLICKEVENT, oldClickevent, clickevent));
			}
		}
		return clickevent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClickEvent basicGetClickevent() {
		return clickevent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setClickevent(ClickEvent newClickevent) {
		ClickEvent oldClickevent = clickevent;
		clickevent = newClickevent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.FEEDBACK_BAR__CLICKEVENT,
					oldClickevent, clickevent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UIAdaptationPackage.FEEDBACK_BAR__CLICKEVENT:
			if (resolve)
				return getClickevent();
			return basicGetClickevent();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UIAdaptationPackage.FEEDBACK_BAR__CLICKEVENT:
			setClickevent((ClickEvent) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.FEEDBACK_BAR__CLICKEVENT:
			setClickevent((ClickEvent) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.FEEDBACK_BAR__CLICKEVENT:
			return clickevent != null;
		}
		return super.eIsSet(featureID);
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //FeedbackBarImpl
