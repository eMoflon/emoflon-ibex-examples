/**
 */
package UIAdaptation.impl;

import UIAdaptation.App;
import UIAdaptation.Layout;
import UIAdaptation.Navigation;
import UIAdaptation.TaskFeature;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>App</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UIAdaptation.impl.AppImpl#getNavigation <em>Navigation</em>}</li>
 *   <li>{@link UIAdaptation.impl.AppImpl#getLayout <em>Layout</em>}</li>
 *   <li>{@link UIAdaptation.impl.AppImpl#getTaskset <em>Taskset</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AppImpl extends EObjectImpl implements App {
	/**
	 * The cached value of the '{@link #getNavigation() <em>Navigation</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNavigation()
	 * @generated
	 * @ordered
	 */
	protected Navigation navigation;

	/**
	 * The cached value of the '{@link #getLayout() <em>Layout</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLayout()
	 * @generated
	 * @ordered
	 */
	protected Layout layout;

	/**
	 * The cached value of the '{@link #getTaskset() <em>Taskset</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTaskset()
	 * @generated
	 * @ordered
	 */
	protected TaskFeature taskset;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AppImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.APP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Navigation getNavigation() {
		return navigation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetNavigation(Navigation newNavigation, NotificationChain msgs) {
		Navigation oldNavigation = navigation;
		navigation = newNavigation;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UIAdaptationPackage.APP__NAVIGATION, oldNavigation, newNavigation);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNavigation(Navigation newNavigation) {
		if (newNavigation != navigation) {
			NotificationChain msgs = null;
			if (navigation != null)
				msgs = ((InternalEObject) navigation).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.APP__NAVIGATION, null, msgs);
			if (newNavigation != null)
				msgs = ((InternalEObject) newNavigation).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.APP__NAVIGATION, null, msgs);
			msgs = basicSetNavigation(newNavigation, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.APP__NAVIGATION, newNavigation,
					newNavigation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Layout getLayout() {
		return layout;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLayout(Layout newLayout, NotificationChain msgs) {
		Layout oldLayout = layout;
		layout = newLayout;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UIAdaptationPackage.APP__LAYOUT, oldLayout, newLayout);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLayout(Layout newLayout) {
		if (newLayout != layout) {
			NotificationChain msgs = null;
			if (layout != null)
				msgs = ((InternalEObject) layout).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.APP__LAYOUT, null, msgs);
			if (newLayout != null)
				msgs = ((InternalEObject) newLayout).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.APP__LAYOUT, null, msgs);
			msgs = basicSetLayout(newLayout, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.APP__LAYOUT, newLayout,
					newLayout));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TaskFeature getTaskset() {
		return taskset;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTaskset(TaskFeature newTaskset, NotificationChain msgs) {
		TaskFeature oldTaskset = taskset;
		taskset = newTaskset;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UIAdaptationPackage.APP__TASKSET, oldTaskset, newTaskset);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTaskset(TaskFeature newTaskset) {
		if (newTaskset != taskset) {
			NotificationChain msgs = null;
			if (taskset != null)
				msgs = ((InternalEObject) taskset).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.APP__TASKSET, null, msgs);
			if (newTaskset != null)
				msgs = ((InternalEObject) newTaskset).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.APP__TASKSET, null, msgs);
			msgs = basicSetTaskset(newTaskset, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.APP__TASKSET, newTaskset,
					newTaskset));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UIAdaptationPackage.APP__NAVIGATION:
			return basicSetNavigation(null, msgs);
		case UIAdaptationPackage.APP__LAYOUT:
			return basicSetLayout(null, msgs);
		case UIAdaptationPackage.APP__TASKSET:
			return basicSetTaskset(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UIAdaptationPackage.APP__NAVIGATION:
			return getNavigation();
		case UIAdaptationPackage.APP__LAYOUT:
			return getLayout();
		case UIAdaptationPackage.APP__TASKSET:
			return getTaskset();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UIAdaptationPackage.APP__NAVIGATION:
			setNavigation((Navigation) newValue);
			return;
		case UIAdaptationPackage.APP__LAYOUT:
			setLayout((Layout) newValue);
			return;
		case UIAdaptationPackage.APP__TASKSET:
			setTaskset((TaskFeature) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.APP__NAVIGATION:
			setNavigation((Navigation) null);
			return;
		case UIAdaptationPackage.APP__LAYOUT:
			setLayout((Layout) null);
			return;
		case UIAdaptationPackage.APP__TASKSET:
			setTaskset((TaskFeature) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.APP__NAVIGATION:
			return navigation != null;
		case UIAdaptationPackage.APP__LAYOUT:
			return layout != null;
		case UIAdaptationPackage.APP__TASKSET:
			return taskset != null;
		}
		return super.eIsSet(featureID);
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //AppImpl
