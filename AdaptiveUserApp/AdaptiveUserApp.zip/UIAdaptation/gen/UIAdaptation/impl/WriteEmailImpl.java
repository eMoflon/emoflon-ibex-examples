/**
 */
package UIAdaptation.impl;

import UIAdaptation.UIAdaptationPackage;
import UIAdaptation.WriteEmail;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Write Email</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public abstract class WriteEmailImpl extends EObjectImpl implements WriteEmail {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WriteEmailImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.WRITE_EMAIL;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //WriteEmailImpl
