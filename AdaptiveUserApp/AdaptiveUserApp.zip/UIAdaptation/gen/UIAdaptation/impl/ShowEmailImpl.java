/**
 */
package UIAdaptation.impl;

import UIAdaptation.EmailForm;
import UIAdaptation.ShowEmail;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Show Email</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UIAdaptation.impl.ShowEmailImpl#getEmailForm <em>Email Form</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ShowEmailImpl extends EObjectImpl implements ShowEmail {
	/**
	 * The cached value of the '{@link #getEmailForm() <em>Email Form</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmailForm()
	 * @generated
	 * @ordered
	 */
	protected EmailForm emailForm;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ShowEmailImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.SHOW_EMAIL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EmailForm getEmailForm() {
		if (emailForm != null && emailForm.eIsProxy()) {
			InternalEObject oldEmailForm = (InternalEObject) emailForm;
			emailForm = (EmailForm) eResolveProxy(oldEmailForm);
			if (emailForm != oldEmailForm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							UIAdaptationPackage.SHOW_EMAIL__EMAIL_FORM, oldEmailForm, emailForm));
			}
		}
		return emailForm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EmailForm basicGetEmailForm() {
		return emailForm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEmailForm(EmailForm newEmailForm) {
		EmailForm oldEmailForm = emailForm;
		emailForm = newEmailForm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.SHOW_EMAIL__EMAIL_FORM,
					oldEmailForm, emailForm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UIAdaptationPackage.SHOW_EMAIL__EMAIL_FORM:
			if (resolve)
				return getEmailForm();
			return basicGetEmailForm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UIAdaptationPackage.SHOW_EMAIL__EMAIL_FORM:
			setEmailForm((EmailForm) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.SHOW_EMAIL__EMAIL_FORM:
			setEmailForm((EmailForm) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.SHOW_EMAIL__EMAIL_FORM:
			return emailForm != null;
		}
		return super.eIsSet(featureID);
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //ShowEmailImpl
