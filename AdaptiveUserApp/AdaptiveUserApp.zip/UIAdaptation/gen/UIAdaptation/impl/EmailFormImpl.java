/**
 */
package UIAdaptation.impl;

import UIAdaptation.EmailForm;
import UIAdaptation.HTML;
import UIAdaptation.TextForm;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Email Form</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UIAdaptation.impl.EmailFormImpl#getHtml <em>Html</em>}</li>
 *   <li>{@link UIAdaptation.impl.EmailFormImpl#getTextForm <em>Text Form</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EmailFormImpl extends EObjectImpl implements EmailForm {
	/**
	 * The cached value of the '{@link #getHtml() <em>Html</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHtml()
	 * @generated
	 * @ordered
	 */
	protected HTML html;

	/**
	 * The cached value of the '{@link #getTextForm() <em>Text Form</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTextForm()
	 * @generated
	 * @ordered
	 */
	protected TextForm textForm;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EmailFormImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.EMAIL_FORM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HTML getHtml() {
		return html;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetHtml(HTML newHtml, NotificationChain msgs) {
		HTML oldHtml = html;
		html = newHtml;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UIAdaptationPackage.EMAIL_FORM__HTML, oldHtml, newHtml);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHtml(HTML newHtml) {
		if (newHtml != html) {
			NotificationChain msgs = null;
			if (html != null)
				msgs = ((InternalEObject) html).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.EMAIL_FORM__HTML, null, msgs);
			if (newHtml != null)
				msgs = ((InternalEObject) newHtml).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.EMAIL_FORM__HTML, null, msgs);
			msgs = basicSetHtml(newHtml, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.EMAIL_FORM__HTML, newHtml,
					newHtml));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TextForm getTextForm() {
		return textForm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTextForm(TextForm newTextForm, NotificationChain msgs) {
		TextForm oldTextForm = textForm;
		textForm = newTextForm;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UIAdaptationPackage.EMAIL_FORM__TEXT_FORM, oldTextForm, newTextForm);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTextForm(TextForm newTextForm) {
		if (newTextForm != textForm) {
			NotificationChain msgs = null;
			if (textForm != null)
				msgs = ((InternalEObject) textForm).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.EMAIL_FORM__TEXT_FORM, null, msgs);
			if (newTextForm != null)
				msgs = ((InternalEObject) newTextForm).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.EMAIL_FORM__TEXT_FORM, null, msgs);
			msgs = basicSetTextForm(newTextForm, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.EMAIL_FORM__TEXT_FORM,
					newTextForm, newTextForm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UIAdaptationPackage.EMAIL_FORM__HTML:
			return basicSetHtml(null, msgs);
		case UIAdaptationPackage.EMAIL_FORM__TEXT_FORM:
			return basicSetTextForm(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UIAdaptationPackage.EMAIL_FORM__HTML:
			return getHtml();
		case UIAdaptationPackage.EMAIL_FORM__TEXT_FORM:
			return getTextForm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UIAdaptationPackage.EMAIL_FORM__HTML:
			setHtml((HTML) newValue);
			return;
		case UIAdaptationPackage.EMAIL_FORM__TEXT_FORM:
			setTextForm((TextForm) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.EMAIL_FORM__HTML:
			setHtml((HTML) null);
			return;
		case UIAdaptationPackage.EMAIL_FORM__TEXT_FORM:
			setTextForm((TextForm) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.EMAIL_FORM__HTML:
			return html != null;
		case UIAdaptationPackage.EMAIL_FORM__TEXT_FORM:
			return textForm != null;
		}
		return super.eIsSet(featureID);
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //EmailFormImpl
