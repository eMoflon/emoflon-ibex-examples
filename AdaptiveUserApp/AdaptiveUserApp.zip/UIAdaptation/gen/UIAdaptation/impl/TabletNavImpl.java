/**
 */
package UIAdaptation.impl;

import UIAdaptation.TabletNav;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tablet Nav</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UIAdaptation.impl.TabletNavImpl#isActivate <em>Activate</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TabletNavImpl extends NaviTypeImpl implements TabletNav {
	/**
	 * The default value of the '{@link #isActivate() <em>Activate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isActivate()
	 * @generated
	 * @ordered
	 */
	protected static final boolean ACTIVATE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isActivate() <em>Activate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isActivate()
	 * @generated
	 * @ordered
	 */
	protected boolean activate = ACTIVATE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TabletNavImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.TABLET_NAV;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isActivate() {
		return activate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setActivate(boolean newActivate) {
		boolean oldActivate = activate;
		activate = newActivate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.TABLET_NAV__ACTIVATE, oldActivate,
					activate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UIAdaptationPackage.TABLET_NAV__ACTIVATE:
			return isActivate();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UIAdaptationPackage.TABLET_NAV__ACTIVATE:
			setActivate((Boolean) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.TABLET_NAV__ACTIVATE:
			setActivate(ACTIVATE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.TABLET_NAV__ACTIVATE:
			return activate != ACTIVATE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (activate: ");
		result.append(activate);
		result.append(')');
		return result.toString();
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //TabletNavImpl
