/**
 */
package UIAdaptation.impl;

import UIAdaptation.FeedbackBar;
import UIAdaptation.NaviType;
import UIAdaptation.Navigation;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Navigation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UIAdaptation.impl.NavigationImpl#getButton <em>Button</em>}</li>
 *   <li>{@link UIAdaptation.impl.NavigationImpl#getMenu <em>Menu</em>}</li>
 *   <li>{@link UIAdaptation.impl.NavigationImpl#isDrivingMode <em>Driving Mode</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class NavigationImpl extends EObjectImpl implements Navigation {
	/**
	 * The cached value of the '{@link #getButton() <em>Button</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getButton()
	 * @generated
	 * @ordered
	 */
	protected FeedbackBar button;

	/**
	 * The cached value of the '{@link #getMenu() <em>Menu</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMenu()
	 * @generated
	 * @ordered
	 */
	protected NaviType menu;

	/**
	 * The default value of the '{@link #isDrivingMode() <em>Driving Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isDrivingMode()
	 * @generated
	 * @ordered
	 */
	protected static final boolean DRIVING_MODE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isDrivingMode() <em>Driving Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isDrivingMode()
	 * @generated
	 * @ordered
	 */
	protected boolean drivingMode = DRIVING_MODE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NavigationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.NAVIGATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FeedbackBar getButton() {
		return button;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetButton(FeedbackBar newButton, NotificationChain msgs) {
		FeedbackBar oldButton = button;
		button = newButton;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UIAdaptationPackage.NAVIGATION__BUTTON, oldButton, newButton);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setButton(FeedbackBar newButton) {
		if (newButton != button) {
			NotificationChain msgs = null;
			if (button != null)
				msgs = ((InternalEObject) button).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.NAVIGATION__BUTTON, null, msgs);
			if (newButton != null)
				msgs = ((InternalEObject) newButton).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.NAVIGATION__BUTTON, null, msgs);
			msgs = basicSetButton(newButton, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.NAVIGATION__BUTTON, newButton,
					newButton));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NaviType getMenu() {
		if (menu != null && menu.eIsProxy()) {
			InternalEObject oldMenu = (InternalEObject) menu;
			menu = (NaviType) eResolveProxy(oldMenu);
			if (menu != oldMenu) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UIAdaptationPackage.NAVIGATION__MENU,
							oldMenu, menu));
			}
		}
		return menu;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NaviType basicGetMenu() {
		return menu;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMenu(NaviType newMenu) {
		NaviType oldMenu = menu;
		menu = newMenu;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.NAVIGATION__MENU, oldMenu, menu));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isDrivingMode() {
		return drivingMode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDrivingMode(boolean newDrivingMode) {
		boolean oldDrivingMode = drivingMode;
		drivingMode = newDrivingMode;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.NAVIGATION__DRIVING_MODE,
					oldDrivingMode, drivingMode));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UIAdaptationPackage.NAVIGATION__BUTTON:
			return basicSetButton(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UIAdaptationPackage.NAVIGATION__BUTTON:
			return getButton();
		case UIAdaptationPackage.NAVIGATION__MENU:
			if (resolve)
				return getMenu();
			return basicGetMenu();
		case UIAdaptationPackage.NAVIGATION__DRIVING_MODE:
			return isDrivingMode();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UIAdaptationPackage.NAVIGATION__BUTTON:
			setButton((FeedbackBar) newValue);
			return;
		case UIAdaptationPackage.NAVIGATION__MENU:
			setMenu((NaviType) newValue);
			return;
		case UIAdaptationPackage.NAVIGATION__DRIVING_MODE:
			setDrivingMode((Boolean) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.NAVIGATION__BUTTON:
			setButton((FeedbackBar) null);
			return;
		case UIAdaptationPackage.NAVIGATION__MENU:
			setMenu((NaviType) null);
			return;
		case UIAdaptationPackage.NAVIGATION__DRIVING_MODE:
			setDrivingMode(DRIVING_MODE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.NAVIGATION__BUTTON:
			return button != null;
		case UIAdaptationPackage.NAVIGATION__MENU:
			return menu != null;
		case UIAdaptationPackage.NAVIGATION__DRIVING_MODE:
			return drivingMode != DRIVING_MODE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (DrivingMode: ");
		result.append(drivingMode);
		result.append(')');
		return result.toString();
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //NavigationImpl
