/**
 */
package UIAdaptation.impl;

import UIAdaptation.ColorScheme;
import UIAdaptation.FontSize;
import UIAdaptation.Layout;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Layout</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link UIAdaptation.impl.LayoutImpl#getColorScheme <em>Color Scheme</em>}</li>
 *   <li>{@link UIAdaptation.impl.LayoutImpl#getFontSize <em>Font Size</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class LayoutImpl extends EObjectImpl implements Layout {
	/**
	 * The cached value of the '{@link #getColorScheme() <em>Color Scheme</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getColorScheme()
	 * @generated
	 * @ordered
	 */
	protected ColorScheme colorScheme;

	/**
	 * The cached value of the '{@link #getFontSize() <em>Font Size</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFontSize()
	 * @generated
	 * @ordered
	 */
	protected FontSize fontSize;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LayoutImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.LAYOUT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ColorScheme getColorScheme() {
		return colorScheme;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetColorScheme(ColorScheme newColorScheme, NotificationChain msgs) {
		ColorScheme oldColorScheme = colorScheme;
		colorScheme = newColorScheme;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					UIAdaptationPackage.LAYOUT__COLOR_SCHEME, oldColorScheme, newColorScheme);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setColorScheme(ColorScheme newColorScheme) {
		if (newColorScheme != colorScheme) {
			NotificationChain msgs = null;
			if (colorScheme != null)
				msgs = ((InternalEObject) colorScheme).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.LAYOUT__COLOR_SCHEME, null, msgs);
			if (newColorScheme != null)
				msgs = ((InternalEObject) newColorScheme).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - UIAdaptationPackage.LAYOUT__COLOR_SCHEME, null, msgs);
			msgs = basicSetColorScheme(newColorScheme, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.LAYOUT__COLOR_SCHEME,
					newColorScheme, newColorScheme));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FontSize getFontSize() {
		if (fontSize != null && fontSize.eIsProxy()) {
			InternalEObject oldFontSize = (InternalEObject) fontSize;
			fontSize = (FontSize) eResolveProxy(oldFontSize);
			if (fontSize != oldFontSize) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UIAdaptationPackage.LAYOUT__FONT_SIZE,
							oldFontSize, fontSize));
			}
		}
		return fontSize;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FontSize basicGetFontSize() {
		return fontSize;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFontSize(FontSize newFontSize) {
		FontSize oldFontSize = fontSize;
		fontSize = newFontSize;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UIAdaptationPackage.LAYOUT__FONT_SIZE, oldFontSize,
					fontSize));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UIAdaptationPackage.LAYOUT__COLOR_SCHEME:
			return basicSetColorScheme(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UIAdaptationPackage.LAYOUT__COLOR_SCHEME:
			return getColorScheme();
		case UIAdaptationPackage.LAYOUT__FONT_SIZE:
			if (resolve)
				return getFontSize();
			return basicGetFontSize();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UIAdaptationPackage.LAYOUT__COLOR_SCHEME:
			setColorScheme((ColorScheme) newValue);
			return;
		case UIAdaptationPackage.LAYOUT__FONT_SIZE:
			setFontSize((FontSize) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.LAYOUT__COLOR_SCHEME:
			setColorScheme((ColorScheme) null);
			return;
		case UIAdaptationPackage.LAYOUT__FONT_SIZE:
			setFontSize((FontSize) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UIAdaptationPackage.LAYOUT__COLOR_SCHEME:
			return colorScheme != null;
		case UIAdaptationPackage.LAYOUT__FONT_SIZE:
			return fontSize != null;
		}
		return super.eIsSet(featureID);
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //LayoutImpl
