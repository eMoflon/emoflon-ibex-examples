/**
 */
package UIAdaptation.impl;

import UIAdaptation.MonoChromatic;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Mono Chromatic</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class MonoChromaticImpl extends ColorSchemeImpl implements MonoChromatic {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MonoChromaticImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.MONO_CHROMATIC;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //MonoChromaticImpl
