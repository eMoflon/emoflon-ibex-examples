/**
 */
package UIAdaptation.impl;

import UIAdaptation.BlacknWhite;
import UIAdaptation.UIAdaptationPackage;

import org.eclipse.emf.ecore.EClass;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Blackn White</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class BlacknWhiteImpl extends ColorSchemeImpl implements BlacknWhite {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BlacknWhiteImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UIAdaptationPackage.Literals.BLACKN_WHITE;
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //BlacknWhiteImpl
