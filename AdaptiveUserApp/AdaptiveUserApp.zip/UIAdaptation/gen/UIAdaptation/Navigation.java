/**
 */
package UIAdaptation;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Navigation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UIAdaptation.Navigation#getButton <em>Button</em>}</li>
 *   <li>{@link UIAdaptation.Navigation#getMenu <em>Menu</em>}</li>
 *   <li>{@link UIAdaptation.Navigation#isDrivingMode <em>Driving Mode</em>}</li>
 * </ul>
 * </p>
 *
 * @see UIAdaptation.UIAdaptationPackage#getNavigation()
 * @model
 * @generated
 */
public interface Navigation extends EObject {
	/**
	 * Returns the value of the '<em><b>Button</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Button</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Button</em>' containment reference.
	 * @see #setButton(FeedbackBar)
	 * @see UIAdaptation.UIAdaptationPackage#getNavigation_Button()
	 * @model containment="true"
	 * @generated
	 */
	FeedbackBar getButton();

	/**
	 * Sets the value of the '{@link UIAdaptation.Navigation#getButton <em>Button</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Button</em>' containment reference.
	 * @see #getButton()
	 * @generated
	 */
	void setButton(FeedbackBar value);

	/**
	 * Returns the value of the '<em><b>Menu</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Menu</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Menu</em>' reference.
	 * @see #setMenu(NaviType)
	 * @see UIAdaptation.UIAdaptationPackage#getNavigation_Menu()
	 * @model required="true"
	 * @generated
	 */
	NaviType getMenu();

	/**
	 * Sets the value of the '{@link UIAdaptation.Navigation#getMenu <em>Menu</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Menu</em>' reference.
	 * @see #getMenu()
	 * @generated
	 */
	void setMenu(NaviType value);

	/**
	 * Returns the value of the '<em><b>Driving Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Driving Mode</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Driving Mode</em>' attribute.
	 * @see #setDrivingMode(boolean)
	 * @see UIAdaptation.UIAdaptationPackage#getNavigation_DrivingMode()
	 * @model
	 * @generated
	 */
	boolean isDrivingMode();

	/**
	 * Sets the value of the '{@link UIAdaptation.Navigation#isDrivingMode <em>Driving Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Driving Mode</em>' attribute.
	 * @see #isDrivingMode()
	 * @generated
	 */
	void setDrivingMode(boolean value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Navigation
