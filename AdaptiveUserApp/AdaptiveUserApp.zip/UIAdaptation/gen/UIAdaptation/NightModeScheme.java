/**
 */
package UIAdaptation;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Night Mode Scheme</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UIAdaptation.UIAdaptationPackage#getNightModeScheme()
 * @model
 * @generated
 */
public interface NightModeScheme extends ColorScheme { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // NightModeScheme
