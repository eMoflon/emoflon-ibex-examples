/**
 */
package UIAdaptation;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Show Email</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UIAdaptation.ShowEmail#getEmailForm <em>Email Form</em>}</li>
 * </ul>
 * </p>
 *
 * @see UIAdaptation.UIAdaptationPackage#getShowEmail()
 * @model
 * @generated
 */
public interface ShowEmail extends EObject {
	/**
	 * Returns the value of the '<em><b>Email Form</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Email Form</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Email Form</em>' reference.
	 * @see #setEmailForm(EmailForm)
	 * @see UIAdaptation.UIAdaptationPackage#getShowEmail_EmailForm()
	 * @model
	 * @generated
	 */
	EmailForm getEmailForm();

	/**
	 * Sets the value of the '{@link UIAdaptation.ShowEmail#getEmailForm <em>Email Form</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Email Form</em>' reference.
	 * @see #getEmailForm()
	 * @generated
	 */
	void setEmailForm(EmailForm value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // ShowEmail
