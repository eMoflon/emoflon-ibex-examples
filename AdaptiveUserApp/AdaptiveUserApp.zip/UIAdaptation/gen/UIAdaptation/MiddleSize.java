/**
 */
package UIAdaptation;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Middle Size</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UIAdaptation.UIAdaptationPackage#getMiddleSize()
 * @model
 * @generated
 */
public interface MiddleSize extends FontSize { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // MiddleSize
