/**
 */
package UIAdaptation;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Click Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UIAdaptation.ClickEvent#getView <em>View</em>}</li>
 * </ul>
 * </p>
 *
 * @see UIAdaptation.UIAdaptationPackage#getClickEvent()
 * @model
 * @generated
 */
public interface ClickEvent extends EObject {
	/**
	 * Returns the value of the '<em><b>View</b></em>' reference list.
	 * The list contents are of type {@link UIAdaptation.View}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>View</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>View</em>' reference list.
	 * @see UIAdaptation.UIAdaptationPackage#getClickEvent_View()
	 * @model
	 * @generated
	 */
	EList<View> getView();
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // ClickEvent
