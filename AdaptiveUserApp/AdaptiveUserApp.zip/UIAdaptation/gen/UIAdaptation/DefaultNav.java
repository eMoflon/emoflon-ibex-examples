/**
 */
package UIAdaptation;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Default Nav</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UIAdaptation.UIAdaptationPackage#getDefaultNav()
 * @model
 * @generated
 */
public interface DefaultNav extends NaviType { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // DefaultNav
