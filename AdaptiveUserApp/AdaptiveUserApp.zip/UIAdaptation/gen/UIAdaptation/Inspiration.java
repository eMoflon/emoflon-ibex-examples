/**
 */
package UIAdaptation;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Inspiration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UIAdaptation.UIAdaptationPackage#getInspiration()
 * @model
 * @generated
 */
public interface Inspiration extends View { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Inspiration
