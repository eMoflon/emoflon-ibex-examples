/**
 */
package UIAdaptation;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Task Feature</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UIAdaptation.TaskFeature#getReadEmail <em>Read Email</em>}</li>
 *   <li>{@link UIAdaptation.TaskFeature#getShowEmail <em>Show Email</em>}</li>
 *   <li>{@link UIAdaptation.TaskFeature#getWriteEmail <em>Write Email</em>}</li>
 *   <li>{@link UIAdaptation.TaskFeature#getMenu <em>Menu</em>}</li>
 *   <li>{@link UIAdaptation.TaskFeature#isVocalUI <em>Vocal UI</em>}</li>
 * </ul>
 * </p>
 *
 * @see UIAdaptation.UIAdaptationPackage#getTaskFeature()
 * @model
 * @generated
 */
public interface TaskFeature extends EObject {
	/**
	 * Returns the value of the '<em><b>Read Email</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Read Email</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Read Email</em>' containment reference.
	 * @see #setReadEmail(ReadEmail)
	 * @see UIAdaptation.UIAdaptationPackage#getTaskFeature_ReadEmail()
	 * @model containment="true"
	 * @generated
	 */
	ReadEmail getReadEmail();

	/**
	 * Sets the value of the '{@link UIAdaptation.TaskFeature#getReadEmail <em>Read Email</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Read Email</em>' containment reference.
	 * @see #getReadEmail()
	 * @generated
	 */
	void setReadEmail(ReadEmail value);

	/**
	 * Returns the value of the '<em><b>Show Email</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Show Email</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Show Email</em>' containment reference.
	 * @see #setShowEmail(ShowEmail)
	 * @see UIAdaptation.UIAdaptationPackage#getTaskFeature_ShowEmail()
	 * @model containment="true" required="true"
	 * @generated
	 */
	ShowEmail getShowEmail();

	/**
	 * Sets the value of the '{@link UIAdaptation.TaskFeature#getShowEmail <em>Show Email</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Show Email</em>' containment reference.
	 * @see #getShowEmail()
	 * @generated
	 */
	void setShowEmail(ShowEmail value);

	/**
	 * Returns the value of the '<em><b>Write Email</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Write Email</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Write Email</em>' containment reference.
	 * @see #setWriteEmail(WriteEmail)
	 * @see UIAdaptation.UIAdaptationPackage#getTaskFeature_WriteEmail()
	 * @model containment="true"
	 * @generated
	 */
	WriteEmail getWriteEmail();

	/**
	 * Sets the value of the '{@link UIAdaptation.TaskFeature#getWriteEmail <em>Write Email</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Write Email</em>' containment reference.
	 * @see #getWriteEmail()
	 * @generated
	 */
	void setWriteEmail(WriteEmail value);

	/**
	 * Returns the value of the '<em><b>Menu</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Menu</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Menu</em>' containment reference.
	 * @see #setMenu(Menu)
	 * @see UIAdaptation.UIAdaptationPackage#getTaskFeature_Menu()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Menu getMenu();

	/**
	 * Sets the value of the '{@link UIAdaptation.TaskFeature#getMenu <em>Menu</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Menu</em>' containment reference.
	 * @see #getMenu()
	 * @generated
	 */
	void setMenu(Menu value);

	/**
	 * Returns the value of the '<em><b>Vocal UI</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vocal UI</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vocal UI</em>' attribute.
	 * @see #setVocalUI(boolean)
	 * @see UIAdaptation.UIAdaptationPackage#getTaskFeature_VocalUI()
	 * @model
	 * @generated
	 */
	boolean isVocalUI();

	/**
	 * Sets the value of the '{@link UIAdaptation.TaskFeature#isVocalUI <em>Vocal UI</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vocal UI</em>' attribute.
	 * @see #isVocalUI()
	 * @generated
	 */
	void setVocalUI(boolean value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // TaskFeature
