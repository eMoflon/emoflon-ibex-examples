/**
 */
package UIAdaptation;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Menu Enum</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see UIAdaptation.UIAdaptationPackage#getMenuEnum()
 * @model
 * @generated
 */
public enum MenuEnum implements Enumerator {
	/**
	 * The '<em><b>Inbox</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #INBOX_VALUE
	 * @generated
	 * @ordered
	 */
	INBOX(0, "Inbox", "Inbox"),

	/**
	 * The '<em><b>Drafts</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DRAFTS_VALUE
	 * @generated
	 * @ordered
	 */
	DRAFTS(1, "Drafts", "Drafts"),

	/**
	 * The '<em><b>Sent</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SENT_VALUE
	 * @generated
	 * @ordered
	 */
	SENT(2, "Sent", "Sent"),

	/**
	 * The '<em><b>Spam</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SPAM_VALUE
	 * @generated
	 * @ordered
	 */
	SPAM(3, "Spam", "Spam"),

	/**
	 * The '<em><b>Trash</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TRASH_VALUE
	 * @generated
	 * @ordered
	 */
	TRASH(4, "Trash", "Trash"),

	/**
	 * The '<em><b>Setting</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SETTING_VALUE
	 * @generated
	 * @ordered
	 */
	SETTING(5, "Setting", "Setting"),

	/**
	 * The '<em><b>Logout</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LOGOUT_VALUE
	 * @generated
	 * @ordered
	 */
	LOGOUT(6, "Logout", "Logout");

	/**
	 * The '<em><b>Inbox</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Inbox</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #INBOX
	 * @model name="Inbox"
	 * @generated
	 * @ordered
	 */
	public static final int INBOX_VALUE = 0;

	/**
	 * The '<em><b>Drafts</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Drafts</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DRAFTS
	 * @model name="Drafts"
	 * @generated
	 * @ordered
	 */
	public static final int DRAFTS_VALUE = 1;

	/**
	 * The '<em><b>Sent</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Sent</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SENT
	 * @model name="Sent"
	 * @generated
	 * @ordered
	 */
	public static final int SENT_VALUE = 2;

	/**
	 * The '<em><b>Spam</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Spam</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SPAM
	 * @model name="Spam"
	 * @generated
	 * @ordered
	 */
	public static final int SPAM_VALUE = 3;

	/**
	 * The '<em><b>Trash</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Trash</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TRASH
	 * @model name="Trash"
	 * @generated
	 * @ordered
	 */
	public static final int TRASH_VALUE = 4;

	/**
	 * The '<em><b>Setting</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Setting</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SETTING
	 * @model name="Setting"
	 * @generated
	 * @ordered
	 */
	public static final int SETTING_VALUE = 5;

	/**
	 * The '<em><b>Logout</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Logout</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #LOGOUT
	 * @model name="Logout"
	 * @generated
	 * @ordered
	 */
	public static final int LOGOUT_VALUE = 6;

	/**
	 * An array of all the '<em><b>Menu Enum</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final MenuEnum[] VALUES_ARRAY = new MenuEnum[] { INBOX, DRAFTS, SENT, SPAM, TRASH, SETTING,
			LOGOUT, };

	/**
	 * A public read-only list of all the '<em><b>Menu Enum</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<MenuEnum> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Menu Enum</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static MenuEnum get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			MenuEnum result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Menu Enum</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static MenuEnum getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			MenuEnum result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Menu Enum</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static MenuEnum get(int value) {
		switch (value) {
		case INBOX_VALUE:
			return INBOX;
		case DRAFTS_VALUE:
			return DRAFTS;
		case SENT_VALUE:
			return SENT;
		case SPAM_VALUE:
			return SPAM;
		case TRASH_VALUE:
			return TRASH;
		case SETTING_VALUE:
			return SETTING;
		case LOGOUT_VALUE:
			return LOGOUT;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private MenuEnum(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //MenuEnum
