/**
 */
package UIAdaptation;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attachments</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UIAdaptation.Attachments#getAutoDownload <em>Auto Download</em>}</li>
 * </ul>
 * </p>
 *
 * @see UIAdaptation.UIAdaptationPackage#getAttachments()
 * @model
 * @generated
 */
public interface Attachments extends EObject {
	/**
	 * Returns the value of the '<em><b>Auto Download</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Auto Download</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Auto Download</em>' reference.
	 * @see #setAutoDownload(AutoDownload)
	 * @see UIAdaptation.UIAdaptationPackage#getAttachments_AutoDownload()
	 * @model
	 * @generated
	 */
	AutoDownload getAutoDownload();

	/**
	 * Sets the value of the '{@link UIAdaptation.Attachments#getAutoDownload <em>Auto Download</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Auto Download</em>' reference.
	 * @see #getAutoDownload()
	 * @generated
	 */
	void setAutoDownload(AutoDownload value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Attachments
