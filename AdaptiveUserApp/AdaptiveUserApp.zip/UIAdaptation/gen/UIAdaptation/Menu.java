/**
 */
package UIAdaptation;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Menu</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UIAdaptation.Menu#getMenuEnum <em>Menu Enum</em>}</li>
 * </ul>
 * </p>
 *
 * @see UIAdaptation.UIAdaptationPackage#getMenu()
 * @model abstract="true"
 * @generated
 */
public interface Menu extends EObject {
	/**
	 * Returns the value of the '<em><b>Menu Enum</b></em>' attribute.
	 * The literals are from the enumeration {@link UIAdaptation.MenuEnum}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Menu Enum</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Menu Enum</em>' attribute.
	 * @see UIAdaptation.MenuEnum
	 * @see #setMenuEnum(MenuEnum)
	 * @see UIAdaptation.UIAdaptationPackage#getMenu_MenuEnum()
	 * @model
	 * @generated
	 */
	MenuEnum getMenuEnum();

	/**
	 * Sets the value of the '{@link UIAdaptation.Menu#getMenuEnum <em>Menu Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Menu Enum</em>' attribute.
	 * @see UIAdaptation.MenuEnum
	 * @see #getMenuEnum()
	 * @generated
	 */
	void setMenuEnum(MenuEnum value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Menu
