/**
 */
package UIAdaptation;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Email Form</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link UIAdaptation.EmailForm#getHtml <em>Html</em>}</li>
 *   <li>{@link UIAdaptation.EmailForm#getTextForm <em>Text Form</em>}</li>
 * </ul>
 * </p>
 *
 * @see UIAdaptation.UIAdaptationPackage#getEmailForm()
 * @model
 * @generated
 */
public interface EmailForm extends EObject {
	/**
	 * Returns the value of the '<em><b>Html</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Html</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Html</em>' containment reference.
	 * @see #setHtml(HTML)
	 * @see UIAdaptation.UIAdaptationPackage#getEmailForm_Html()
	 * @model containment="true"
	 * @generated
	 */
	HTML getHtml();

	/**
	 * Sets the value of the '{@link UIAdaptation.EmailForm#getHtml <em>Html</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Html</em>' containment reference.
	 * @see #getHtml()
	 * @generated
	 */
	void setHtml(HTML value);

	/**
	 * Returns the value of the '<em><b>Text Form</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Text Form</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Text Form</em>' containment reference.
	 * @see #setTextForm(TextForm)
	 * @see UIAdaptation.UIAdaptationPackage#getEmailForm_TextForm()
	 * @model containment="true"
	 * @generated
	 */
	TextForm getTextForm();

	/**
	 * Sets the value of the '{@link UIAdaptation.EmailForm#getTextForm <em>Text Form</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Text Form</em>' containment reference.
	 * @see #getTextForm()
	 * @generated
	 */
	void setTextForm(TextForm value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // EmailForm
