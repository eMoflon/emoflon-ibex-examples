/**
 */
package UIAdaptation;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see UIAdaptation.UIAdaptationPackage
 * @generated
 */
public interface UIAdaptationFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	UIAdaptationFactory eINSTANCE = UIAdaptation.impl.UIAdaptationFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>App</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>App</em>'.
	 * @generated
	 */
	App createApp();

	/**
	 * Returns a new object of class '<em>Navigation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Navigation</em>'.
	 * @generated
	 */
	Navigation createNavigation();

	/**
	 * Returns a new object of class '<em>Grid Nav</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Grid Nav</em>'.
	 * @generated
	 */
	GridNav createGridNav();

	/**
	 * Returns a new object of class '<em>Default Nav</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Default Nav</em>'.
	 * @generated
	 */
	DefaultNav createDefaultNav();

	/**
	 * Returns a new object of class '<em>Tablet Nav</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tablet Nav</em>'.
	 * @generated
	 */
	TabletNav createTabletNav();

	/**
	 * Returns a new object of class '<em>Minimum Navigation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Minimum Navigation</em>'.
	 * @generated
	 */
	MinimumNavigation createMinimumNavigation();

	/**
	 * Returns a new object of class '<em>Less Informed Nav</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Less Informed Nav</em>'.
	 * @generated
	 */
	LessInformedNav createLessInformedNav();

	/**
	 * Returns a new object of class '<em>More Informed Nav</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>More Informed Nav</em>'.
	 * @generated
	 */
	MoreInformedNav createMoreInformedNav();

	/**
	 * Returns a new object of class '<em>Feedback Bar</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Feedback Bar</em>'.
	 * @generated
	 */
	FeedbackBar createFeedbackBar();

	/**
	 * Returns a new object of class '<em>Click Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Click Event</em>'.
	 * @generated
	 */
	ClickEvent createClickEvent();

	/**
	 * Returns a new object of class '<em>Feedback</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Feedback</em>'.
	 * @generated
	 */
	Feedback createFeedback();

	/**
	 * Returns a new object of class '<em>Inspiration</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Inspiration</em>'.
	 * @generated
	 */
	Inspiration createInspiration();

	/**
	 * Returns a new object of class '<em>Layout</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Layout</em>'.
	 * @generated
	 */
	Layout createLayout();

	/**
	 * Returns a new object of class '<em>Default Size</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Default Size</em>'.
	 * @generated
	 */
	DefaultSize createDefaultSize();

	/**
	 * Returns a new object of class '<em>Large Size</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Large Size</em>'.
	 * @generated
	 */
	LargeSize createLargeSize();

	/**
	 * Returns a new object of class '<em>Middle Size</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Middle Size</em>'.
	 * @generated
	 */
	MiddleSize createMiddleSize();

	/**
	 * Returns a new object of class '<em>Custom Color</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Custom Color</em>'.
	 * @generated
	 */
	CustomColor createCustomColor();

	/**
	 * Returns a new object of class '<em>Blackn White</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Blackn White</em>'.
	 * @generated
	 */
	BlacknWhite createBlacknWhite();

	/**
	 * Returns a new object of class '<em>Mono Chromatic</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mono Chromatic</em>'.
	 * @generated
	 */
	MonoChromatic createMonoChromatic();

	/**
	 * Returns a new object of class '<em>Night Mode Scheme</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Night Mode Scheme</em>'.
	 * @generated
	 */
	NightModeScheme createNightModeScheme();

	/**
	 * Returns a new object of class '<em>Task Feature</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Task Feature</em>'.
	 * @generated
	 */
	TaskFeature createTaskFeature();

	/**
	 * Returns a new object of class '<em>Attachments</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attachments</em>'.
	 * @generated
	 */
	Attachments createAttachments();

	/**
	 * Returns a new object of class '<em>Auto Download</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Auto Download</em>'.
	 * @generated
	 */
	AutoDownload createAutoDownload();

	/**
	 * Returns a new object of class '<em>Read Email</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Read Email</em>'.
	 * @generated
	 */
	ReadEmail createReadEmail();

	/**
	 * Returns a new object of class '<em>Show Email</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Show Email</em>'.
	 * @generated
	 */
	ShowEmail createShowEmail();

	/**
	 * Returns a new object of class '<em>Email Form</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Email Form</em>'.
	 * @generated
	 */
	EmailForm createEmailForm();

	/**
	 * Returns a new object of class '<em>HTML</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>HTML</em>'.
	 * @generated
	 */
	HTML createHTML();

	/**
	 * Returns a new object of class '<em>Text Form</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Text Form</em>'.
	 * @generated
	 */
	TextForm createTextForm();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	UIAdaptationPackage getUIAdaptationPackage();

} //UIAdaptationFactory
