/**
 */
package UIAdaptation;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>More Informed Nav</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UIAdaptation.UIAdaptationPackage#getMoreInformedNav()
 * @model
 * @generated
 */
public interface MoreInformedNav extends Navigation { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // MoreInformedNav
