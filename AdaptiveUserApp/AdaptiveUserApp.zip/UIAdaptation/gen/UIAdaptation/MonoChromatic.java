/**
 */
package UIAdaptation;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mono Chromatic</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UIAdaptation.UIAdaptationPackage#getMonoChromatic()
 * @model
 * @generated
 */
public interface MonoChromatic extends ColorScheme { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // MonoChromatic
