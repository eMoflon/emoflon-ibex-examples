/**
 */
package UIAdaptation;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Large Size</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UIAdaptation.UIAdaptationPackage#getLargeSize()
 * @model
 * @generated
 */
public interface LargeSize extends FontSize { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // LargeSize
