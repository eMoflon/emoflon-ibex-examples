/**
 */
package UIAdaptation;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Navi Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UIAdaptation.UIAdaptationPackage#getNaviType()
 * @model abstract="true"
 * @generated
 */
public interface NaviType extends EObject { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // NaviType
