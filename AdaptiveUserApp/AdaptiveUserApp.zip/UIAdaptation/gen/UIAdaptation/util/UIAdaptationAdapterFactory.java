/**
 */
package UIAdaptation.util;

import UIAdaptation.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see UIAdaptation.UIAdaptationPackage
 * @generated
 */
public class UIAdaptationAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static UIAdaptationPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UIAdaptationAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = UIAdaptationPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UIAdaptationSwitch<Adapter> modelSwitch = new UIAdaptationSwitch<Adapter>() {
		@Override
		public Adapter caseApp(App object) {
			return createAppAdapter();
		}

		@Override
		public Adapter caseNavigation(Navigation object) {
			return createNavigationAdapter();
		}

		@Override
		public Adapter caseNaviType(NaviType object) {
			return createNaviTypeAdapter();
		}

		@Override
		public Adapter caseGridNav(GridNav object) {
			return createGridNavAdapter();
		}

		@Override
		public Adapter caseDefaultNav(DefaultNav object) {
			return createDefaultNavAdapter();
		}

		@Override
		public Adapter caseTabletNav(TabletNav object) {
			return createTabletNavAdapter();
		}

		@Override
		public Adapter caseMinimumNavigation(MinimumNavigation object) {
			return createMinimumNavigationAdapter();
		}

		@Override
		public Adapter caseLessInformedNav(LessInformedNav object) {
			return createLessInformedNavAdapter();
		}

		@Override
		public Adapter caseMoreInformedNav(MoreInformedNav object) {
			return createMoreInformedNavAdapter();
		}

		@Override
		public Adapter caseFeedbackBar(FeedbackBar object) {
			return createFeedbackBarAdapter();
		}

		@Override
		public Adapter caseClickEvent(ClickEvent object) {
			return createClickEventAdapter();
		}

		@Override
		public Adapter caseView(View object) {
			return createViewAdapter();
		}

		@Override
		public Adapter caseFeedback(Feedback object) {
			return createFeedbackAdapter();
		}

		@Override
		public Adapter caseInspiration(Inspiration object) {
			return createInspirationAdapter();
		}

		@Override
		public Adapter caseLayout(Layout object) {
			return createLayoutAdapter();
		}

		@Override
		public Adapter caseFontSize(FontSize object) {
			return createFontSizeAdapter();
		}

		@Override
		public Adapter caseDefaultSize(DefaultSize object) {
			return createDefaultSizeAdapter();
		}

		@Override
		public Adapter caseLargeSize(LargeSize object) {
			return createLargeSizeAdapter();
		}

		@Override
		public Adapter caseMiddleSize(MiddleSize object) {
			return createMiddleSizeAdapter();
		}

		@Override
		public Adapter caseColorScheme(ColorScheme object) {
			return createColorSchemeAdapter();
		}

		@Override
		public Adapter caseCustomColor(CustomColor object) {
			return createCustomColorAdapter();
		}

		@Override
		public Adapter caseBlacknWhite(BlacknWhite object) {
			return createBlacknWhiteAdapter();
		}

		@Override
		public Adapter caseMonoChromatic(MonoChromatic object) {
			return createMonoChromaticAdapter();
		}

		@Override
		public Adapter caseNightModeScheme(NightModeScheme object) {
			return createNightModeSchemeAdapter();
		}

		@Override
		public Adapter caseTaskFeature(TaskFeature object) {
			return createTaskFeatureAdapter();
		}

		@Override
		public Adapter caseMenu(Menu object) {
			return createMenuAdapter();
		}

		@Override
		public Adapter caseAttachments(Attachments object) {
			return createAttachmentsAdapter();
		}

		@Override
		public Adapter caseAutoDownload(AutoDownload object) {
			return createAutoDownloadAdapter();
		}

		@Override
		public Adapter caseReadEmail(ReadEmail object) {
			return createReadEmailAdapter();
		}

		@Override
		public Adapter caseShowEmail(ShowEmail object) {
			return createShowEmailAdapter();
		}

		@Override
		public Adapter caseWriteEmail(WriteEmail object) {
			return createWriteEmailAdapter();
		}

		@Override
		public Adapter caseEmailForm(EmailForm object) {
			return createEmailFormAdapter();
		}

		@Override
		public Adapter caseHTML(HTML object) {
			return createHTMLAdapter();
		}

		@Override
		public Adapter caseTextForm(TextForm object) {
			return createTextFormAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.App <em>App</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.App
	 * @generated
	 */
	public Adapter createAppAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.Navigation <em>Navigation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.Navigation
	 * @generated
	 */
	public Adapter createNavigationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.NaviType <em>Navi Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.NaviType
	 * @generated
	 */
	public Adapter createNaviTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.GridNav <em>Grid Nav</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.GridNav
	 * @generated
	 */
	public Adapter createGridNavAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.DefaultNav <em>Default Nav</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.DefaultNav
	 * @generated
	 */
	public Adapter createDefaultNavAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.TabletNav <em>Tablet Nav</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.TabletNav
	 * @generated
	 */
	public Adapter createTabletNavAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.MinimumNavigation <em>Minimum Navigation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.MinimumNavigation
	 * @generated
	 */
	public Adapter createMinimumNavigationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.LessInformedNav <em>Less Informed Nav</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.LessInformedNav
	 * @generated
	 */
	public Adapter createLessInformedNavAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.MoreInformedNav <em>More Informed Nav</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.MoreInformedNav
	 * @generated
	 */
	public Adapter createMoreInformedNavAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.FeedbackBar <em>Feedback Bar</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.FeedbackBar
	 * @generated
	 */
	public Adapter createFeedbackBarAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.ClickEvent <em>Click Event</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.ClickEvent
	 * @generated
	 */
	public Adapter createClickEventAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.View <em>View</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.View
	 * @generated
	 */
	public Adapter createViewAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.Feedback <em>Feedback</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.Feedback
	 * @generated
	 */
	public Adapter createFeedbackAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.Inspiration <em>Inspiration</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.Inspiration
	 * @generated
	 */
	public Adapter createInspirationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.Layout <em>Layout</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.Layout
	 * @generated
	 */
	public Adapter createLayoutAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.FontSize <em>Font Size</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.FontSize
	 * @generated
	 */
	public Adapter createFontSizeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.DefaultSize <em>Default Size</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.DefaultSize
	 * @generated
	 */
	public Adapter createDefaultSizeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.LargeSize <em>Large Size</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.LargeSize
	 * @generated
	 */
	public Adapter createLargeSizeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.MiddleSize <em>Middle Size</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.MiddleSize
	 * @generated
	 */
	public Adapter createMiddleSizeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.ColorScheme <em>Color Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.ColorScheme
	 * @generated
	 */
	public Adapter createColorSchemeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.CustomColor <em>Custom Color</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.CustomColor
	 * @generated
	 */
	public Adapter createCustomColorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.BlacknWhite <em>Blackn White</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.BlacknWhite
	 * @generated
	 */
	public Adapter createBlacknWhiteAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.MonoChromatic <em>Mono Chromatic</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.MonoChromatic
	 * @generated
	 */
	public Adapter createMonoChromaticAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.NightModeScheme <em>Night Mode Scheme</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.NightModeScheme
	 * @generated
	 */
	public Adapter createNightModeSchemeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.TaskFeature <em>Task Feature</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.TaskFeature
	 * @generated
	 */
	public Adapter createTaskFeatureAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.Menu <em>Menu</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.Menu
	 * @generated
	 */
	public Adapter createMenuAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.Attachments <em>Attachments</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.Attachments
	 * @generated
	 */
	public Adapter createAttachmentsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.AutoDownload <em>Auto Download</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.AutoDownload
	 * @generated
	 */
	public Adapter createAutoDownloadAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.ReadEmail <em>Read Email</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.ReadEmail
	 * @generated
	 */
	public Adapter createReadEmailAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.ShowEmail <em>Show Email</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.ShowEmail
	 * @generated
	 */
	public Adapter createShowEmailAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.WriteEmail <em>Write Email</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.WriteEmail
	 * @generated
	 */
	public Adapter createWriteEmailAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.EmailForm <em>Email Form</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.EmailForm
	 * @generated
	 */
	public Adapter createEmailFormAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.HTML <em>HTML</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.HTML
	 * @generated
	 */
	public Adapter createHTMLAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link UIAdaptation.TextForm <em>Text Form</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see UIAdaptation.TextForm
	 * @generated
	 */
	public Adapter createTextFormAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //UIAdaptationAdapterFactory
