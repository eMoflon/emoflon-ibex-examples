/**
 */
package UIAdaptation.util;

import UIAdaptation.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see UIAdaptation.UIAdaptationPackage
 * @generated
 */
public class UIAdaptationSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static UIAdaptationPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UIAdaptationSwitch() {
		if (modelPackage == null) {
			modelPackage = UIAdaptationPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case UIAdaptationPackage.APP: {
			App app = (App) theEObject;
			T result = caseApp(app);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.NAVIGATION: {
			Navigation navigation = (Navigation) theEObject;
			T result = caseNavigation(navigation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.NAVI_TYPE: {
			NaviType naviType = (NaviType) theEObject;
			T result = caseNaviType(naviType);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.GRID_NAV: {
			GridNav gridNav = (GridNav) theEObject;
			T result = caseGridNav(gridNav);
			if (result == null)
				result = caseNaviType(gridNav);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.DEFAULT_NAV: {
			DefaultNav defaultNav = (DefaultNav) theEObject;
			T result = caseDefaultNav(defaultNav);
			if (result == null)
				result = caseNaviType(defaultNav);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.TABLET_NAV: {
			TabletNav tabletNav = (TabletNav) theEObject;
			T result = caseTabletNav(tabletNav);
			if (result == null)
				result = caseNaviType(tabletNav);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.MINIMUM_NAVIGATION: {
			MinimumNavigation minimumNavigation = (MinimumNavigation) theEObject;
			T result = caseMinimumNavigation(minimumNavigation);
			if (result == null)
				result = caseNavigation(minimumNavigation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.LESS_INFORMED_NAV: {
			LessInformedNav lessInformedNav = (LessInformedNav) theEObject;
			T result = caseLessInformedNav(lessInformedNav);
			if (result == null)
				result = caseNavigation(lessInformedNav);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.MORE_INFORMED_NAV: {
			MoreInformedNav moreInformedNav = (MoreInformedNav) theEObject;
			T result = caseMoreInformedNav(moreInformedNav);
			if (result == null)
				result = caseNavigation(moreInformedNav);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.FEEDBACK_BAR: {
			FeedbackBar feedbackBar = (FeedbackBar) theEObject;
			T result = caseFeedbackBar(feedbackBar);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.CLICK_EVENT: {
			ClickEvent clickEvent = (ClickEvent) theEObject;
			T result = caseClickEvent(clickEvent);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.VIEW: {
			View view = (View) theEObject;
			T result = caseView(view);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.FEEDBACK: {
			Feedback feedback = (Feedback) theEObject;
			T result = caseFeedback(feedback);
			if (result == null)
				result = caseView(feedback);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.INSPIRATION: {
			Inspiration inspiration = (Inspiration) theEObject;
			T result = caseInspiration(inspiration);
			if (result == null)
				result = caseView(inspiration);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.LAYOUT: {
			Layout layout = (Layout) theEObject;
			T result = caseLayout(layout);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.FONT_SIZE: {
			FontSize fontSize = (FontSize) theEObject;
			T result = caseFontSize(fontSize);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.DEFAULT_SIZE: {
			DefaultSize defaultSize = (DefaultSize) theEObject;
			T result = caseDefaultSize(defaultSize);
			if (result == null)
				result = caseFontSize(defaultSize);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.LARGE_SIZE: {
			LargeSize largeSize = (LargeSize) theEObject;
			T result = caseLargeSize(largeSize);
			if (result == null)
				result = caseFontSize(largeSize);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.MIDDLE_SIZE: {
			MiddleSize middleSize = (MiddleSize) theEObject;
			T result = caseMiddleSize(middleSize);
			if (result == null)
				result = caseFontSize(middleSize);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.COLOR_SCHEME: {
			ColorScheme colorScheme = (ColorScheme) theEObject;
			T result = caseColorScheme(colorScheme);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.CUSTOM_COLOR: {
			CustomColor customColor = (CustomColor) theEObject;
			T result = caseCustomColor(customColor);
			if (result == null)
				result = caseColorScheme(customColor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.BLACKN_WHITE: {
			BlacknWhite blacknWhite = (BlacknWhite) theEObject;
			T result = caseBlacknWhite(blacknWhite);
			if (result == null)
				result = caseColorScheme(blacknWhite);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.MONO_CHROMATIC: {
			MonoChromatic monoChromatic = (MonoChromatic) theEObject;
			T result = caseMonoChromatic(monoChromatic);
			if (result == null)
				result = caseColorScheme(monoChromatic);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.NIGHT_MODE_SCHEME: {
			NightModeScheme nightModeScheme = (NightModeScheme) theEObject;
			T result = caseNightModeScheme(nightModeScheme);
			if (result == null)
				result = caseColorScheme(nightModeScheme);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.TASK_FEATURE: {
			TaskFeature taskFeature = (TaskFeature) theEObject;
			T result = caseTaskFeature(taskFeature);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.MENU: {
			Menu menu = (Menu) theEObject;
			T result = caseMenu(menu);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.ATTACHMENTS: {
			Attachments attachments = (Attachments) theEObject;
			T result = caseAttachments(attachments);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.AUTO_DOWNLOAD: {
			AutoDownload autoDownload = (AutoDownload) theEObject;
			T result = caseAutoDownload(autoDownload);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.READ_EMAIL: {
			ReadEmail readEmail = (ReadEmail) theEObject;
			T result = caseReadEmail(readEmail);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.SHOW_EMAIL: {
			ShowEmail showEmail = (ShowEmail) theEObject;
			T result = caseShowEmail(showEmail);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.WRITE_EMAIL: {
			WriteEmail writeEmail = (WriteEmail) theEObject;
			T result = caseWriteEmail(writeEmail);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.EMAIL_FORM: {
			EmailForm emailForm = (EmailForm) theEObject;
			T result = caseEmailForm(emailForm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.HTML: {
			HTML html = (HTML) theEObject;
			T result = caseHTML(html);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case UIAdaptationPackage.TEXT_FORM: {
			TextForm textForm = (TextForm) theEObject;
			T result = caseTextForm(textForm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>App</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>App</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseApp(App object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Navigation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Navigation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNavigation(Navigation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Navi Type</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Navi Type</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNaviType(NaviType object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Grid Nav</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Grid Nav</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGridNav(GridNav object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Default Nav</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Default Nav</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDefaultNav(DefaultNav object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tablet Nav</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tablet Nav</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTabletNav(TabletNav object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Minimum Navigation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Minimum Navigation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMinimumNavigation(MinimumNavigation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Less Informed Nav</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Less Informed Nav</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLessInformedNav(LessInformedNav object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>More Informed Nav</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>More Informed Nav</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMoreInformedNav(MoreInformedNav object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Feedback Bar</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Feedback Bar</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFeedbackBar(FeedbackBar object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Click Event</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Click Event</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseClickEvent(ClickEvent object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>View</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>View</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseView(View object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Feedback</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Feedback</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFeedback(Feedback object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Inspiration</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Inspiration</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInspiration(Inspiration object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Layout</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Layout</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLayout(Layout object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Font Size</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Font Size</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFontSize(FontSize object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Default Size</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Default Size</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDefaultSize(DefaultSize object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Large Size</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Large Size</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLargeSize(LargeSize object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Middle Size</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Middle Size</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMiddleSize(MiddleSize object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Color Scheme</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Color Scheme</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseColorScheme(ColorScheme object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Custom Color</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Custom Color</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCustomColor(CustomColor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Blackn White</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Blackn White</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBlacknWhite(BlacknWhite object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Mono Chromatic</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Mono Chromatic</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMonoChromatic(MonoChromatic object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Night Mode Scheme</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Night Mode Scheme</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNightModeScheme(NightModeScheme object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Task Feature</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Task Feature</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTaskFeature(TaskFeature object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Menu</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Menu</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMenu(Menu object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attachments</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attachments</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttachments(Attachments object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Auto Download</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Auto Download</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAutoDownload(AutoDownload object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Read Email</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Read Email</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseReadEmail(ReadEmail object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Show Email</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Show Email</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseShowEmail(ShowEmail object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Write Email</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Write Email</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWriteEmail(WriteEmail object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Email Form</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Email Form</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEmailForm(EmailForm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>HTML</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>HTML</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHTML(HTML object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Text Form</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Text Form</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTextForm(TextForm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //UIAdaptationSwitch
