/**
 */
package UIAdaptation;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Blackn White</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UIAdaptation.UIAdaptationPackage#getBlacknWhite()
 * @model
 * @generated
 */
public interface BlacknWhite extends ColorScheme { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // BlacknWhite
