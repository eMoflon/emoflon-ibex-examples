/**
 */
package UIAdaptation;

// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Minimum Navigation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see UIAdaptation.UIAdaptationPackage#getMinimumNavigation()
 * @model
 * @generated
 */
public interface MinimumNavigation extends Navigation { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // MinimumNavigation
